create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_sampled_cell;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_reg_vessels;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_ref_changes;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_abstract_landingsite1;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_abstract_landingsite;
ALTER TABLE ONLY public.changes_perm_vessel DROP CONSTRAINT fk_vessel_perm_changes_reg_vessels;
ALTER TABLE ONLY public.changes_perm_vessel DROP CONSTRAINT fk_vessel_perm_changes_ref_changes;
ALTER TABLE ONLY public.changes_perm_vessel DROP CONSTRAINT fk_vessel_perm_changes_fr_frame;
ALTER TABLE ONLY public.ui_user DROP CONSTRAINT fk_user_role;
ALTER TABLE ONLY public.ui_rules DROP CONSTRAINT fk_ui_rules_ui_rule_types;
ALTER TABLE ONLY public.ui_rules DROP CONSTRAINT fk_ui_rules_ui_forms;
ALTER TABLE ONLY public.ui_rule_ptrs DROP CONSTRAINT fk_ui_rule_ptrs_ui_rules;
ALTER TABLE ONLY public.ui_rule_ptrs DROP CONSTRAINT fk_ui_rule_ptrs_ui_forms;
ALTER TABLE ONLY public.fr_tree DROP CONSTRAINT fk_tree_node_description;
ALTER TABLE ONLY public.sampled_strata_vessels DROP CONSTRAINT fk_sampled_strata_vessels_ref_minor_strata;
ALTER TABLE ONLY public.sampled_levels DROP CONSTRAINT fk_sampled_levels_ref_sampling_technique;
ALTER TABLE ONLY public.sampled_levels DROP CONSTRAINT fk_sampled_levels_ref_levels;
ALTER TABLE ONLY public.sampled_levels DROP CONSTRAINT fk_sampled_levels_ref_criteria;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_units1;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_units;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_samplers;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_abstract_landingsite;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_gl_dates;
ALTER TABLE ONLY public.sampled_fishing_trips_gears DROP CONSTRAINT fk_sampled_fishing_trips_gears_sampled_fishing_trips;
ALTER TABLE ONLY public.sampled_fishing_trips_gears DROP CONSTRAINT fk_sampled_fishing_trips_gears_ref_gears;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_cas_dates;
ALTER TABLE ONLY public.sampled_fishing_trips_zones DROP CONSTRAINT fk_sampled_fishing_trip_zones_sampled_fishing_trips;
ALTER TABLE ONLY public.sampled_fishing_trips_zones DROP CONSTRAINT fk_sampled_fishing_trip_zones_ref_fishing_zones;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_units2;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_units1;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_units;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_gears;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_fishing_zones;
ALTER TABLE ONLY public.sampled_fishing_operations_categories DROP CONSTRAINT fk_sampled_fishing_operations_categories_sampled_fishing_operat;
ALTER TABLE ONLY public.sampled_fishing_operations_categories DROP CONSTRAINT fk_sampled_fishing_operations_categories_ref_commercial_categor;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_cas_dates1;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_cas_dates;
ALTER TABLE ONLY public.sampled_cell DROP CONSTRAINT fk_sampled_cell_gl_dates;
ALTER TABLE ONLY public.sampled_cell DROP CONSTRAINT fk_sampled_cell_cas_dates;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT fk_sampled_catch_sampled_fishing_operations;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units3;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units2;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units1;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_commercial_categories;
ALTER TABLE ONLY public.ref_gears DROP CONSTRAINT fk_refgears_refmarinefisherysubsectors;
ALTER TABLE ONLY public.ref_gears DROP CONSTRAINT fk_refgears_refgearclasses;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_vessel_types;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_ports;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_operational_statuses;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_issuing_offices;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_gears1;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_gears;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_fleet_segmentation;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_engine_locations;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_countries1;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_countries;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_commercial_categories1;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_commercial_categories;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_changes;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_authorisation_types;
ALTER TABLE ONLY public.ref_sampling_technique DROP CONSTRAINT fk_ref_sampling_technique_ref_strategy;
ALTER TABLE ONLY public.ref_sampling_technique DROP CONSTRAINT fk_ref_sampling_technique_fr_time;
ALTER TABLE ONLY public.ref_collectors DROP CONSTRAINT fk_ref_collectors_reg_vessels;
ALTER TABLE ONLY public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_ref_no_recording_activities;
ALTER TABLE ONLY public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_group_of_landingsites;
ALTER TABLE ONLY public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_frame_time;
ALTER TABLE ONLY public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_cas_dates1;
ALTER TABLE ONLY public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_cas_dates;
ALTER TABLE ONLY public.changes_perm_ls DROP CONSTRAINT fk_ls_perm_changes_fr_frame;
ALTER TABLE ONLY public.changes_perm_ls DROP CONSTRAINT fk_ls_perm_changes_abstract_landingsite;
ALTER TABLE ONLY public.ref_location DROP CONSTRAINT fk_location_ref_countries;
ALTER TABLE ONLY public.info_tables_import DROP CONSTRAINT fk_info_tables_import_info_tables;
ALTER TABLE ONLY public.info_fields DROP CONSTRAINT fk_info_fields_info_tables1;
ALTER TABLE ONLY public.info_client DROP CONSTRAINT fk_info_client_info_changes;
ALTER TABLE ONLY public.info_changes DROP CONSTRAINT fk_info_changes_gl_session;
ALTER TABLE ONLY public.info_changes DROP CONSTRAINT fk_info_changes_gl_dates;
ALTER TABLE ONLY public.changes_perm_gls DROP CONSTRAINT fk_gls_perm_changes_group_of_landingsites;
ALTER TABLE ONLY public.changes_perm_gls DROP CONSTRAINT fk_gls_perm_changes_fr_frame;
ALTER TABLE ONLY public.fr_gls2als DROP CONSTRAINT fk_gls2als_group_of_landingsites;
ALTER TABLE ONLY public.fr_gls2als DROP CONSTRAINT fk_gls2als_abstract_landingsite;
ALTER TABLE ONLY public.gl_session DROP CONSTRAINT fk_gl_session_ui_user;
ALTER TABLE ONLY public.gl_session DROP CONSTRAINT fk_gl_session_ref_local;
ALTER TABLE ONLY public.gl_session DROP CONSTRAINT fk_gl_session_gl_dates1;
ALTER TABLE ONLY public.gl_session DROP CONSTRAINT fk_gl_session_gl_dates;
ALTER TABLE ONLY public.fr_time DROP CONSTRAINT fk_frame_time_cas_dates1;
ALTER TABLE ONLY public.fr_time DROP CONSTRAINT fk_frame_time_cas_dates;
ALTER TABLE ONLY public.fr_time DROP CONSTRAINT fk_fr_time_fr_frame;
ALTER TABLE ONLY public.fr_sub_frame DROP CONSTRAINT fk_fr_sub_frame_ref_frame;
ALTER TABLE ONLY public.fr_sub_frame DROP CONSTRAINT fk_fr_sub_frame_fr_frame;
ALTER TABLE ONLY public.fr_gls2als DROP CONSTRAINT fk_fr_gls2als_fr_frame;
ALTER TABLE ONLY public.fr_frame DROP CONSTRAINT fk_fr_frame_ref_source__;
ALTER TABLE ONLY public.fr_frame DROP CONSTRAINT fk_fr_frame_ref_source_;
ALTER TABLE ONLY public.fr_frame DROP CONSTRAINT fk_fr_frame_ref_source;
ALTER TABLE ONLY public.fr_f2gls DROP CONSTRAINT fk_fr_f2gls_group_of_landingsites;
ALTER TABLE ONLY public.fr_f2gls DROP CONSTRAINT fk_fr_f2gls_fr_frame;
ALTER TABLE ONLY public.fr_als2vessel DROP CONSTRAINT fk_fr_als2vessel_reg_vessels;
ALTER TABLE ONLY public.fr_als2vessel DROP CONSTRAINT fk_fr_als2vessel_fr_frame;
ALTER TABLE ONLY public.fr_als2vessel DROP CONSTRAINT fk_fr_als2vessel_abstract_landingsite;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_fishing_trips_ref_units;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT fk_fishing_trips_cell_vessels;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT fk_fishing_operation_fishing_trips;
ALTER TABLE ONLY public.sampled_cell_vessels DROP CONSTRAINT fk_cell_vessels_cell_vessel_types;
ALTER TABLE ONLY public.sampled_cell_vessel_types DROP CONSTRAINT fk_cell_vessel_types_ref_vessel_types;
ALTER TABLE ONLY public.sampled_cell_vessel_types DROP CONSTRAINT fk_cell_vessel_types_cell;
ALTER TABLE ONLY public.sampled_cell DROP CONSTRAINT fk_cell_minor_strata;
ALTER TABLE ONLY public.ref_abstract_landingsite DROP CONSTRAINT fk_cas_landingsite2psu_ref_ports;
ALTER TABLE ONLY public.ref_abstract_landingsite DROP CONSTRAINT fk_cas_landingsite2psu_ref_collectors;
ALTER TABLE ONLY public.ref_abstract_landingsite DROP CONSTRAINT fk_cas_landingsite2psu_cas_landingsite_type;
ALTER TABLE ONLY public.gl_dates DROP CONSTRAINT fk_cas_dates_ref_datetime_type;
ALTER TABLE ONLY public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_vessels;
ALTER TABLE ONLY public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_source;
ALTER TABLE ONLY public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_sample_status;
ALTER TABLE ONLY public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_sample_origin;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_abstract_changes_temp_vessel_ref_source;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT fk_abstract_changes_temp_vessel_ref_minor_strata;
DROP INDEX public.uq___ref_months__3dadc7f6;
DROP INDEX public.uq___ref_countries__0d5f9656;
DROP INDEX public.ref_vessel_types_uq___ref_vessel_type__2442fbae;
DROP INDEX public.ref_operational_statuses_uq___ref_operational__4366a14c;
DROP INDEX public.ref_no_recording_activities_uq___ref_no_recordin__21118948;
DROP INDEX public.ref_marine_fishery_subsectors_uq___ref_marine_fish__25d63e65;
DROP INDEX public.ref_issuing_offices_uq____ref_issuing_of__3e4ce674;
DROP INDEX public.ref_gear_classes_uq___ref_gear_classe__17881f0e;
DROP INDEX public.ref_fleet_segmentation_uq___ref_fleet_segme__11cf45b8;
DROP INDEX public.ref_fishing_zones_uq___ref_fishing_zon__0d0a909b;
DROP INDEX public.ref_engine_locations_uq___ref_engine_loca__5dc591cd;
DROP INDEX public.ref_commercial_categories_uq___ref_group_of_sp__1c4cd42b;
DROP INDEX public.ref_changes_uq____ref_inactivity__49be9920;
DROP INDEX public.ref_authorisation_types_uq____ref_authorisat__39883157;
DROP INDEX public.info_tables_uniquenamecstrnt;
DROP INDEX public.info_fields_uniquetablefieldcstrt;
DROP INDEX public.gl_null_replacements_unique_display_name_cstrt;
DROP INDEX public.gl_null_replacements_unique_code_cstrt;
ALTER TABLE ONLY public.ui_user DROP CONSTRAINT ui_user_pk_user;
ALTER TABLE ONLY public.ui_rule_ptrs DROP CONSTRAINT ui_rule_ptrs_pk_ui_pre_triggers_ptrs_1;
ALTER TABLE ONLY public.ui_role DROP CONSTRAINT ui_role_pk_role;
ALTER TABLE ONLY public.sampled_fishing_trips_zones DROP CONSTRAINT sampled_fishing_trips_zones_pk_sampled_fishing_trip_zones;
ALTER TABLE ONLY public.sampled_fishing_trips DROP CONSTRAINT sampled_fishing_trips_pk_fishing_trips;
ALTER TABLE ONLY public.sampled_fishing_operations DROP CONSTRAINT sampled_fishing_operations_pk_fishing_operation;
ALTER TABLE ONLY public.sampled_cell_vessels DROP CONSTRAINT sampled_cell_vessels_pk_cell_vessels;
ALTER TABLE ONLY public.sampled_cell_vessel_types DROP CONSTRAINT sampled_cell_vessel_types_pk_cell_vessel_types;
ALTER TABLE ONLY public.sampled_cell DROP CONSTRAINT sampled_cell_pk_cell;
ALTER TABLE ONLY public.ref_vessels DROP CONSTRAINT ref_vessels_constraint1;
ALTER TABLE ONLY public.ref_vessel_types DROP CONSTRAINT ref_vessel_types_refvesseltypes_constraint1_;
ALTER TABLE ONLY public.ref_strategy DROP CONSTRAINT ref_strategy_pk_ref_criteria;
ALTER TABLE ONLY public.ref_stocks DROP CONSTRAINT ref_stocks_refstocks_constraint1;
ALTER TABLE ONLY public.ref_species DROP CONSTRAINT ref_species_refspecies_constraint1______;
ALTER TABLE ONLY public.ref_sampling_technique DROP CONSTRAINT ref_sampling_technique_pk_ref_schema;
ALTER TABLE ONLY public.ref_sample_status DROP CONSTRAINT ref_sample_status_aaaaaref_logbook_status_pk;
ALTER TABLE ONLY public.ref_sample_origin DROP CONSTRAINT ref_sample_origin_aaaaaref_logbooks_origin_pk;
ALTER TABLE ONLY public.ref_ports DROP CONSTRAINT ref_ports_refports_constraint1_;
ALTER TABLE ONLY public.ref_operational_statuses DROP CONSTRAINT ref_operational_statuses_refoperationalstatuses_constraint1_;
ALTER TABLE ONLY public.ref_no_recording_activities DROP CONSTRAINT ref_no_recording_activities_reflogbooknareasons_constraint1;
ALTER TABLE ONLY public.ref_months DROP CONSTRAINT ref_months_refmonths_constraint1;
ALTER TABLE ONLY public.ref_minor_strata DROP CONSTRAINT ref_minor_strata_pk_minor_strata;
ALTER TABLE ONLY public.ref_marine_fishery_subsectors DROP CONSTRAINT ref_marine_fishery_subsectors_refmarinefisherysubsectors_constr;
ALTER TABLE ONLY public.ref_location DROP CONSTRAINT ref_location_pk_location;
ALTER TABLE ONLY public.ref_levels DROP CONSTRAINT ref_levels_pk_sampled_levels;
ALTER TABLE ONLY public.ref_landingsite_type DROP CONSTRAINT ref_landingsite_type_pk_ref_psu_detail_type;
ALTER TABLE ONLY public.ref_issuing_offices DROP CONSTRAINT ref_issuing_offices_refissuingoffices_constraint1;
ALTER TABLE ONLY public.ref_group_of_landingsites DROP CONSTRAINT ref_group_of_landingsites_pk_group_of_landingsites;
ALTER TABLE ONLY public.ref_gears DROP CONSTRAINT ref_gears_refgears_constraint1;
ALTER TABLE ONLY public.ref_gear_classes DROP CONSTRAINT ref_gear_classes_refgearclasses_constraint1;
ALTER TABLE ONLY public.ref_fleet_segmentation DROP CONSTRAINT ref_fleet_segmentation_reffleetsegmentation_constraint1;
ALTER TABLE ONLY public.ref_fishing_zones DROP CONSTRAINT ref_fishing_zones_reffishingzones_constraint1;
ALTER TABLE ONLY public.ref_engine_locations DROP CONSTRAINT ref_engine_locations_refenginelocations_constraint1;
ALTER TABLE ONLY public.ref_countries DROP CONSTRAINT ref_countries_refcountries_constraint1;
ALTER TABLE ONLY public.ref_commercial_categories DROP CONSTRAINT ref_commercial_categories_refgroupofspecies_constraint1;
ALTER TABLE ONLY public.ref_changes DROP CONSTRAINT ref_changes_refinactivityreasons_constraint1_;
ALTER TABLE ONLY public.ref_authorisation_types DROP CONSTRAINT ref_authorisation_types_refauthorisationtypes_constraint1;
ALTER TABLE ONLY public.ref_abstract_landingsite DROP CONSTRAINT ref_abstract_landingsite_pk_ref_psu_detail;
ALTER TABLE ONLY public.ui_rules DROP CONSTRAINT pk_ui_rules;
ALTER TABLE ONLY public.ui_rule_types DROP CONSTRAINT pk_ui_rule_types;
ALTER TABLE ONLY public.ui_forms DROP CONSTRAINT pk_ui_forms;
ALTER TABLE ONLY public.ui_boolean_mapping DROP CONSTRAINT pk_ui_boolean_mapping;
ALTER TABLE ONLY public.sampled_strata_vessels DROP CONSTRAINT pk_sampled_strata_vessels;
ALTER TABLE ONLY public.sampled_levels DROP CONSTRAINT pk_sampled_levels_1;
ALTER TABLE ONLY public.sampled_fishing_trips_gears DROP CONSTRAINT pk_sampled_fishing_trips_gears;
ALTER TABLE ONLY public.sampled_fishing_operations_categories DROP CONSTRAINT pk_sampled_fishing_operations_categories;
ALTER TABLE ONLY public.sampled_catch DROP CONSTRAINT pk_sampled_catch;
ALTER TABLE ONLY public.ref_units DROP CONSTRAINT pk_ref_units;
ALTER TABLE ONLY public.ref_source DROP CONSTRAINT pk_ref_source;
ALTER TABLE ONLY public.ref_samplers DROP CONSTRAINT pk_ref_samplers;
ALTER TABLE ONLY public.ref_frame DROP CONSTRAINT pk_ref_frame;
ALTER TABLE ONLY public.ref_datetime_type DROP CONSTRAINT pk_ref_datetime_type;
ALTER TABLE ONLY public.ref_collectors DROP CONSTRAINT pk_ref_collectors;
ALTER TABLE ONLY public.info_triggers DROP CONSTRAINT pk_info_triggers;
ALTER TABLE ONLY public.info_fk DROP CONSTRAINT pk_info_fk;
ALTER TABLE ONLY public.info_changes DROP CONSTRAINT pk_info_changes;
ALTER TABLE ONLY public.gl_session DROP CONSTRAINT pk_gl_session;
ALTER TABLE ONLY public.fr_sub_frame DROP CONSTRAINT pk_fr_sub_frame;
ALTER TABLE ONLY public.fr_gls2als DROP CONSTRAINT pk_fr_gls2als;
ALTER TABLE ONLY public.fr_frame DROP CONSTRAINT pk_fr_frame;
ALTER TABLE ONLY public.fr_f2gls DROP CONSTRAINT pk_fr_f2gls;
ALTER TABLE ONLY public.fr_als2vessel DROP CONSTRAINT pk_fr_als2vessel;
ALTER TABLE ONLY public.abstract_sampled_vessels DROP CONSTRAINT pk_abstract_sampled_vessels;
ALTER TABLE ONLY public.info_tables DROP CONSTRAINT info_tables_pk_cas_tables;
ALTER TABLE ONLY public.info_tables_import DROP CONSTRAINT info_tables_import_pk_cas_tables_import_1;
ALTER TABLE ONLY public.info_fields DROP CONSTRAINT info_fields_pk_cas_fields;
ALTER TABLE ONLY public.gl_null_replacements DROP CONSTRAINT gl_null_replacements_pk_null_replacements;
ALTER TABLE ONLY public.gl_dates DROP CONSTRAINT gl_dates_pk_cas_dates;
ALTER TABLE ONLY public.fr_tree DROP CONSTRAINT fr_tree_pk_tree;
ALTER TABLE ONLY public.fr_time DROP CONSTRAINT fr_time_pk_fr_frame_time;
ALTER TABLE ONLY public.fr_node_description DROP CONSTRAINT fr_node_description_pk_ref_levels;
ALTER TABLE ONLY public.changes_perm_vessel DROP CONSTRAINT changes_perm_vessel_pk_perm_changes;
ALTER TABLE ONLY public.changes_perm_ls DROP CONSTRAINT changes_perm_ls_pk_ls_perm_changes;
ALTER TABLE ONLY public.changes_perm_gls DROP CONSTRAINT changes_perm_gls_pk_gls_perm_changes;
ALTER TABLE ONLY public.abstract_changes_temp_vessel DROP CONSTRAINT abstract_changes_temp_vessel_pk_temp_changes;
ALTER TABLE ONLY public.ref_logbook_types DROP CONSTRAINT aaaaaref_logbook_types_pk;
ALTER TABLE public.ui_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ui_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ui_rule_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ui_rule_ptrs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ui_role ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ui_forms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ui_boolean_mapping ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_strata_vessels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_levels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_fishing_trips_zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_fishing_trips_gears ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_fishing_trips ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_fishing_operations_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_fishing_operations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_cell_vessels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_cell_vessel_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_cell ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sampled_catch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_vessels ALTER COLUMN vesselid DROP DEFAULT;
ALTER TABLE public.ref_vessel_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_units ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_strategy ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_stocks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_species ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_sampling_technique ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_samplers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_sample_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_sample_origin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_ports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_operational_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_no_recording_activities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_months ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_minor_strata ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_marine_fishery_subsectors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_logbook_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_location ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_levels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_landingsite_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_issuing_offices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_group_of_landingsites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_gears ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_gear_classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_frame ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_fleet_segmentation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_fishing_zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_engine_locations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_datetime_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_commercial_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_collectors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_changes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_authorisation_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ref_abstract_landingsite ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_triggers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_tables_import ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_tables ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_master ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_fk ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_client ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.info_changes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gl_session ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gl_null_replacements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gl_dates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_tree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_time ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_sub_frame ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_node_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_gls2als ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_frame ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_f2gls ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fr_als2vessel ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.changes_perm_vessel ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.changes_perm_ls ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.changes_perm_gls ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.abstract_sampled_vessels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.abstract_changes_temp_vessel ALTER COLUMN id DROP DEFAULT;
DROP VIEW public.viewvesseltypesgears;
DROP VIEW public.viewvesseltypes4cell;
DROP VIEW public.viewvesselssampling;
DROP VIEW public.viewvesselslogbook;
DROP VIEW public.viewvessels4ms;
DROP VIEW public.viewvessels4cell;
DROP VIEW public.viewunionaddedvessels;
DROP VIEW public.viewtablesimport;
DROP VIEW public.viewstartenddatefrtime;
DROP VIEW public.viewselectlogbooksampling;
DROP VIEW public.viewsampvesseltypes;
DROP VIEW public.viewreasons2permchangels;
DROP VIEW public.viewpreviewcatch;
DROP VIEW public.viewports;
DROP VIEW public.viewoutvesselsreasons;
DROP VIEW public.viewnotin;
DROP VIEW public.viewnonimportedtables;
DROP VIEW public.viewmsdates;
DROP VIEW public.viewmaingear;
DROP VIEW public.viewls4gls;
DROP VIEW public.viewlastinsertedlocation;
DROP VIEW public.viewinvesselsreasons;
DROP VIEW public.viewinfofields;
DROP VIEW public.viewinfochanges;
DROP VIEW public.viewimportedtablechanges;
DROP VIEW public.viewhasrecords;
DROP VIEW public.viewgls4selectedframe;
DROP VIEW public.viewfilter4combotrip;
DROP VIEW public.viewfieldsnonimportedtables;
DROP VIEW public.viewcopysites;
DROP VIEW public.viewcommercialcategoriesandgears4vessels;
DROP VIEW public.viewcheckoperationcat;
DROP VIEW public.viewcatchbygear;
DROP VIEW public.viewals4filtercombotrips_logbook;
DROP VIEW public.viewals;
DROP VIEW public.view_foreignkeys;
DROP SEQUENCE public.ui_user_id_seq;
DROP TABLE public.ui_user;
DROP SEQUENCE public.ui_rules_id_seq;
DROP TABLE public.ui_rules;
DROP SEQUENCE public.ui_rule_types_id_seq;
DROP TABLE public.ui_rule_types;
DROP SEQUENCE public.ui_rule_ptrs_id_seq;
DROP TABLE public.ui_rule_ptrs;
DROP SEQUENCE public.ui_role_id_seq;
DROP TABLE public.ui_role;
DROP SEQUENCE public.ui_forms_id_seq;
DROP TABLE public.ui_forms;
DROP SEQUENCE public.ui_boolean_mapping_id_seq;
DROP TABLE public.ui_boolean_mapping;
DROP TABLE public.t_distribution;
DROP SEQUENCE public.sampled_strata_vessels_id_seq;
DROP TABLE public.sampled_strata_vessels;
DROP SEQUENCE public.sampled_levels_id_seq;
DROP TABLE public.sampled_levels;
DROP SEQUENCE public.sampled_fishing_trips_zones_id_seq;
DROP TABLE public.sampled_fishing_trips_zones;
DROP SEQUENCE public.sampled_fishing_trips_id_seq;
DROP SEQUENCE public.sampled_fishing_trips_gears_id_seq;
DROP TABLE public.sampled_fishing_trips_gears;
DROP TABLE public.sampled_fishing_trips;
DROP SEQUENCE public.sampled_fishing_operations_id_seq;
DROP SEQUENCE public.sampled_fishing_operations_categories_id_seq;
DROP TABLE public.sampled_fishing_operations_categories;
DROP SEQUENCE public.sampled_cell_vessels_id_seq;
DROP TABLE public.sampled_cell_vessels;
DROP SEQUENCE public.sampled_cell_vessel_types_id_seq;
DROP TABLE public.sampled_cell_vessel_types;
DROP SEQUENCE public.sampled_cell_id_seq;
DROP TABLE public.sampled_cell;
DROP SEQUENCE public.sampled_catch_id_seq;
DROP TABLE public.sampled_catch;
DROP SEQUENCE public.ref_vessels_vesselid_seq;
DROP TABLE public.ref_vessels;
DROP SEQUENCE public.ref_vessel_types_id_seq;
DROP TABLE public.ref_vessel_types;
DROP SEQUENCE public.ref_units_id_seq;
DROP TABLE public.ref_units;
DROP SEQUENCE public.ref_strategy_id_seq;
DROP TABLE public.ref_strategy;
DROP SEQUENCE public.ref_stocks_id_seq;
DROP TABLE public.ref_stocks;
DROP SEQUENCE public.ref_species_id_seq;
DROP TABLE public.ref_species;
DROP SEQUENCE public.ref_source_id_seq;
DROP TABLE public.ref_source;
DROP SEQUENCE public.ref_sampling_technique_id_seq;
DROP TABLE public.ref_sampling_technique;
DROP SEQUENCE public.ref_samplers_id_seq;
DROP TABLE public.ref_samplers;
DROP SEQUENCE public.ref_sample_status_id_seq;
DROP TABLE public.ref_sample_status;
DROP SEQUENCE public.ref_sample_origin_id_seq;
DROP TABLE public.ref_sample_origin;
DROP SEQUENCE public.ref_ports_id_seq;
DROP TABLE public.ref_ports;
DROP SEQUENCE public.ref_operational_statuses_id_seq;
DROP TABLE public.ref_operational_statuses;
DROP SEQUENCE public.ref_no_recording_activities_id_seq;
DROP TABLE public.ref_no_recording_activities;
DROP SEQUENCE public.ref_months_id_seq;
DROP TABLE public.ref_months;
DROP SEQUENCE public.ref_minor_strata_id_seq;
DROP SEQUENCE public.ref_marine_fishery_subsectors_id_seq;
DROP TABLE public.ref_marine_fishery_subsectors;
DROP SEQUENCE public.ref_logbook_types_id_seq;
DROP TABLE public.ref_logbook_types;
DROP SEQUENCE public.ref_location_id_seq;
DROP TABLE public.ref_location;
DROP SEQUENCE public.ref_levels_id_seq;
DROP TABLE public.ref_levels;
DROP SEQUENCE public.ref_landingsite_type_id_seq;
DROP TABLE public.ref_landingsite_type;
DROP SEQUENCE public.ref_issuing_offices_id_seq;
DROP TABLE public.ref_issuing_offices;
DROP SEQUENCE public.ref_group_of_landingsites_id_seq;
DROP SEQUENCE public.ref_gears_id_seq;
DROP SEQUENCE public.ref_gear_classes_id_seq;
DROP TABLE public.ref_gear_classes;
DROP SEQUENCE public.ref_frame_id_seq;
DROP SEQUENCE public.ref_fleet_segmentation_id_seq;
DROP TABLE public.ref_fleet_segmentation;
DROP SEQUENCE public.ref_fishing_zones_id_seq;
DROP TABLE public.ref_fishing_zones;
DROP SEQUENCE public.ref_engine_locations_id_seq;
DROP TABLE public.ref_engine_locations;
DROP SEQUENCE public.ref_datetime_type_id_seq;
DROP TABLE public.ref_datetime_type;
DROP SEQUENCE public.ref_countries_id_seq;
DROP TABLE public.ref_countries;
DROP SEQUENCE public.ref_commercial_categories_id_seq;
DROP SEQUENCE public.ref_collectors_id_seq;
DROP TABLE public.ref_collectors;
DROP SEQUENCE public.ref_changes_id_seq;
DROP TABLE public.ref_changes;
DROP SEQUENCE public.ref_authorisation_types_id_seq;
DROP TABLE public.ref_authorisation_types;
DROP SEQUENCE public.ref_abstract_landingsite_id_seq;
DROP VIEW public.query_trips_for_exaro;
DROP TABLE public.sampled_fishing_operations;
DROP TABLE public.ref_gears;
DROP TABLE public.ref_commercial_categories;
DROP SEQUENCE public.info_triggers_id_seq;
DROP TABLE public.info_triggers;
DROP SEQUENCE public.info_tables_import_id_seq;
DROP TABLE public.info_tables_import;
DROP SEQUENCE public.info_tables_id_seq;
DROP TABLE public.info_tables;
DROP SEQUENCE public.info_master_id_seq;
DROP TABLE public.info_master;
DROP SEQUENCE public.info_fk_id_seq;
DROP TABLE public.info_fk;
DROP SEQUENCE public.info_fields_id_seq;
DROP TABLE public.info_fields;
DROP SEQUENCE public.info_client_id_seq;
DROP TABLE public.info_client;
DROP SEQUENCE public.info_changes_id_seq;
DROP TABLE public.info_changes;
DROP SEQUENCE public.gl_session_id_seq;
DROP TABLE public.gl_session;
DROP SEQUENCE public.gl_null_replacements_id_seq;
DROP TABLE public.gl_null_replacements;
DROP SEQUENCE public.gl_dates_id_seq;
DROP TABLE public.gl_dates;
DROP SEQUENCE public.fr_tree_id_seq;
DROP TABLE public.fr_tree;
DROP SEQUENCE public.fr_time_id_seq;
DROP TABLE public.fr_time;
DROP SEQUENCE public.fr_sub_frame_id_seq;
DROP SEQUENCE public.fr_node_description_id_seq;
DROP TABLE public.fr_node_description;
DROP SEQUENCE public.fr_gls2als_id_seq;
DROP SEQUENCE public.fr_frame_id_seq;
DROP SEQUENCE public.fr_f2gls_id_seq;
DROP SEQUENCE public.fr_als2vessel_id_seq;
DROP VIEW public.countgls4frame;
DROP TABLE public.ref_frame;
DROP TABLE public.fr_sub_frame;
DROP TABLE public.fr_frame;
DROP TABLE public.fr_f2gls;
DROP SEQUENCE public.changes_perm_vessel_id_seq;
DROP TABLE public.changes_perm_vessel;
DROP SEQUENCE public.changes_perm_ls_id_seq;
DROP TABLE public.changes_perm_ls;
DROP SEQUENCE public.changes_perm_gls_id_seq;
DROP TABLE public.changes_perm_gls;
DROP SEQUENCE public.abstract_sampled_vessels_id_seq;
DROP TABLE public.abstract_sampled_vessels;
DROP SEQUENCE public.abstract_changes_temp_vessel_id_seq;
DROP TABLE public.abstract_changes_temp_vessel;
DROP VIEW public."View_ForeignKeys";
DROP VIEW public."ViewSelectLogbookSampling";
DROP TABLE public.ref_minor_strata;
DROP TABLE public.ref_group_of_landingsites;
DROP TABLE public.ref_abstract_landingsite;
DROP TABLE public.fr_gls2als;
DROP TABLE public.fr_als2vessel;
DROP FUNCTION public.update_rules_from_ptrs();
DROP FUNCTION public.update_info_tables2();
DROP FUNCTION public.spcountgls4frame(_p_frameid integer);
DROP FUNCTION public.showhierarchy(_root integer, _level integer);
DROP FUNCTION public.set_constraints_deferrable();
DROP FUNCTION public.searchandreplace(searchstr character varying, replacestr character varying);
DROP FUNCTION public.searchalltables(searchstr character varying);
DROP FUNCTION public.returnbasedate();
DROP FUNCTION public.reset_table(_table character varying);
DROP FUNCTION public.reset_changes();
DROP FUNCTION public.reset_all_tables();
DROP FUNCTION public.renameanddrop(_name character varying);
DROP FUNCTION public.remove_fields_from_unused_tables();
DROP FUNCTION public.nested2adjacency(_p_id integer);
DROP FUNCTION public.list2nested();
DROP FUNCTION public.initializenestedmodel();
DROP FUNCTION public.gettablexml(_name character varying);
DROP FUNCTION public.gen_info_tables();
DROP FUNCTION public.dropinstriggers();
DROP FUNCTION public.dropdeltriggers();
DROP FUNCTION public.dropafteruptriggers();
DROP FUNCTION public.drop_id_session_all();
DROP FUNCTION public.drop_all_triggers();
DROP FUNCTION public.drop_all_constraints();
DROP FUNCTION public.displayrowcount();
DROP FUNCTION public.create_trigger_all2();
DROP FUNCTION public.create_all_constraints();
DROP FUNCTION public.create_after_update_all();
DROP FUNCTION public.create_after_insert_all();
DROP FUNCTION public.create_after_delete_all();
DROP FUNCTION public.add_session_id(_table character varying);
DROP FUNCTION public.add_session_all();
DROP FUNCTION public.add_fields_from_new_tables();
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: add_fields_from_new_tables(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION add_fields_from_new_tables() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN

INSERT into Info_Fields ( table_name , field_name , original_type , reviewed_type , original_size 
, reviewed_size ) 



SELECT table_name as table_name, column_name as field_name, data_type as original_type, data_type as reviewed_type, 

	CASE WHEN data_type like 'text' THEN character_octet_length
	WHEN data_type like '%int%' THEN numeric_precision
            ELSE  -1 END as original_size,

	CASE WHEN data_type like 'text' THEN character_octet_length
	WHEN data_type like '%int%' THEN numeric_precision
            ELSE  -1 END as reviewed_size
            
FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' 
AND table_name NOT IN
	(SELECT table_name from Info_Fields)
	
order by 1, 2 ASC;




  END;
  $$;


ALTER FUNCTION public.add_fields_from_new_tables() OWNER TO postgres;

--
-- Name: add_session_all(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION add_session_all() RETURNS void
    LANGUAGE plpgsql
    AS $$
	DECLARE
	_FK varchar (100) ;
	 _string varchar ( 1000 );
	 r record;
begin

	FOR r IN SELECT distinct table_name FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' LOOP
	
		_FK := 'fk_' || r.table_name || '_gl_session' ;

		-- check if column exists
		IF NOT EXISTS (SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name like r.table_name and column_name like 'id_session')
		THEN
			_string := 'ALTER TABLE ' || r.table_name || ' ADD id_session bigint NOT NULL DEFAULT 1' ;
			--raise info '%', _string;
			EXECUTE ( _string ) ; 				
		END IF;

		-- check if constraint exists
		IF NOT EXISTS (SELECT table_name,constraint_name
		     FROM information_schema.constraint_table_usage
		     where constraint_name like _FK)
		     THEN
			_string := 'ALTER TABLE ' || r.table_name || ' ADD  CONSTRAINT  ' || _FK || ' FOREIGN KEY( id_session ) REFERENCES   GL_Session  ( id )';
			--raise info '%', _string;			
			EXECUTE ( _string ) ; 					
		     end if;



	end LOOP;



 
END 

  $$;


ALTER FUNCTION public.add_session_all() OWNER TO postgres;

--
-- Name: add_session_id(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION add_session_id(_table character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
	DECLARE
	 _string varchar ( 1000 );
begin
	_string := 'ALTER TABLE ' || _table || ' ADD id_session bigint NOT NULL DEFAULT 1' ;
	raise info '%', _string;
	EXECUTE ( _string ) ; 
	_string := 'ALTER TABLE ' || _table || ' ADD  CONSTRAINT  fk_' || _table || '_gl_session  FOREIGN KEY( id_session ) REFERENCES   gl_session  ( id )';
	EXECUTE ( _string ) ; 
	raise info '%', _string;	
 
END 

  $$;


ALTER FUNCTION public.add_session_id(_table character varying) OWNER TO postgres;

--
-- Name: create_after_delete_all(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_after_delete_all() RETURNS void
    LANGUAGE plpgsql
    AS $$



	DECLARE _string varchar ( 1000 ) ;
	DECLARE _table_name varchar ( 50 ); 
	DECLARE r RECORD;

  BEGIN



	FOR r IN SELECT DISTINCT TABLE_NAME from info_triggers  LOOP
  

		_string := 'select Create_AFTER_DELETE_TRIGGER ('  ||  cast(r.TABLE_NAME as varchar)  ||  ')';
		--raise info '%s', r.TABLE_NAME;
		raise info '%', _string;
		EXECUTE ( _string ) ; 
	
	 end loop;


	
  END;
  
 $$;


ALTER FUNCTION public.create_after_delete_all() OWNER TO postgres;

--
-- Name: create_after_insert_all(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_after_insert_all() RETURNS void
    LANGUAGE plpgsql
    AS $$



	DECLARE _string varchar ( 1000 ) ;
	DECLARE _table_name varchar ( 50 ); 
	DECLARE r RECORD;

  BEGIN



	FOR r IN SELECT DISTINCT TABLE_NAME from info_triggers  LOOP
  

		_string := 'select Create_AFTER_INSERT_TRIGGER ('''  ||  cast(r.TABLE_NAME as varchar)  ||  ''')';
		--raise info '%s', r.TABLE_NAME;
		raise info '%', _string;
		EXECUTE ( _string ) ; 
	
	 end loop;


	
  END;
  
 $$;


ALTER FUNCTION public.create_after_insert_all() OWNER TO postgres;

--
-- Name: create_after_update_all(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_after_update_all() RETURNS void
    LANGUAGE plpgsql
    AS $$



	DECLARE _string varchar ( 1000 ) ;
	DECLARE _table_name varchar ( 50 ); 
	DECLARE r RECORD;

  BEGIN



	FOR r IN SELECT DISTINCT TABLE_NAME from info_triggers  LOOP
  

		_string := 'select Create_AFTER_UPDATE_TRIGGER ('''  ||  cast(r.TABLE_NAME as varchar)  ||  ''')';
		--raise info '%s', r.TABLE_NAME;
		raise info '%', _string;
		EXECUTE ( _string ) ; 
	
	 end loop;


	
  END;
  
 $$;


ALTER FUNCTION public.create_after_update_all() OWNER TO postgres;

--
-- Name: create_all_constraints(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_all_constraints() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN

	ALTER TABLE public.ui_user ADD CONSTRAINT ui_user_pk_user PRIMARY KEY (id);
	ALTER TABLE public.ui_rules ADD CONSTRAINT pk_ui_rules PRIMARY KEY (id);
	ALTER TABLE public.ui_rule_types ADD CONSTRAINT pk_ui_rule_types PRIMARY KEY (id);
	ALTER TABLE public.ui_rule_ptrs ADD CONSTRAINT ui_rule_ptrs_pk_ui_pre_triggers_ptrs_1 PRIMARY KEY (id);
	ALTER TABLE public.ui_role ADD CONSTRAINT ui_role_pk_role PRIMARY KEY (id);
	ALTER TABLE public.ui_forms ADD CONSTRAINT pk_ui_forms PRIMARY KEY (id);
	ALTER TABLE public.ui_boolean_mapping ADD CONSTRAINT pk_ui_boolean_mapping PRIMARY KEY (id);
	ALTER TABLE public.sampled_strata_vessels ADD CONSTRAINT pk_sampled_strata_vessels PRIMARY KEY (id);
	ALTER TABLE public.sampled_levels ADD CONSTRAINT pk_sampled_levels_1 PRIMARY KEY (id);
	ALTER TABLE public.sampled_fishing_trips_zones ADD CONSTRAINT sampled_fishing_trips_zones_pk_sampled_fishing_trip_zones PRIMARY KEY (id);
	ALTER TABLE public.sampled_fishing_trips_gears ADD CONSTRAINT pk_sampled_fishing_trips_gears PRIMARY KEY (id);
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT sampled_fishing_trips_pk_fishing_trips PRIMARY KEY (id);
	ALTER TABLE public.sampled_fishing_operations_categories ADD CONSTRAINT pk_sampled_fishing_operations_categories PRIMARY KEY (id);
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT sampled_fishing_operations_pk_fishing_operation PRIMARY KEY (id);
	ALTER TABLE public.sampled_cell_vessels ADD CONSTRAINT sampled_cell_vessels_pk_cell_vessels PRIMARY KEY (id);
	ALTER TABLE public.sampled_cell_vessel_types ADD CONSTRAINT sampled_cell_vessel_types_pk_cell_vessel_types PRIMARY KEY (id);
	ALTER TABLE public.sampled_cell ADD CONSTRAINT sampled_cell_pk_cell PRIMARY KEY (id);
	ALTER TABLE public.sampled_catch ADD CONSTRAINT pk_sampled_catch PRIMARY KEY (id);
	ALTER TABLE public.ref_vessels ADD CONSTRAINT ref_vessels_constraint1 PRIMARY KEY (vesselid);
	ALTER TABLE public.ref_vessel_types ADD CONSTRAINT ref_vessel_types_refvesseltypes_constraint1_ PRIMARY KEY (id);
	ALTER TABLE public.ref_units ADD CONSTRAINT pk_ref_units PRIMARY KEY (id);
	ALTER TABLE public.ref_strategy ADD CONSTRAINT ref_strategy_pk_ref_criteria PRIMARY KEY (id);
	ALTER TABLE public.ref_stocks ADD CONSTRAINT ref_stocks_refstocks_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_species ADD CONSTRAINT ref_species_refspecies_constraint1______ PRIMARY KEY (id);
	ALTER TABLE public.ref_source ADD CONSTRAINT pk_ref_source PRIMARY KEY (id);
	ALTER TABLE public.ref_sampling_technique ADD CONSTRAINT ref_sampling_technique_pk_ref_schema PRIMARY KEY (id);
	ALTER TABLE public.ref_samplers ADD CONSTRAINT pk_ref_samplers PRIMARY KEY (id);
	ALTER TABLE public.ref_sample_status ADD CONSTRAINT ref_sample_status_aaaaaref_logbook_status_pk PRIMARY KEY (id);
	ALTER TABLE public.ref_sample_origin ADD CONSTRAINT ref_sample_origin_aaaaaref_logbooks_origin_pk PRIMARY KEY (id);
	ALTER TABLE public.ref_ports ADD CONSTRAINT ref_ports_refports_constraint1_ PRIMARY KEY (id);
	ALTER TABLE public.ref_operational_statuses ADD CONSTRAINT ref_operational_statuses_refoperationalstatuses_constraint1_ PRIMARY KEY (id);
	ALTER TABLE public.ref_no_recording_activities ADD CONSTRAINT ref_no_recording_activities_reflogbooknareasons_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_months ADD CONSTRAINT ref_months_refmonths_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_minor_strata ADD CONSTRAINT ref_minor_strata_pk_minor_strata PRIMARY KEY (id);
	ALTER TABLE public.ref_marine_fishery_subsectors ADD CONSTRAINT ref_marine_fishery_subsectors_refmarinefisherysubsectors_constr PRIMARY KEY (id);
	ALTER TABLE public.ref_logbook_types ADD CONSTRAINT aaaaaref_logbook_types_pk PRIMARY KEY (id);
	ALTER TABLE public.ref_location ADD CONSTRAINT ref_location_pk_location PRIMARY KEY (id);
	ALTER TABLE public.ref_levels ADD CONSTRAINT ref_levels_pk_sampled_levels PRIMARY KEY (id);
	ALTER TABLE public.ref_landingsite_type ADD CONSTRAINT ref_landingsite_type_pk_ref_psu_detail_type PRIMARY KEY (id);
	ALTER TABLE public.ref_issuing_offices ADD CONSTRAINT ref_issuing_offices_refissuingoffices_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_group_of_landingsites ADD CONSTRAINT ref_group_of_landingsites_pk_group_of_landingsites PRIMARY KEY (id);
	ALTER TABLE public.ref_gears ADD CONSTRAINT ref_gears_refgears_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_gear_classes ADD CONSTRAINT ref_gear_classes_refgearclasses_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_frame ADD CONSTRAINT pk_ref_frame PRIMARY KEY (id);
	ALTER TABLE public.ref_fleet_segmentation ADD CONSTRAINT ref_fleet_segmentation_reffleetsegmentation_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_fishing_zones ADD CONSTRAINT ref_fishing_zones_reffishingzones_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_engine_locations ADD CONSTRAINT ref_engine_locations_refenginelocations_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_datetime_type ADD CONSTRAINT pk_ref_datetime_type PRIMARY KEY (id);
	ALTER TABLE public.ref_countries ADD CONSTRAINT ref_countries_refcountries_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_commercial_categories ADD CONSTRAINT ref_commercial_categories_refgroupofspecies_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_collectors ADD CONSTRAINT pk_ref_collectors PRIMARY KEY (id);
	ALTER TABLE public.ref_changes ADD CONSTRAINT ref_changes_refinactivityreasons_constraint1_ PRIMARY KEY (id);
	ALTER TABLE public.ref_authorisation_types ADD CONSTRAINT ref_authorisation_types_refauthorisationtypes_constraint1 PRIMARY KEY (id);
	ALTER TABLE public.ref_abstract_landingsite ADD CONSTRAINT ref_abstract_landingsite_pk_ref_psu_detail PRIMARY KEY (id);
	ALTER TABLE public.info_triggers ADD CONSTRAINT pk_info_triggers PRIMARY KEY (id);
	ALTER TABLE public.info_tables_import ADD CONSTRAINT info_tables_import_pk_cas_tables_import_1 PRIMARY KEY (id);
	ALTER TABLE public.info_tables ADD CONSTRAINT info_tables_pk_cas_tables PRIMARY KEY (id);
	ALTER TABLE public.info_fk ADD CONSTRAINT pk_info_fk PRIMARY KEY (id);
	ALTER TABLE public.info_fields ADD CONSTRAINT info_fields_pk_cas_fields PRIMARY KEY (id);
	ALTER TABLE public.info_changes ADD CONSTRAINT pk_info_changes PRIMARY KEY (id);
	ALTER TABLE public.gl_session ADD CONSTRAINT pk_gl_session PRIMARY KEY (id);
	ALTER TABLE public.gl_null_replacements ADD CONSTRAINT gl_null_replacements_pk_null_replacements PRIMARY KEY (id);
	ALTER TABLE public.gl_dates ADD CONSTRAINT gl_dates_pk_cas_dates PRIMARY KEY (id);
	ALTER TABLE public.fr_tree ADD CONSTRAINT fr_tree_pk_tree PRIMARY KEY (id);
	ALTER TABLE public.fr_time ADD CONSTRAINT fr_time_pk_fr_frame_time PRIMARY KEY (id);
	ALTER TABLE public.fr_sub_frame ADD CONSTRAINT pk_fr_sub_frame PRIMARY KEY (id);
	ALTER TABLE public.fr_node_description ADD CONSTRAINT fr_node_description_pk_ref_levels PRIMARY KEY (id);
	ALTER TABLE public.fr_gls2als ADD CONSTRAINT pk_fr_gls2als PRIMARY KEY (id);
	ALTER TABLE public.fr_frame ADD CONSTRAINT pk_fr_frame PRIMARY KEY (id);
	ALTER TABLE public.fr_f2gls ADD CONSTRAINT pk_fr_f2gls PRIMARY KEY (id);
	ALTER TABLE public.fr_als2vessel ADD CONSTRAINT pk_fr_als2vessel PRIMARY KEY (id);
	ALTER TABLE public.changes_perm_vessel ADD CONSTRAINT changes_perm_vessel_pk_perm_changes PRIMARY KEY (id);
	ALTER TABLE public.changes_perm_ls ADD CONSTRAINT changes_perm_ls_pk_ls_perm_changes PRIMARY KEY (id);
	ALTER TABLE public.changes_perm_gls ADD CONSTRAINT changes_perm_gls_pk_gls_perm_changes PRIMARY KEY (id);
	ALTER TABLE public.abstract_sampled_vessels ADD CONSTRAINT pk_abstract_sampled_vessels PRIMARY KEY (id);
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT abstract_changes_temp_vessel_pk_temp_changes PRIMARY KEY (id);
	ALTER TABLE public.ui_user ADD CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES ui_role(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.ui_rules ADD CONSTRAINT fk_ui_rules_ui_rule_types FOREIGN KEY (type) REFERENCES ui_rule_types(id) DEFERRABLE;
	ALTER TABLE public.ui_rules ADD CONSTRAINT fk_ui_rules_ui_forms FOREIGN KEY (form) REFERENCES ui_forms(id) DEFERRABLE;
	ALTER TABLE public.ui_rule_ptrs ADD CONSTRAINT fk_ui_rule_ptrs_ui_rules FOREIGN KEY (id_rules) REFERENCES ui_rules(id) DEFERRABLE;
	ALTER TABLE public.ui_rule_ptrs ADD CONSTRAINT fk_ui_rule_ptrs_ui_forms FOREIGN KEY (form) REFERENCES ui_forms(id) DEFERRABLE;
	ALTER TABLE public.sampled_strata_vessels ADD CONSTRAINT fk_sampled_strata_vessels_ref_minor_strata FOREIGN KEY (id_minor_strata) REFERENCES ref_minor_strata(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_levels ADD CONSTRAINT fk_sampled_levels_ref_sampling_technique FOREIGN KEY (id_sampling_technique) REFERENCES ref_sampling_technique(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_levels ADD CONSTRAINT fk_sampled_levels_ref_levels FOREIGN KEY (id_level) REFERENCES ref_levels(id) DEFERRABLE;
	ALTER TABLE public.sampled_levels ADD CONSTRAINT fk_sampled_levels_ref_criteria FOREIGN KEY (id_strategy) REFERENCES ref_strategy(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips_zones ADD CONSTRAINT fk_sampled_fishing_trip_zones_sampled_fishing_trips FOREIGN KEY (id_fishing_trip) REFERENCES sampled_fishing_trips(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips_zones ADD CONSTRAINT fk_sampled_fishing_trip_zones_ref_fishing_zones FOREIGN KEY (id_fishing_zone) REFERENCES ref_fishing_zones(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips_gears ADD CONSTRAINT fk_sampled_fishing_trips_gears_sampled_fishing_trips FOREIGN KEY (id_fishing_trip) REFERENCES sampled_fishing_trips(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips_gears ADD CONSTRAINT fk_sampled_fishing_trips_gears_ref_gears FOREIGN KEY (id_fishing_gear) REFERENCES ref_gears(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_sampled_fishing_trips_ref_units1 FOREIGN KEY (id_catch_no_boxes_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_sampled_fishing_trips_ref_units FOREIGN KEY (id_catch_units_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_sampled_fishing_trips_ref_samplers FOREIGN KEY (id_sampler) REFERENCES ref_samplers(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_sampled_fishing_trips_ref_abstract_landingsite FOREIGN KEY (id_abstract_landing_site) REFERENCES ref_abstract_landingsite(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_sampled_fishing_trips_gl_dates FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_sampled_fishing_trips_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_fishing_trips_ref_units FOREIGN KEY (id_catch_weight_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_trips ADD CONSTRAINT fk_fishing_trips_cell_vessels FOREIGN KEY (id_abstract_sampled_vessels) REFERENCES abstract_sampled_vessels(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations_categories ADD CONSTRAINT fk_sampled_fishing_operations_categories_sampled_fishing_operat FOREIGN KEY (id_fishing_operation) REFERENCES sampled_fishing_operations(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations_categories ADD CONSTRAINT fk_sampled_fishing_operations_categories_ref_commercial_categor FOREIGN KEY (id_commercial_category) REFERENCES ref_commercial_categories(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_ref_units2 FOREIGN KEY (id_catch_units_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_ref_units1 FOREIGN KEY (id_catch_no_boxes_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_ref_units FOREIGN KEY (id_catch_weight_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_ref_gears FOREIGN KEY (id_gear) REFERENCES ref_gears(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_ref_fishing_zones FOREIGN KEY (id_fishing_zone) REFERENCES ref_fishing_zones(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_cas_dates1 FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_sampled_fishing_operations_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.sampled_fishing_operations ADD CONSTRAINT fk_fishing_operation_fishing_trips FOREIGN KEY (id_fishing_trip) REFERENCES sampled_fishing_trips(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_cell_vessels ADD CONSTRAINT fk_cell_vessels_cell_vessel_types FOREIGN KEY (id_cell_vessel_types) REFERENCES sampled_cell_vessel_types(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_cell_vessel_types ADD CONSTRAINT fk_cell_vessel_types_ref_vessel_types FOREIGN KEY (id_vessel_type) REFERENCES ref_vessel_types(id) DEFERRABLE;
	ALTER TABLE public.sampled_cell_vessel_types ADD CONSTRAINT fk_cell_vessel_types_cell FOREIGN KEY (id_cell) REFERENCES sampled_cell(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_cell ADD CONSTRAINT fk_sampled_cell_gl_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.sampled_cell ADD CONSTRAINT fk_sampled_cell_cas_dates FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.sampled_cell ADD CONSTRAINT fk_cell_minor_strata FOREIGN KEY (id_minor_strata) REFERENCES ref_minor_strata(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_catch ADD CONSTRAINT fk_sampled_catch_sampled_fishing_operations FOREIGN KEY (id_fishing_operation) REFERENCES sampled_fishing_operations(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.sampled_catch ADD CONSTRAINT fk_sampled_catch_ref_units3 FOREIGN KEY (id_sample_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_catch ADD CONSTRAINT fk_sampled_catch_ref_units2 FOREIGN KEY (id_catch_weight_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_catch ADD CONSTRAINT fk_sampled_catch_ref_units1 FOREIGN KEY (id_catch_units_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_catch ADD CONSTRAINT fk_sampled_catch_ref_units FOREIGN KEY (id_catch_no_boxes_units) REFERENCES ref_units(id) DEFERRABLE;
	ALTER TABLE public.sampled_catch ADD CONSTRAINT fk_sampled_catch_ref_commercial_categories FOREIGN KEY (id_commercial_category) REFERENCES ref_commercial_categories(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_vessel_types FOREIGN KEY (vesseltype) REFERENCES ref_vessel_types(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_ports FOREIGN KEY (homeport) REFERENCES ref_ports(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_operational_statuses FOREIGN KEY (operationalstatus) REFERENCES ref_operational_statuses(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_issuing_offices FOREIGN KEY (issuingoffice) REFERENCES ref_issuing_offices(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_gears1 FOREIGN KEY (maingeartype) REFERENCES ref_gears(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_gears FOREIGN KEY (secondarygeartype) REFERENCES ref_gears(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_fleet_segmentation FOREIGN KEY (fleetsegment) REFERENCES ref_fleet_segmentation(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_engine_locations FOREIGN KEY (enginelocation) REFERENCES ref_engine_locations(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_countries1 FOREIGN KEY (flag) REFERENCES ref_countries(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_countries FOREIGN KEY (originalflag) REFERENCES ref_countries(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_commercial_categories1 FOREIGN KEY (maingeartargetgroupofspecies) REFERENCES ref_commercial_categories(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_commercial_categories FOREIGN KEY (secondarygeartargetgroupofspecies) REFERENCES ref_commercial_categories(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_changes FOREIGN KEY (nonoperationalreason) REFERENCES ref_changes(id) DEFERRABLE;
	ALTER TABLE public.ref_vessels ADD CONSTRAINT fk_ref_vessels_ref_authorisation_types FOREIGN KEY (authorisationtype) REFERENCES ref_authorisation_types(id) DEFERRABLE;
	ALTER TABLE public.ref_sampling_technique ADD CONSTRAINT fk_ref_sampling_technique_ref_strategy FOREIGN KEY (id_strategy) REFERENCES ref_strategy(id) DEFERRABLE;
	ALTER TABLE public.ref_sampling_technique ADD CONSTRAINT fk_ref_sampling_technique_fr_time FOREIGN KEY (id_fr_time) REFERENCES fr_time(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.ref_minor_strata ADD CONSTRAINT fk_minor_strata_ref_no_recording_activities FOREIGN KEY (id_no_recording_activity) REFERENCES ref_no_recording_activities(id) DEFERRABLE;
	ALTER TABLE public.ref_minor_strata ADD CONSTRAINT fk_minor_strata_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) DEFERRABLE;
	ALTER TABLE public.ref_minor_strata ADD CONSTRAINT fk_minor_strata_frame_time FOREIGN KEY (id_frame_time) REFERENCES fr_time(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.ref_minor_strata ADD CONSTRAINT fk_minor_strata_cas_dates1 FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.ref_minor_strata ADD CONSTRAINT fk_minor_strata_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.ref_location ADD CONSTRAINT fk_location_ref_countries FOREIGN KEY (country) REFERENCES ref_countries(id) DEFERRABLE;
	ALTER TABLE public.ref_gears ADD CONSTRAINT fk_refgears_refmarinefisherysubsectors FOREIGN KEY (marinefisherysubsector) REFERENCES ref_marine_fishery_subsectors(id) DEFERRABLE;
	ALTER TABLE public.ref_gears ADD CONSTRAINT fk_refgears_refgearclasses FOREIGN KEY (gearclass) REFERENCES ref_gear_classes(id) DEFERRABLE;
	ALTER TABLE public.ref_collectors ADD CONSTRAINT fk_ref_collectors_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;
	ALTER TABLE public.ref_abstract_landingsite ADD CONSTRAINT fk_cas_landingsite2psu_ref_ports FOREIGN KEY (id_port) REFERENCES ref_ports(id) DEFERRABLE;
	ALTER TABLE public.ref_abstract_landingsite ADD CONSTRAINT fk_cas_landingsite2psu_ref_collectors FOREIGN KEY (id_collector) REFERENCES ref_collectors(id) DEFERRABLE;
	ALTER TABLE public.ref_abstract_landingsite ADD CONSTRAINT fk_cas_landingsite2psu_cas_landingsite_type FOREIGN KEY (id_landingsite_type) REFERENCES ref_landingsite_type(id) DEFERRABLE;
	ALTER TABLE public.info_tables_import ADD CONSTRAINT fk_info_tables_import_info_tables FOREIGN KEY (imported_name) REFERENCES info_tables(name) DEFERRABLE;
	ALTER TABLE public.info_fields ADD CONSTRAINT fk_info_fields_info_tables1 FOREIGN KEY (table_name) REFERENCES info_tables(name) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.info_client ADD CONSTRAINT fk_info_client_info_changes FOREIGN KEY (client_id) REFERENCES info_changes(id) DEFERRABLE;
	ALTER TABLE public.info_changes ADD CONSTRAINT fk_info_changes_gl_session FOREIGN KEY (id_session) REFERENCES gl_session(id) DEFERRABLE;
	ALTER TABLE public.info_changes ADD CONSTRAINT fk_info_changes_gl_dates FOREIGN KEY (id_datetime) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.gl_session ADD CONSTRAINT fk_gl_session_ui_user FOREIGN KEY (id_user) REFERENCES ui_user(id) DEFERRABLE;
	ALTER TABLE public.gl_session ADD CONSTRAINT fk_gl_session_ref_local FOREIGN KEY (id_location) REFERENCES ref_location(id) DEFERRABLE;
	ALTER TABLE public.gl_session ADD CONSTRAINT fk_gl_session_gl_dates1 FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.gl_session ADD CONSTRAINT fk_gl_session_gl_dates FOREIGN KEY (id_base_date) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.gl_dates ADD CONSTRAINT fk_cas_dates_ref_datetime_type FOREIGN KEY (date_type) REFERENCES ref_datetime_type(id) DEFERRABLE;
	ALTER TABLE public.fr_tree ADD CONSTRAINT fk_tree_node_description FOREIGN KEY (id) REFERENCES fr_node_description(id) DEFERRABLE;
	ALTER TABLE public.fr_time ADD CONSTRAINT fk_frame_time_cas_dates1 FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.fr_time ADD CONSTRAINT fk_frame_time_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;
	ALTER TABLE public.fr_time ADD CONSTRAINT fk_fr_time_fr_frame FOREIGN KEY (id_frame) REFERENCES fr_frame(id) DEFERRABLE;
	ALTER TABLE public.fr_sub_frame ADD CONSTRAINT fk_fr_sub_frame_ref_frame FOREIGN KEY (type) REFERENCES ref_frame(id) DEFERRABLE;
	ALTER TABLE public.fr_sub_frame ADD CONSTRAINT fk_fr_sub_frame_fr_frame FOREIGN KEY (id_frame) REFERENCES fr_frame(id) DEFERRABLE;
	ALTER TABLE public.fr_gls2als ADD CONSTRAINT fk_gls2als_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_gls2als ADD CONSTRAINT fk_gls2als_abstract_landingsite FOREIGN KEY (id_abstract_landingsite) REFERENCES ref_abstract_landingsite(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_gls2als ADD CONSTRAINT fk_fr_gls2als_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_frame ADD CONSTRAINT fk_fr_frame_ref_source__ FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;
	ALTER TABLE public.fr_frame ADD CONSTRAINT fk_fr_frame_ref_source_ FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;
	ALTER TABLE public.fr_frame ADD CONSTRAINT fk_fr_frame_ref_source FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;
	ALTER TABLE public.fr_f2gls ADD CONSTRAINT fk_fr_f2gls_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_f2gls ADD CONSTRAINT fk_fr_f2gls_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_als2vessel ADD CONSTRAINT fk_fr_als2vessel_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_als2vessel ADD CONSTRAINT fk_fr_als2vessel_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.fr_als2vessel ADD CONSTRAINT fk_fr_als2vessel_abstract_landingsite FOREIGN KEY (id_abstract_landingsite) REFERENCES ref_abstract_landingsite(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.changes_perm_vessel ADD CONSTRAINT fk_vessel_perm_changes_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;
	ALTER TABLE public.changes_perm_vessel ADD CONSTRAINT fk_vessel_perm_changes_ref_changes FOREIGN KEY (id_ref_changes) REFERENCES ref_changes(id) DEFERRABLE;
	ALTER TABLE public.changes_perm_vessel ADD CONSTRAINT fk_vessel_perm_changes_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.changes_perm_ls ADD CONSTRAINT fk_ls_perm_changes_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.changes_perm_ls ADD CONSTRAINT fk_ls_perm_changes_abstract_landingsite FOREIGN KEY (id_abstract_landingsite) REFERENCES ref_abstract_landingsite(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.changes_perm_gls ADD CONSTRAINT fk_gls_perm_changes_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.changes_perm_gls ADD CONSTRAINT fk_gls_perm_changes_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;
	ALTER TABLE public.abstract_sampled_vessels ADD CONSTRAINT fk_abstract_sampled_vessels_ref_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;
	ALTER TABLE public.abstract_sampled_vessels ADD CONSTRAINT fk_abstract_sampled_vessels_ref_source FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;
	ALTER TABLE public.abstract_sampled_vessels ADD CONSTRAINT fk_abstract_sampled_vessels_ref_sample_status FOREIGN KEY (id_sample_status) REFERENCES ref_sample_status(id) DEFERRABLE;
	ALTER TABLE public.abstract_sampled_vessels ADD CONSTRAINT fk_abstract_sampled_vessels_ref_sample_origin FOREIGN KEY (id_sample_origin) REFERENCES ref_sample_origin(id) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_vessel_temp_changes_sampled_cell FOREIGN KEY (id_cell) REFERENCES sampled_cell(id) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_vessel_temp_changes_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_vessel_temp_changes_ref_changes FOREIGN KEY (id_ref_changes) REFERENCES ref_changes(id) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_vessel_temp_changes_abstract_landingsite1 FOREIGN KEY (to_ls) REFERENCES ref_abstract_landingsite(id) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_vessel_temp_changes_abstract_landingsite FOREIGN KEY (from_ls) REFERENCES ref_abstract_landingsite(id) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_abstract_changes_temp_vessel_ref_source FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;
	ALTER TABLE public.abstract_changes_temp_vessel ADD CONSTRAINT fk_abstract_changes_temp_vessel_ref_minor_strata FOREIGN KEY (id_minor_strata) REFERENCES ref_minor_strata(id) ON DELETE CASCADE DEFERRABLE;

  END;
  
$$;


ALTER FUNCTION public.create_all_constraints() OWNER TO postgres;

--
-- Name: create_trigger_all2(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_trigger_all2() RETURNS void
    LANGUAGE plpgsql
    AS $$



	DECLARE _string varchar ( 1000 ) ;
	DECLARE _table_name varchar ( 50 ); 
	DECLARE _column_name varchar(50) ;
	DECLARE r RECORD;

  BEGIN



	FOR r IN SELECT DISTINCT TABLE_NAME, FIELD_NAME from info_triggers  LOOP
  

		_string := 'select Create_Change_Triggers ('''  ||  cast(r.TABLE_NAME as varchar)  ||  ''',''' || cast(r.FIELD_NAME as varchar) || ''')';
		--raise info '%s', r.TABLE_NAME;
		raise info '%', _string;
		EXECUTE ( _string ) ; 
	
	 end loop;


	
  END;
  
 $$;


ALTER FUNCTION public.create_trigger_all2() OWNER TO postgres;

--
-- Name: displayrowcount(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION displayrowcount() RETURNS TABLE(a name, b name, c real)
    LANGUAGE plpgsql
    AS $$  
  BEGIN

	return QUERY 
		SELECT 
		  nspname AS schemaname,relname,reltuples
		FROM pg_class C
		LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
		WHERE 
		  nspname NOT IN ('pg_catalog', 'information_schema') AND
		  relkind='r' 
		ORDER BY reltuples DESC;
	
  END;
  $$;


ALTER FUNCTION public.displayrowcount() OWNER TO postgres;

--
-- Name: drop_all_constraints(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION drop_all_constraints() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN

	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_abstract_changes_temp_vessel_ref_minor_strata;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_abstract_changes_temp_vessel_ref_source;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_abstract_landingsite;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_abstract_landingsite1;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_ref_changes;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_reg_vessels;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT fk_vessel_temp_changes_sampled_cell;
	ALTER TABLE public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_sample_origin;
	ALTER TABLE public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_sample_status;
	ALTER TABLE public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_source;
	ALTER TABLE public.abstract_sampled_vessels DROP CONSTRAINT fk_abstract_sampled_vessels_ref_vessels;
	ALTER TABLE public.changes_perm_gls DROP CONSTRAINT fk_gls_perm_changes_fr_frame;
	ALTER TABLE public.changes_perm_gls DROP CONSTRAINT fk_gls_perm_changes_group_of_landingsites;
	ALTER TABLE public.changes_perm_ls DROP CONSTRAINT fk_ls_perm_changes_abstract_landingsite;
	ALTER TABLE public.changes_perm_ls DROP CONSTRAINT fk_ls_perm_changes_fr_frame;
	ALTER TABLE public.changes_perm_vessel DROP CONSTRAINT fk_vessel_perm_changes_fr_frame;
	ALTER TABLE public.changes_perm_vessel DROP CONSTRAINT fk_vessel_perm_changes_ref_changes;
	ALTER TABLE public.changes_perm_vessel DROP CONSTRAINT fk_vessel_perm_changes_reg_vessels;
	ALTER TABLE public.fr_als2vessel DROP CONSTRAINT fk_fr_als2vessel_abstract_landingsite;
	ALTER TABLE public.fr_als2vessel DROP CONSTRAINT fk_fr_als2vessel_fr_frame;
	ALTER TABLE public.fr_als2vessel DROP CONSTRAINT fk_fr_als2vessel_reg_vessels;
	ALTER TABLE public.fr_f2gls DROP CONSTRAINT fk_fr_f2gls_fr_frame;
	ALTER TABLE public.fr_f2gls DROP CONSTRAINT fk_fr_f2gls_group_of_landingsites;
	ALTER TABLE public.fr_frame DROP CONSTRAINT fk_fr_frame_ref_source;
	ALTER TABLE public.fr_frame DROP CONSTRAINT fk_fr_frame_ref_source_;
	ALTER TABLE public.fr_frame DROP CONSTRAINT fk_fr_frame_ref_source__;
	ALTER TABLE public.fr_gls2als DROP CONSTRAINT fk_fr_gls2als_fr_frame;
	ALTER TABLE public.fr_gls2als DROP CONSTRAINT fk_gls2als_abstract_landingsite;
	ALTER TABLE public.fr_gls2als DROP CONSTRAINT fk_gls2als_group_of_landingsites;
	ALTER TABLE public.fr_sub_frame DROP CONSTRAINT fk_fr_sub_frame_fr_frame;
	ALTER TABLE public.fr_sub_frame DROP CONSTRAINT fk_fr_sub_frame_ref_frame;
	ALTER TABLE public.fr_time DROP CONSTRAINT fk_fr_time_fr_frame;
	ALTER TABLE public.fr_time DROP CONSTRAINT fk_frame_time_cas_dates;
	ALTER TABLE public.fr_time DROP CONSTRAINT fk_frame_time_cas_dates1;
	ALTER TABLE public.fr_tree DROP CONSTRAINT fk_tree_node_description;
	ALTER TABLE public.gl_dates DROP CONSTRAINT fk_cas_dates_ref_datetime_type;
	ALTER TABLE public.gl_session DROP CONSTRAINT fk_gl_session_gl_dates;
	ALTER TABLE public.gl_session DROP CONSTRAINT fk_gl_session_gl_dates1;
	ALTER TABLE public.gl_session DROP CONSTRAINT fk_gl_session_ref_local;
	ALTER TABLE public.gl_session DROP CONSTRAINT fk_gl_session_ui_user;
	ALTER TABLE public.info_changes DROP CONSTRAINT fk_info_changes_gl_dates;
	ALTER TABLE public.info_changes DROP CONSTRAINT fk_info_changes_gl_session;
	ALTER TABLE public.info_client DROP CONSTRAINT fk_info_client_info_changes;
	ALTER TABLE public.info_fields DROP CONSTRAINT fk_info_fields_info_tables1;
	ALTER TABLE public.info_tables_import DROP CONSTRAINT fk_info_tables_import_info_tables;
	ALTER TABLE public.ref_abstract_landingsite DROP CONSTRAINT fk_cas_landingsite2psu_cas_landingsite_type;
	ALTER TABLE public.ref_abstract_landingsite DROP CONSTRAINT fk_cas_landingsite2psu_ref_collectors;
	ALTER TABLE public.ref_abstract_landingsite DROP CONSTRAINT fk_cas_landingsite2psu_ref_ports;
	ALTER TABLE public.ref_collectors DROP CONSTRAINT fk_ref_collectors_reg_vessels;
	ALTER TABLE public.ref_gears DROP CONSTRAINT fk_refgears_refgearclasses;
	ALTER TABLE public.ref_gears DROP CONSTRAINT fk_refgears_refmarinefisherysubsectors;
	ALTER TABLE public.ref_location DROP CONSTRAINT fk_location_ref_countries;
	ALTER TABLE public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_cas_dates;
	ALTER TABLE public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_cas_dates1;
	ALTER TABLE public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_frame_time;
	ALTER TABLE public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_group_of_landingsites;
	ALTER TABLE public.ref_minor_strata DROP CONSTRAINT fk_minor_strata_ref_no_recording_activities;
	ALTER TABLE public.ref_sampling_technique DROP CONSTRAINT fk_ref_sampling_technique_fr_time;
	ALTER TABLE public.ref_sampling_technique DROP CONSTRAINT fk_ref_sampling_technique_ref_strategy;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_authorisation_types;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_changes;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_commercial_categories;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_commercial_categories1;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_countries;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_countries1;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_engine_locations;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_fleet_segmentation;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_gears;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_gears1;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_issuing_offices;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_operational_statuses;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_ports;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT fk_ref_vessels_ref_vessel_types;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_commercial_categories;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units1;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units2;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT fk_sampled_catch_ref_units3;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT fk_sampled_catch_sampled_fishing_operations;
	ALTER TABLE public.sampled_cell DROP CONSTRAINT fk_cell_minor_strata;
	ALTER TABLE public.sampled_cell DROP CONSTRAINT fk_sampled_cell_cas_dates;
	ALTER TABLE public.sampled_cell DROP CONSTRAINT fk_sampled_cell_gl_dates;
	ALTER TABLE public.sampled_cell_vessel_types DROP CONSTRAINT fk_cell_vessel_types_cell;
	ALTER TABLE public.sampled_cell_vessel_types DROP CONSTRAINT fk_cell_vessel_types_ref_vessel_types;
	ALTER TABLE public.sampled_cell_vessels DROP CONSTRAINT fk_cell_vessels_cell_vessel_types;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_fishing_operation_fishing_trips;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_cas_dates;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_cas_dates1;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_fishing_zones;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_gears;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_units;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_units1;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT fk_sampled_fishing_operations_ref_units2;
	ALTER TABLE public.sampled_fishing_operations_categories DROP CONSTRAINT fk_sampled_fishing_operations_categories_ref_commercial_categor;
	ALTER TABLE public.sampled_fishing_operations_categories DROP CONSTRAINT fk_sampled_fishing_operations_categories_sampled_fishing_operat;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_fishing_trips_cell_vessels;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_fishing_trips_ref_units;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_cas_dates;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_gl_dates;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_abstract_landingsite;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_samplers;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_units;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT fk_sampled_fishing_trips_ref_units1;
	ALTER TABLE public.sampled_fishing_trips_gears DROP CONSTRAINT fk_sampled_fishing_trips_gears_ref_gears;
	ALTER TABLE public.sampled_fishing_trips_gears DROP CONSTRAINT fk_sampled_fishing_trips_gears_sampled_fishing_trips;
	ALTER TABLE public.sampled_fishing_trips_zones DROP CONSTRAINT fk_sampled_fishing_trip_zones_ref_fishing_zones;
	ALTER TABLE public.sampled_fishing_trips_zones DROP CONSTRAINT fk_sampled_fishing_trip_zones_sampled_fishing_trips;
	ALTER TABLE public.sampled_levels DROP CONSTRAINT fk_sampled_levels_ref_criteria;
	ALTER TABLE public.sampled_levels DROP CONSTRAINT fk_sampled_levels_ref_levels;
	ALTER TABLE public.sampled_levels DROP CONSTRAINT fk_sampled_levels_ref_sampling_technique;
	ALTER TABLE public.sampled_strata_vessels DROP CONSTRAINT fk_sampled_strata_vessels_ref_minor_strata;
	ALTER TABLE public.ui_rule_ptrs DROP CONSTRAINT fk_ui_rule_ptrs_ui_forms;
	ALTER TABLE public.ui_rule_ptrs DROP CONSTRAINT fk_ui_rule_ptrs_ui_rules;
	ALTER TABLE public.ui_rules DROP CONSTRAINT fk_ui_rules_ui_forms;
	ALTER TABLE public.ui_rules DROP CONSTRAINT fk_ui_rules_ui_rule_types;
	ALTER TABLE public.ui_user DROP CONSTRAINT fk_user_role;
	ALTER TABLE public.abstract_changes_temp_vessel DROP CONSTRAINT abstract_changes_temp_vessel_pk_temp_changes;
	ALTER TABLE public.abstract_sampled_vessels DROP CONSTRAINT pk_abstract_sampled_vessels;
	ALTER TABLE public.changes_perm_gls DROP CONSTRAINT changes_perm_gls_pk_gls_perm_changes;
	ALTER TABLE public.changes_perm_ls DROP CONSTRAINT changes_perm_ls_pk_ls_perm_changes;
	ALTER TABLE public.changes_perm_vessel DROP CONSTRAINT changes_perm_vessel_pk_perm_changes;
	ALTER TABLE public.fr_als2vessel DROP CONSTRAINT pk_fr_als2vessel;
	ALTER TABLE public.fr_f2gls DROP CONSTRAINT pk_fr_f2gls;
	ALTER TABLE public.fr_frame DROP CONSTRAINT pk_fr_frame;
	ALTER TABLE public.fr_gls2als DROP CONSTRAINT pk_fr_gls2als;
	ALTER TABLE public.fr_node_description DROP CONSTRAINT fr_node_description_pk_ref_levels;
	ALTER TABLE public.fr_sub_frame DROP CONSTRAINT pk_fr_sub_frame;
	ALTER TABLE public.fr_time DROP CONSTRAINT fr_time_pk_fr_frame_time;
	ALTER TABLE public.fr_tree DROP CONSTRAINT fr_tree_pk_tree;
	ALTER TABLE public.gl_dates DROP CONSTRAINT gl_dates_pk_cas_dates;
	ALTER TABLE public.gl_null_replacements DROP CONSTRAINT gl_null_replacements_pk_null_replacements;
	ALTER TABLE public.gl_session DROP CONSTRAINT pk_gl_session;
	ALTER TABLE public.info_changes DROP CONSTRAINT pk_info_changes;
	ALTER TABLE public.info_fields DROP CONSTRAINT info_fields_pk_cas_fields;
	ALTER TABLE public.info_fk DROP CONSTRAINT pk_info_fk;
	ALTER TABLE public.info_tables DROP CONSTRAINT info_tables_pk_cas_tables;
	ALTER TABLE public.info_tables_import DROP CONSTRAINT info_tables_import_pk_cas_tables_import_1;
	ALTER TABLE public.info_triggers DROP CONSTRAINT pk_info_triggers;
	ALTER TABLE public.ref_abstract_landingsite DROP CONSTRAINT ref_abstract_landingsite_pk_ref_psu_detail;
	ALTER TABLE public.ref_authorisation_types DROP CONSTRAINT ref_authorisation_types_refauthorisationtypes_constraint1;
	ALTER TABLE public.ref_changes DROP CONSTRAINT ref_changes_refinactivityreasons_constraint1_;
	ALTER TABLE public.ref_collectors DROP CONSTRAINT pk_ref_collectors;
	ALTER TABLE public.ref_commercial_categories DROP CONSTRAINT ref_commercial_categories_refgroupofspecies_constraint1;
	ALTER TABLE public.ref_countries DROP CONSTRAINT ref_countries_refcountries_constraint1;
	ALTER TABLE public.ref_datetime_type DROP CONSTRAINT pk_ref_datetime_type;
	ALTER TABLE public.ref_engine_locations DROP CONSTRAINT ref_engine_locations_refenginelocations_constraint1;
	ALTER TABLE public.ref_fishing_zones DROP CONSTRAINT ref_fishing_zones_reffishingzones_constraint1;
	ALTER TABLE public.ref_fleet_segmentation DROP CONSTRAINT ref_fleet_segmentation_reffleetsegmentation_constraint1;
	ALTER TABLE public.ref_frame DROP CONSTRAINT pk_ref_frame;
	ALTER TABLE public.ref_gear_classes DROP CONSTRAINT ref_gear_classes_refgearclasses_constraint1;
	ALTER TABLE public.ref_gears DROP CONSTRAINT ref_gears_refgears_constraint1;
	ALTER TABLE public.ref_group_of_landingsites DROP CONSTRAINT ref_group_of_landingsites_pk_group_of_landingsites;
	ALTER TABLE public.ref_issuing_offices DROP CONSTRAINT ref_issuing_offices_refissuingoffices_constraint1;
	ALTER TABLE public.ref_landingsite_type DROP CONSTRAINT ref_landingsite_type_pk_ref_psu_detail_type;
	ALTER TABLE public.ref_levels DROP CONSTRAINT ref_levels_pk_sampled_levels;
	ALTER TABLE public.ref_location DROP CONSTRAINT ref_location_pk_location;
	ALTER TABLE public.ref_logbook_types DROP CONSTRAINT aaaaaref_logbook_types_pk;
	ALTER TABLE public.ref_marine_fishery_subsectors DROP CONSTRAINT ref_marine_fishery_subsectors_refmarinefisherysubsectors_constr;
	ALTER TABLE public.ref_minor_strata DROP CONSTRAINT ref_minor_strata_pk_minor_strata;
	ALTER TABLE public.ref_months DROP CONSTRAINT ref_months_refmonths_constraint1;
	ALTER TABLE public.ref_no_recording_activities DROP CONSTRAINT ref_no_recording_activities_reflogbooknareasons_constraint1;
	ALTER TABLE public.ref_operational_statuses DROP CONSTRAINT ref_operational_statuses_refoperationalstatuses_constraint1_;
	ALTER TABLE public.ref_ports DROP CONSTRAINT ref_ports_refports_constraint1_;
	ALTER TABLE public.ref_sample_origin DROP CONSTRAINT ref_sample_origin_aaaaaref_logbooks_origin_pk;
	ALTER TABLE public.ref_sample_status DROP CONSTRAINT ref_sample_status_aaaaaref_logbook_status_pk;
	ALTER TABLE public.ref_samplers DROP CONSTRAINT pk_ref_samplers;
	ALTER TABLE public.ref_sampling_technique DROP CONSTRAINT ref_sampling_technique_pk_ref_schema;
	ALTER TABLE public.ref_source DROP CONSTRAINT pk_ref_source;
	ALTER TABLE public.ref_species DROP CONSTRAINT ref_species_refspecies_constraint1______;
	ALTER TABLE public.ref_stocks DROP CONSTRAINT ref_stocks_refstocks_constraint1;
	ALTER TABLE public.ref_strategy DROP CONSTRAINT ref_strategy_pk_ref_criteria;
	ALTER TABLE public.ref_units DROP CONSTRAINT pk_ref_units;
	ALTER TABLE public.ref_vessel_types DROP CONSTRAINT ref_vessel_types_refvesseltypes_constraint1_;
	ALTER TABLE public.ref_vessels DROP CONSTRAINT ref_vessels_constraint1;
	ALTER TABLE public.sampled_catch DROP CONSTRAINT pk_sampled_catch;
	ALTER TABLE public.sampled_cell DROP CONSTRAINT sampled_cell_pk_cell;
	ALTER TABLE public.sampled_cell_vessel_types DROP CONSTRAINT sampled_cell_vessel_types_pk_cell_vessel_types;
	ALTER TABLE public.sampled_cell_vessels DROP CONSTRAINT sampled_cell_vessels_pk_cell_vessels;
	ALTER TABLE public.sampled_fishing_operations DROP CONSTRAINT sampled_fishing_operations_pk_fishing_operation;
	ALTER TABLE public.sampled_fishing_operations_categories DROP CONSTRAINT pk_sampled_fishing_operations_categories;
	ALTER TABLE public.sampled_fishing_trips DROP CONSTRAINT sampled_fishing_trips_pk_fishing_trips;
	ALTER TABLE public.sampled_fishing_trips_gears DROP CONSTRAINT pk_sampled_fishing_trips_gears;
	ALTER TABLE public.sampled_fishing_trips_zones DROP CONSTRAINT sampled_fishing_trips_zones_pk_sampled_fishing_trip_zones;
	ALTER TABLE public.sampled_levels DROP CONSTRAINT pk_sampled_levels_1;
	ALTER TABLE public.sampled_strata_vessels DROP CONSTRAINT pk_sampled_strata_vessels;
	ALTER TABLE public.ui_boolean_mapping DROP CONSTRAINT pk_ui_boolean_mapping;
	ALTER TABLE public.ui_forms DROP CONSTRAINT pk_ui_forms;
	ALTER TABLE public.ui_role DROP CONSTRAINT ui_role_pk_role;
	ALTER TABLE public.ui_rule_ptrs DROP CONSTRAINT ui_rule_ptrs_pk_ui_pre_triggers_ptrs_1;
	ALTER TABLE public.ui_rule_types DROP CONSTRAINT pk_ui_rule_types;
	ALTER TABLE public.ui_rules DROP CONSTRAINT pk_ui_rules;
	ALTER TABLE public.ui_user DROP CONSTRAINT ui_user_pk_user;

	
  END;
  
$$;


ALTER FUNCTION public.drop_all_constraints() OWNER TO postgres;

--
-- Name: drop_all_triggers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION drop_all_triggers() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$ DECLARE
    triggNameRecord RECORD;
    triggTableRecord RECORD;
BEGIN
    FOR triggNameRecord IN select distinct(trigger_name) from information_schema.triggers where trigger_schema = 'public' LOOP
        FOR triggTableRecord IN SELECT distinct(event_object_table) from information_schema.triggers where trigger_name = triggNameRecord.trigger_name LOOP
            RAISE NOTICE 'Dropping trigger: % on table: %', triggNameRecord.trigger_name, triggTableRecord.event_object_table;
            EXECUTE 'DROP TRIGGER ' || triggNameRecord.trigger_name || ' ON ' || triggTableRecord.event_object_table || ';';
        END LOOP;
    END LOOP;

    RETURN 'done';
END;
$$;


ALTER FUNCTION public.drop_all_triggers() OWNER TO postgres;

--
-- Name: drop_id_session_all(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION drop_id_session_all() RETURNS void
    LANGUAGE plpgsql
    AS $$  
DECLARE
	--_name varchar ( 50 ) ;
	_string varchar ( 1000 );
	_fk varchar ( 100 ) ;
	r record;
	_Command varchar ( 1000 );
  BEGIN
	FOR r IN SELECT distinct tablename FROM pg_catalog.pg_tables where schemaname='public'
	and tablename not like 'info_%' and tablename not like 'ui_%' and tablename not like 'gl_%'   LOOP

-- drop fk references to this table
		--raise info '%s', r.tablename;
		_fk := 'fk_' || r.tablename || '_gl_session';
		IF EXISTS ( SELECT *
			FROM information_schema.constraint_table_usage
			where constraint_name like _fk) 
		then 
			_string := 'ALTER TABLE  ' || r.tablename || ' DROP CONSTRAINT  ' || _fk ;
			raise info '%', _string ; 
			perform ( _string ) ; 
		end if ;

	end loop;


-- TODO: port this later? Drop default constraints

	--declare @Command  nvarchar(1000)

	--select @Command = 'ALTER TABLE ' + @name + ' drop constraint ' + d.name
	 --from sys.tables t   
	  --join    sys.default_constraints d       
	   --on d.parent_object_id = t.object_id  
	  --join    sys.columns c      
	   --on c.object_id = t.object_id      
		--and c.column_id = d.parent_column_id
	 --where t.name = @name
	  --and c.name = 'id_session'
	  
	--execute (@Command)


if exists ( 
SELECT column_name            
		FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' and table_name like r.tablename and COLUMN_NAME='id_session' )
	THEN
		_string :='ALTER TABLE ' || r.tablename || ' drop COLUMN [id_session]';
		PERFORM (_string);
	END IF;

  END;
  
  $$;


ALTER FUNCTION public.drop_id_session_all() OWNER TO postgres;

--
-- Name: dropafteruptriggers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropafteruptriggers() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$ DECLARE
    triggNameRecord RECORD;
    triggTableRecord RECORD;
BEGIN
    FOR triggNameRecord IN select distinct(trigger_name) from information_schema.triggers where trigger_schema = 'public' AND trigger_name like '%_up_%' LOOP
        FOR triggTableRecord IN SELECT distinct(event_object_table) from information_schema.triggers where trigger_name = triggNameRecord.trigger_name LOOP
            RAISE NOTICE 'Dropping trigger: % on table: %', triggNameRecord.trigger_name, triggTableRecord.event_object_table;
            EXECUTE 'DROP TRIGGER ' || triggNameRecord.trigger_name || ' ON ' || triggTableRecord.event_object_table || ';';
        END LOOP;
    END LOOP;

    RETURN 'done';
END;
$$;


ALTER FUNCTION public.dropafteruptriggers() OWNER TO postgres;

--
-- Name: dropdeltriggers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropdeltriggers() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$ DECLARE
    triggNameRecord RECORD;
    triggTableRecord RECORD;
BEGIN
    FOR triggNameRecord IN select distinct(trigger_name) from information_schema.triggers where trigger_schema = 'public' AND trigger_name like '%_del_%' LOOP
        FOR triggTableRecord IN SELECT distinct(event_object_table) from information_schema.triggers where trigger_name = triggNameRecord.trigger_name LOOP
            RAISE NOTICE 'Dropping trigger: % on table: %', triggNameRecord.trigger_name, triggTableRecord.event_object_table;
            EXECUTE 'DROP TRIGGER ' || triggNameRecord.trigger_name || ' ON ' || triggTableRecord.event_object_table || ';';
        END LOOP;
    END LOOP;

    RETURN 'done';
END;
$$;


ALTER FUNCTION public.dropdeltriggers() OWNER TO postgres;

--
-- Name: dropinstriggers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropinstriggers() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$ DECLARE
    triggNameRecord RECORD;
    triggTableRecord RECORD;
BEGIN
    FOR triggNameRecord IN select distinct(trigger_name) from information_schema.triggers where trigger_schema = 'public' AND trigger_name like '%_ins_%' LOOP
        FOR triggTableRecord IN SELECT distinct(event_object_table) from information_schema.triggers where trigger_name = triggNameRecord.trigger_name LOOP
            RAISE NOTICE 'Dropping trigger: % on table: %', triggNameRecord.trigger_name, triggTableRecord.event_object_table;
            EXECUTE 'DROP TRIGGER ' || triggNameRecord.trigger_name || ' ON ' || triggTableRecord.event_object_table || ';';
        END LOOP;
    END LOOP;

    RETURN 'done';
END;
$$;


ALTER FUNCTION public.dropinstriggers() OWNER TO postgres;

--
-- Name: gen_info_tables(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION gen_info_tables() RETURNS void
    LANGUAGE plpgsql
    AS $$  
DECLARE 
	--_name varchar ( 50 ) ;
	_string varchar ( 150 ) ;	
	r RECORD;	
  BEGIN

-- first remove the fk constraint
 IF EXISTS ( SELECT table_name,constraint_name
             FROM information_schema.constraint_table_usage
             where constraint_name like 'fk_info_tables_import_info_tables' and table_name like 'info_tables' ) then 
		begin 
			alter table Info_Tables_Import 
			DROP CONSTRAINT FK_Info_Tables_Import_Info_Tables ;

		 end;
  end if;



-- remove records and reset serial
 if ( select count ( ID ) from info_tables ) >0 
	then 
		--raise info '%', 'delete all' ;
		delete from info_tables ;
		perform reset_table ( 'info_tables' ) ;
	else
		raise info '%', 'empty table' ;
	end if ; 


FOR r IN SELECT tablename FROM pg_catalog.pg_tables where schemaname='public' order by tablename ASC Loop
begin
	_string:= 'insert into info_tables ( name ) values ( '''|| cast(r.tablename as varchar) || ''')';
	--raise info '%', _string ; 
	EXECUTE (_string); 	  
end;
end loop;


-- put the fk back
ALTER table info_tables_import add constraint fk_info_tables_import_info_tables FOREIGN KEY ( imported_name ) REFERENCES Info_Tables ( "name" ) ;



  END;
  $$;


ALTER FUNCTION public.gen_info_tables() OWNER TO postgres;

--
-- Name: gettablexml(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION gettablexml(_name character varying) RETURNS record
    LANGUAGE plpgsql
    AS $$  
 DECLARE 
	--_name varchar ( 50 ) = _p_name ;
	_q varchar ( 1000 ); 
	_xmlstr varchar ;
	r RECORD;
  BEGIN
	_xmlstr := 'select table_to_xml(''' || _name || ''',false,true,'''')::text'; 
	raise info '%', _xmlstr;
	
	EXECUTE (_xmlstr) into r;
	return r;
	


  END;
  $$;


ALTER FUNCTION public.gettablexml(_name character varying) OWNER TO postgres;

--
-- Name: initializenestedmodel(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION initializenestedmodel() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  DECLARE
   _start int ;
   _string varchar ( 500 ) ;
   _id varchar(15);   
  BEGIN

	DELETE from fr_tree;
	DELETE from ref_levels;

	_string:='ALTER SEQUENCE  fr_tree__id_seq RESTART WITH -1';
	EXECUTE (_string);
	_string:='ALTER SEQUENCE  ref_levels_id_seq RESTART WITH -1';
	EXECUTE (_string);
	
	INSERT INTO ref_levels SELECT name , name_eng , description FROM ref_levels_copy;
	INSERT INTO fr_tree SELECT lft , rgt , parent , depth FROM tree_copy;

  END;
  $$;


ALTER FUNCTION public.initializenestedmodel() OWNER TO postgres;

--
-- Name: list2nested(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION list2nested() RETURNS void
    LANGUAGE plpgsql
    AS $$
  BEGIN


	CREATE TABLE treecopy 
	( id smallint NOT NULL 
	, parent smallint ) ; 

	INSERT INTO treecopy 
	SELECT id , parent FROM fr_tree ; 


	UPDATE treecopy SET parent = NULL WHERE parent = - 1 

	; CREATE TABLE stack 
	( stack_top INTEGER NOT NULL 
	, id smallint NOT NULL 
	, lft INTEGER 
	, rgt INTEGER ) ; 

	DECLARE _counter INT ; begin 
	DECLARE _max_counter INT ; begin 
	DECLARE _current_top INT ; begin 
	
	_counter := 2 ; 
	_max_counter := 2 * ( SELECT COUNT ( * ) FROM treecopy ) ; 
	_current_top := 1 ; 

	DELETE FROM stack ; 

	INSERT INTO stack 
	SELECT 1 , id , 1 
	, _max_counter FROM treecopy 
	WHERE parent IS NULL ; 

	DELETE FROM treecopy 
	WHERE parent IS NULL ; 

	WHILE _counter <= _max_counter-1 loop 

	IF EXISTS ( SELECT * 
	FROM stack AS S1 , treecopy AS T1 
	WHERE S1.id = T1.parent 
	AND S1.stack_top = _current_top ) 
	then 
		begin
		  INSERT INTO stack 
			SELECT ( _current_top + 1 ) , MIN ( T1.id ) , _counter , CAST ( NULL AS INT ) 
			FROM stack AS S1 , treecopy AS T1 
			WHERE S1.id = T1.parent 
			AND S1.stack_top = _current_top ; 
			
		  DELETE FROM treecopy
			WHERE id = ( SELECT id 
			FROM stack 
			WHERE stack_top = _current_top + 1 ) ; 
		 _counter := _counter + 1 ; 	
		 _current_top := _current_top + 1 ; 
		END; 
	ELSE 
		begin
			UPDATE stack 
			SET rgt = _counter 
			, stack_top = - stack_top 
			WHERE stack_top = _current_top 
			; _counter := _counter + 1 ; 
			_current_top := _current_top - 1 ; 
		END ;
	end if ;

	END loop;

	-- Update FR_Tree

	update fr_tree SET lft = ( SELECT lft from stack WHERE stack.id = fr_tree.id ) 
	, rgt = ( select rgt from stack WHERE stack.id = fr_tree.id ) ; 

	DROP TABLE treecopy ;

	DROP TABLE stack ;


	end; end; end;
  END;
  
  $$;


ALTER FUNCTION public.list2nested() OWNER TO postgres;

--
-- Name: nested2adjacency(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION nested2adjacency(_p_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$  
  DECLARE
	_id int = _p_id ;
  BEGIN
	PERFORM 'SELECT * FROM fr_tree hc JOIN fr_tree hp ON hc.lft BETWEEN hp.lft AND hp.rgt 
		WHERE hc.id = _id AND hp.id != _id ORDER BY hp.lft DESC ';

  END;
  $$;


ALTER FUNCTION public.nested2adjacency(_p_id integer) OWNER TO postgres;

--
-- Name: remove_fields_from_unused_tables(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION remove_fields_from_unused_tables() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN

DELETE from Info_Fields 
WHERE table_name NOT IN 
( 
	SELECT distinct table_name             
		FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' 	
		order by 1 ASC

);

  END;
  $$;


ALTER FUNCTION public.remove_fields_from_unused_tables() OWNER TO postgres;

--
-- Name: renameanddrop(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION renameanddrop(_name character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN


IF EXISTS (SELECT distinct tablename FROM pg_catalog.pg_tables where schemaname='public' and tablename like _name)
then 
	raise info '%s', 'T already.'; 
	DROP TABLE IF EXISTS T_old ; 
	ALTER TABLE _name RENAME TO T_old;
ELSE 
	raise info '%s', 'No T already.' ;
end if ;

  END;
  $$;


ALTER FUNCTION public.renameanddrop(_name character varying) OWNER TO postgres;

--
-- Name: reset_all_tables(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION reset_all_tables() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  DECLARE
   _start int ;
   _string varchar ( 500 ) ;
   _id varchar(15);
   r record;
  BEGIN

	FOR r IN SELECT distinct table_name FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' LOOP

		if (r.table_name not like 't_distribution') then
			if r.table_name like 'ref_vessels' then
				_id='vesselid';
			else
				_id='id';
			end if;
			
			
			_string := 'select ' || _id || ' from ' || r.table_name || ' ORDER BY ' || _id || ' DESC LIMIT 1' ;
			--raise info '%', _string;
			DROP TABLE IF EXISTS T1;
			CREATE TEMPORARY TABLE T1 ( Col1 int ) ; 
			EXECUTE 'insert into T1 ' ||   _string ;
			_start:= ( select * FROM T1 ) ;
			if ( _start IS NULL ) 
				then _start := 1 ;
			end if ; 
			raise info '%', _start ; 

			EXECUTE 'ALTER SEQUENCE ' || r.table_name || '_' || _id || '_seq RESTART WITH ' || _start;
			--raise info '%', 'ALTER SEQUENCE ' || r.table_name || '_' || _id || '_seq RESTART WITH ' || _start;

		
		end if;

     END LOOP;
	
  END;
  
$$;


ALTER FUNCTION public.reset_all_tables() OWNER TO postgres;

--
-- Name: reset_changes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION reset_changes() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN

	-- OBSOLETE CLAUSULE TO CHECK IF IT IS A MASTER DATABASE
	 if ( NOT EXISTS ( SELECT distinct table_name FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and table_name like 'master' and is_updatable like 'YES' ) )
	 then 
			delete from info_client ; 
			delete from info_master ; 
			--raise info '%', 'delete stuff';
	end if ;



	delete from info_changes where "table" != 'n/a' ;
	--raise info '%', 'ok: changes removed' ;
	
  END;
  
$$;


ALTER FUNCTION public.reset_changes() OWNER TO postgres;

--
-- Name: reset_table(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION reset_table(_table character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$  
  DECLARE
   _start int ;
   _string varchar ( 500 ) ;
   _id varchar(15);   
  BEGIN


		if (_table not like 't_distribution') then
			if _table like 'ref_vessels' then
				_id='vesselid';
			else
				_id='id';
			end if;
			
			
			_string := 'select ' || _id || ' from ' || _table || ' ORDER BY ' || _id || ' DESC LIMIT 1' ;
			--raise info '%', _string;
			DROP TABLE IF EXISTS T1;
			CREATE TEMPORARY TABLE T1 ( Col1 int ) ; 
			EXECUTE 'insert into T1 ' ||   _string ;
			_start:= ( select * FROM T1 ) ;
			if ( _start IS NULL ) 
				then _start := 1 ;
			end if ; 
			raise info '%', _start ; 

			EXECUTE 'ALTER SEQUENCE ' || r.table_name || '_' || _id || '_seq RESTART WITH ' || _start;
			--raise info '%', 'ALTER SEQUENCE ' || _table || '_' || _id || '_seq RESTART WITH ' || _start;

		
		end if;


  END;
  $$;


ALTER FUNCTION public.reset_table(_table character varying) OWNER TO postgres;

--
-- Name: returnbasedate(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION returnbasedate() RETURNS timestamp without time zone
    LANGUAGE plpgsql
    AS $$
  declare
      dt timestamp;
      _var bytea;      
  BEGIN


 --TODO: review this
 
 --_var := 0x00000000 + CAST ( _var AS bytea ) 
--; _dt := ( SELECT CAST ( _var AS date ) as BASEDATE ) 
--; raise info '%s', CAST ( _dt AS varchar ( 100 ) ) 
	dt:=(SELECT to_timestamp (0));

 return dt;
 	
  END;
  
 $$;


ALTER FUNCTION public.returnbasedate() OWNER TO postgres;

--
-- Name: searchalltables(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION searchalltables(searchstr character varying) RETURNS TABLE(a character varying, b character varying, c character varying)
    LANGUAGE plpgsql
    AS $_$  
	DECLARE r RECORD;	
	DECLARE _string varchar ( 1000 ) ;	
	DECLARE _string2 varchar ( 1000 ) ;		
	DECLARE cnt int;
	DECLARE r2 RECORD;
  BEGIN
	DROP TABLE If EXISTS results_;
	CREATE TEMPORARY TABLE results_ (tablename varchar(100), columnname varchar(100), val varchar(1000));

	for r in SELECT table_name, column_name, data_type
		FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' and (data_type like 'text' or data_type like 'character%') LOOP

		_string:='select count(*) FROM ' || r.table_name || ' where "' || r.column_name || '" like ''' || $1 || '''';
		--raise info '%', _string;					
		EXECUTE (_string) INTO cnt;
		if (cnt>0) then
			_string:='select ' || r.column_name || ' FROM ' || r.table_name || ' where "' || r.column_name || '" like ''' ||$1 || '''';
			raise info '%', _string;			
			FOR r2 in  EXECUTE (_string) LOOP
				_string2:='INSERT INTO results_ VALUES(''' || r.table_name || ''',''' || r.column_name ||''',''' || r2 || ''')';
				--raise info '%', _string2;
				EXECUTE (_string2);
			end Loop;
		end if;		
			
	end loop;

	return QUERY select * from results_;	
	
  END;
  $_$;


ALTER FUNCTION public.searchalltables(searchstr character varying) OWNER TO postgres;

--
-- Name: searchandreplace(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION searchandreplace(searchstr character varying, replacestr character varying) RETURNS void
    LANGUAGE plpgsql
    AS $_$  
	DECLARE r RECORD;
	DECLARE _string varchar ( 1000 ) ;	
  BEGIN


	for r in SELECT table_name, column_name, data_type
		FROM INFORMATION_SCHEMA.COLUMNS where table_schema='public' and is_updatable like 'YES' and (data_type like 'text' or data_type like 'character%') LOOP

		--raise info '%', r.table_name;
		--raise info '%', r.column_name;

		
		_string:= 'UPDATE ' || r.table_name  || ' set ' || r.column_name || '= replace(' || r.column_name || ', ''' || $1 || ''',''' || $2 || ''')';
		raise info '%', _string;
		PERFORM (_string);
		
				
	end loop;	

  END;
  $_$;


ALTER FUNCTION public.searchandreplace(searchstr character varying, replacestr character varying) OWNER TO postgres;

--
-- Name: set_constraints_deferrable(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION set_constraints_deferrable() RETURNS void
    LANGUAGE plpgsql
    AS $$  
  BEGIN

	update pg_constraint set condeferrable = 't' where contype = 'f';
	update pg_trigger set tgdeferrable=true;
	
  END;
  
$$;


ALTER FUNCTION public.set_constraints_deferrable() OWNER TO postgres;

--
-- Name: showhierarchy(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION showhierarchy(_root integer, _level integer) RETURNS void
    LANGUAGE plpgsql
    AS $$  
 DECLARE
   _child int ; 
   declare _name varchar ( 30 ) ;
  BEGIN
      
 _name := ( SELECT fr_node_description.name FROM fr_tree INNER JOIN fr_node_description ON fr_tree.id = fr_node_description.id WHERE fr_tree.id = _root );

 raise info '%', REPEAT ( '-', _level * 4 ) || _name;
 _level :=_level+1;
 
_child := ( SELECT MIN ( id ) FROM fr_tree WHERE parent = _root ) ;
WHILE _child IS NOT NULL 
loop 
begin 
 perform showhierarchy ( _child, _level ) ;
  _child := ( SELECT MIN ( id ) FROM fr_tree WHERE parent = _root AND id >_child ) ;
END ;
end loop ;


  END;
  $$;


ALTER FUNCTION public.showhierarchy(_root integer, _level integer) OWNER TO postgres;

--
-- Name: spcountgls4frame(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION spcountgls4frame(_p_frameid integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      _total integer;
  BEGIN

_total := ( 
-- 8 ]
SELECT COUNT ( * ) as 
-- 9 ]
ct FROM fr_frame INNER JOIN 
-- 10 ]
fr_sub_frame ON fr_frame.id = fr_sub_frame.id_frame INNER JOIN 
-- 11 ]
fr_f2gls ON fr_sub_frame.ID = fr_f2gls.id_sub_frame INNER JOIN 
-- 12 ]
ref_frame ON fr_sub_frame.type = ref_frame.id
-- 13 ]
GROUP BY ref_frame.name , fr_frame.id
-- 14 ]
HAVING ( ref_frame.name LIKE 'root' ) AND ( fr_frame.id = $1 ) ) 
-- 15 ]

-- 16 ]
; if ( _total is null ) 
-- 17 ]
then _total := 0 ; end if ; 
-- 18 ]


      RETURN _total;

  END;
  $_$;


ALTER FUNCTION public.spcountgls4frame(_p_frameid integer) OWNER TO postgres;

--
-- Name: update_info_tables2(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_info_tables2() RETURNS void
    LANGUAGE plpgsql
    AS $$  
 DECLARE 
 r RECORD; 
  BEGIN


FOR r IN SELECT distinct tablename FROM pg_catalog.pg_tables where schemaname='public'  LOOP

	--raise info '%', r.tablename;
	IF ( SELECT count ( name ) from info_tables where name = r.tablename ) = 0  THEN
		insert into info_tables ( name ) values ( r.tablename ) ;
		--raise info '%', 'insert into info_tables ( name ) values ( ''' || r.tablename || ''')' ;
	END IF;

end loop;




  END;
  $$;


ALTER FUNCTION public.update_info_tables2() OWNER TO postgres;

--
-- Name: update_rules_from_ptrs(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_rules_from_ptrs() RETURNS void
    LANGUAGE plpgsql
    AS $$  
 DECLARE
	_val1 int;
	_val2 int;
	_string varchar ( 1000 );	
  BEGIN
  
 _val1 := 42;
 while _val1 <69 loop 
	begin 
		_val1 := _val1 + 1;
		_val2 := _val1 + 39;
		_string :='update ui_rules Set ui_rules.rule  = Replace (ui_rules.rule , ''ptr(' || CAST ( _val1 AS varchar ) || ')'' , ' || '''ptr(' || CAST ( _val2 AS varchar ) || ')'')From ui_rules ' ;
		raise info '%', _string; 
		PERFORM ( _string ) ; 
	END;
 end loop ;



  END;
  $$;


ALTER FUNCTION public.update_rules_from_ptrs() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: fr_als2vessel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_als2vessel (
    id bigint NOT NULL,
    id_sub_frame integer NOT NULL,
    id_abstract_landingsite integer NOT NULL,
    vesselid integer NOT NULL
);


ALTER TABLE public.fr_als2vessel OWNER TO postgres;

--
-- Name: fr_gls2als; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_gls2als (
    id bigint NOT NULL,
    id_sub_frame integer NOT NULL,
    id_gls integer NOT NULL,
    id_abstract_landingsite integer NOT NULL
);


ALTER TABLE public.fr_gls2als OWNER TO postgres;

--
-- Name: ref_abstract_landingsite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_abstract_landingsite (
    id integer NOT NULL,
    id_landingsite_type smallint NOT NULL,
    id_port integer NOT NULL,
    id_collector integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_abstract_landingsite OWNER TO postgres;

--
-- Name: ref_group_of_landingsites; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_group_of_landingsites (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_group_of_landingsites OWNER TO postgres;

--
-- Name: ref_minor_strata; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_minor_strata (
    id integer NOT NULL,
    id_start_dt bigint NOT NULL,
    id_end_dt bigint NOT NULL,
    id_frame_time integer NOT NULL,
    id_gls integer NOT NULL,
    isclosed boolean NOT NULL,
    id_no_recording_activity smallint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.ref_minor_strata OWNER TO postgres;

--
-- Name: ViewSelectLogbookSampling; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW "ViewSelectLogbookSampling" AS
    SELECT fr_als2vessel.vesselid FROM ((((ref_group_of_landingsites JOIN ref_minor_strata ON ((ref_group_of_landingsites.id = ref_minor_strata.id_gls))) JOIN fr_gls2als ON ((ref_group_of_landingsites.id = fr_gls2als.id_gls))) JOIN ref_abstract_landingsite ON ((fr_gls2als.id_abstract_landingsite = ref_abstract_landingsite.id))) JOIN fr_als2vessel ON ((ref_abstract_landingsite.id = fr_als2vessel.id_abstract_landingsite))) WHERE (ref_minor_strata.id = 1);


ALTER TABLE public."ViewSelectLogbookSampling" OWNER TO postgres;

--
-- Name: View_ForeignKeys; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW "View_ForeignKeys" AS
    SELECT fk.table_name AS fk_table, cu.column_name AS fk_column, pk.table_name AS pk_table, pt.column_name AS pk_column, c.constraint_name FROM ((((information_schema.referential_constraints c JOIN information_schema.table_constraints fk ON (((c.constraint_name)::text = (fk.constraint_name)::text))) JOIN information_schema.table_constraints pk ON (((c.unique_constraint_name)::text = (pk.constraint_name)::text))) JOIN information_schema.key_column_usage cu ON (((c.constraint_name)::text = (cu.constraint_name)::text))) JOIN (SELECT i1.table_name, i2.column_name FROM (information_schema.table_constraints i1 JOIN information_schema.key_column_usage i2 ON (((i1.constraint_name)::text = (i2.constraint_name)::text))) WHERE ((i1.constraint_type)::text = 'PRIMARY KEY'::text)) pt ON (((pt.table_name)::text = (pk.table_name)::text)));


ALTER TABLE public."View_ForeignKeys" OWNER TO postgres;

--
-- Name: abstract_changes_temp_vessel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE abstract_changes_temp_vessel (
    id integer NOT NULL,
    id_cell integer NOT NULL,
    vesselid integer NOT NULL,
    from_ls integer NOT NULL,
    to_ls integer NOT NULL,
    id_ref_changes smallint NOT NULL,
    id_source smallint NOT NULL,
    id_minor_strata integer NOT NULL
);


ALTER TABLE public.abstract_changes_temp_vessel OWNER TO postgres;

--
-- Name: abstract_changes_temp_vessel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE abstract_changes_temp_vessel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.abstract_changes_temp_vessel_id_seq OWNER TO postgres;

--
-- Name: abstract_changes_temp_vessel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE abstract_changes_temp_vessel_id_seq OWNED BY abstract_changes_temp_vessel.id;


--
-- Name: abstract_changes_temp_vessel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('abstract_changes_temp_vessel_id_seq', 1, false);


--
-- Name: abstract_sampled_vessels; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE abstract_sampled_vessels (
    id integer NOT NULL,
    id_source smallint NOT NULL,
    vesselid integer NOT NULL,
    id_sample_origin smallint NOT NULL,
    id_sample_status smallint NOT NULL,
    id_sampled_cell_vessels integer NOT NULL,
    id_sampled_strata_vessels integer NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.abstract_sampled_vessels OWNER TO postgres;

--
-- Name: abstract_sampled_vessels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE abstract_sampled_vessels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.abstract_sampled_vessels_id_seq OWNER TO postgres;

--
-- Name: abstract_sampled_vessels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE abstract_sampled_vessels_id_seq OWNED BY abstract_sampled_vessels.id;


--
-- Name: abstract_sampled_vessels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('abstract_sampled_vessels_id_seq', 1, false);


--
-- Name: changes_perm_gls; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE changes_perm_gls (
    id integer NOT NULL,
    id_sub_frame integer NOT NULL,
    id_gls integer NOT NULL,
    reason text NOT NULL
);


ALTER TABLE public.changes_perm_gls OWNER TO postgres;

--
-- Name: changes_perm_gls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE changes_perm_gls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.changes_perm_gls_id_seq OWNER TO postgres;

--
-- Name: changes_perm_gls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE changes_perm_gls_id_seq OWNED BY changes_perm_gls.id;


--
-- Name: changes_perm_gls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('changes_perm_gls_id_seq', 1, false);


--
-- Name: changes_perm_ls; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE changes_perm_ls (
    id integer NOT NULL,
    id_sub_frame integer NOT NULL,
    id_abstract_landingsite integer NOT NULL,
    reason text NOT NULL
);


ALTER TABLE public.changes_perm_ls OWNER TO postgres;

--
-- Name: changes_perm_ls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE changes_perm_ls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.changes_perm_ls_id_seq OWNER TO postgres;

--
-- Name: changes_perm_ls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE changes_perm_ls_id_seq OWNED BY changes_perm_ls.id;


--
-- Name: changes_perm_ls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('changes_perm_ls_id_seq', 1, false);


--
-- Name: changes_perm_vessel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE changes_perm_vessel (
    id integer NOT NULL,
    id_sub_frame integer NOT NULL,
    vesselid integer NOT NULL,
    id_ref_changes smallint NOT NULL
);


ALTER TABLE public.changes_perm_vessel OWNER TO postgres;

--
-- Name: changes_perm_vessel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE changes_perm_vessel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.changes_perm_vessel_id_seq OWNER TO postgres;

--
-- Name: changes_perm_vessel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE changes_perm_vessel_id_seq OWNED BY changes_perm_vessel.id;


--
-- Name: changes_perm_vessel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('changes_perm_vessel_id_seq', 9, true);


--
-- Name: fr_f2gls; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_f2gls (
    id bigint NOT NULL,
    id_sub_frame integer NOT NULL,
    id_gls integer NOT NULL
);


ALTER TABLE public.fr_f2gls OWNER TO postgres;

--
-- Name: fr_frame; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_frame (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    id_cloned_previous_frame integer DEFAULT 1 NOT NULL,
    id_source smallint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.fr_frame OWNER TO postgres;

--
-- Name: fr_sub_frame; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_sub_frame (
    id integer NOT NULL,
    type smallint NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    id_frame integer NOT NULL
);


ALTER TABLE public.fr_sub_frame OWNER TO postgres;

--
-- Name: ref_frame; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_frame (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_frame OWNER TO postgres;

--
-- Name: countgls4frame; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW countgls4frame AS
    SELECT count(*) AS expr1 FROM (((fr_frame JOIN fr_sub_frame ON ((fr_frame.id = fr_sub_frame.id_frame))) JOIN fr_f2gls ON ((fr_sub_frame.id = fr_f2gls.id_sub_frame))) JOIN ref_frame ON ((fr_sub_frame.type = ref_frame.id))) GROUP BY ref_frame.name, fr_frame.id HAVING (((ref_frame.name)::text ~~ ('root'::bpchar)::text) AND (fr_frame.id = 9));


ALTER TABLE public.countgls4frame OWNER TO postgres;

--
-- Name: fr_als2vessel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_als2vessel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_als2vessel_id_seq OWNER TO postgres;

--
-- Name: fr_als2vessel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_als2vessel_id_seq OWNED BY fr_als2vessel.id;


--
-- Name: fr_als2vessel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_als2vessel_id_seq', 1372, true);


--
-- Name: fr_f2gls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_f2gls_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_f2gls_id_seq OWNER TO postgres;

--
-- Name: fr_f2gls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_f2gls_id_seq OWNED BY fr_f2gls.id;


--
-- Name: fr_f2gls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_f2gls_id_seq', 252, true);


--
-- Name: fr_frame_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_frame_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_frame_id_seq OWNER TO postgres;

--
-- Name: fr_frame_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_frame_id_seq OWNED BY fr_frame.id;


--
-- Name: fr_frame_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_frame_id_seq', 1, false);


--
-- Name: fr_gls2als_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_gls2als_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_gls2als_id_seq OWNER TO postgres;

--
-- Name: fr_gls2als_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_gls2als_id_seq OWNED BY fr_gls2als.id;


--
-- Name: fr_gls2als_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_gls2als_id_seq', 1037, true);


--
-- Name: fr_node_description; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_node_description (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    name_eng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    old_code character varying(50) DEFAULT '11111'::character varying NOT NULL
);


ALTER TABLE public.fr_node_description OWNER TO postgres;

--
-- Name: fr_node_description_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_node_description_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_node_description_id_seq OWNER TO postgres;

--
-- Name: fr_node_description_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_node_description_id_seq OWNED BY fr_node_description.id;


--
-- Name: fr_node_description_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_node_description_id_seq', 1, false);


--
-- Name: fr_sub_frame_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_sub_frame_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_sub_frame_id_seq OWNER TO postgres;

--
-- Name: fr_sub_frame_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_sub_frame_id_seq OWNED BY fr_sub_frame.id;


--
-- Name: fr_sub_frame_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_sub_frame_id_seq', 1, false);


--
-- Name: fr_time; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_time (
    id integer NOT NULL,
    id_frame integer NOT NULL,
    id_start_dt bigint NOT NULL,
    id_end_dt bigint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.fr_time OWNER TO postgres;

--
-- Name: fr_time_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_time_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_time_id_seq OWNER TO postgres;

--
-- Name: fr_time_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_time_id_seq OWNED BY fr_time.id;


--
-- Name: fr_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_time_id_seq', 1, false);


--
-- Name: fr_tree; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fr_tree (
    id integer NOT NULL,
    lft smallint NOT NULL,
    rgt smallint NOT NULL,
    parent smallint DEFAULT (-1) NOT NULL,
    depth smallint NOT NULL
);


ALTER TABLE public.fr_tree OWNER TO postgres;

--
-- Name: fr_tree_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fr_tree_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fr_tree_id_seq OWNER TO postgres;

--
-- Name: fr_tree_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fr_tree_id_seq OWNED BY fr_tree.id;


--
-- Name: fr_tree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fr_tree_id_seq', 1, false);


--
-- Name: gl_dates; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE gl_dates (
    id bigint NOT NULL,
    date_utc timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    date_local timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    date_type smallint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.gl_dates OWNER TO postgres;

--
-- Name: gl_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE gl_dates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gl_dates_id_seq OWNER TO postgres;

--
-- Name: gl_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE gl_dates_id_seq OWNED BY gl_dates.id;


--
-- Name: gl_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('gl_dates_id_seq', 1, false);


--
-- Name: gl_null_replacements; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE gl_null_replacements (
    id integer NOT NULL,
    internal_name character varying(50) NOT NULL,
    name_eng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    "varchar" character varying(50) NOT NULL,
    "int" integer NOT NULL,
    char3 character(3) NOT NULL,
    char2 character(2) NOT NULL,
    datetime timestamp without time zone NOT NULL,
    "bit" boolean NOT NULL,
    char4 character(10) NOT NULL,
    char1 character(1) NOT NULL,
    "smallint" smallint DEFAULT 1111 NOT NULL,
    "decimal" numeric(18,10) NOT NULL
);


ALTER TABLE public.gl_null_replacements OWNER TO postgres;

--
-- Name: gl_null_replacements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE gl_null_replacements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gl_null_replacements_id_seq OWNER TO postgres;

--
-- Name: gl_null_replacements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE gl_null_replacements_id_seq OWNED BY gl_null_replacements.id;


--
-- Name: gl_null_replacements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('gl_null_replacements_id_seq', 1, false);


--
-- Name: gl_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE gl_session (
    id bigint NOT NULL,
    id_user smallint NOT NULL,
    mac_address character varying(50) NOT NULL,
    id_base_date bigint NOT NULL,
    id_location integer NOT NULL,
    id_start_dt bigint NOT NULL,
    id_end_dt bigint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.gl_session OWNER TO postgres;

--
-- Name: gl_session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE gl_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gl_session_id_seq OWNER TO postgres;

--
-- Name: gl_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE gl_session_id_seq OWNED BY gl_session.id;


--
-- Name: gl_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('gl_session_id_seq', 1, false);


--
-- Name: info_changes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_changes (
    id integer NOT NULL,
    "table" character varying(50) NOT NULL,
    "column" character varying(50) NOT NULL,
    "from" character varying(100) DEFAULT '274b68192b056e268f128ff63bfcd4a4'::character varying,
    "to" character varying(100) DEFAULT '274b68192b056e268f128ff63bfcd4a4'::character varying NOT NULL,
    id_session bigint NOT NULL,
    id_datetime bigint NOT NULL
);


ALTER TABLE public.info_changes OWNER TO postgres;

--
-- Name: COLUMN info_changes."from"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN info_changes."from" IS 'The default value for this field corresponds to a MD5 Hash of Not Applicable';


--
-- Name: COLUMN info_changes."to"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN info_changes."to" IS 'The default value for this field corresponds to a MD5 Hash of Not Applicable';


--
-- Name: info_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_changes_id_seq OWNER TO postgres;

--
-- Name: info_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_changes_id_seq OWNED BY info_changes.id;


--
-- Name: info_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_changes_id_seq', 1, false);


--
-- Name: info_client; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_client (
    id integer NOT NULL,
    client_id integer NOT NULL
);


ALTER TABLE public.info_client OWNER TO postgres;

--
-- Name: info_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_client_id_seq OWNER TO postgres;

--
-- Name: info_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_client_id_seq OWNED BY info_client.id;


--
-- Name: info_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_client_id_seq', 1, false);


--
-- Name: info_fields; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_fields (
    id integer NOT NULL,
    table_name character varying(50) NOT NULL,
    field_name character varying(50) NOT NULL,
    original_type character varying(50) NOT NULL,
    reviewed_type character varying(50) NOT NULL,
    original_size integer NOT NULL,
    reviewed_size integer NOT NULL,
    change2autoincrement boolean DEFAULT false NOT NULL,
    hasdefaultvalue boolean DEFAULT false NOT NULL,
    defaultvalue character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    createuniquecstrt boolean DEFAULT false NOT NULL,
    replacenulls boolean DEFAULT false NOT NULL,
    nullvalue character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.info_fields OWNER TO postgres;

--
-- Name: info_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_fields_id_seq OWNER TO postgres;

--
-- Name: info_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_fields_id_seq OWNED BY info_fields.id;


--
-- Name: info_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_fields_id_seq', 590, true);


--
-- Name: info_fk; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_fk (
    id integer NOT NULL,
    fk_table character varying(50) NOT NULL,
    fk_field character varying(50) NOT NULL,
    pk_table character varying(50) NOT NULL,
    pk_field character varying(50) NOT NULL
);


ALTER TABLE public.info_fk OWNER TO postgres;

--
-- Name: info_fk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_fk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_fk_id_seq OWNER TO postgres;

--
-- Name: info_fk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_fk_id_seq OWNED BY info_fk.id;


--
-- Name: info_fk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_fk_id_seq', 1, false);


--
-- Name: info_master; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_master (
    id integer NOT NULL,
    master_id integer NOT NULL
);


ALTER TABLE public.info_master OWNER TO postgres;

--
-- Name: info_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_master_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_master_id_seq OWNER TO postgres;

--
-- Name: info_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_master_id_seq OWNED BY info_master.id;


--
-- Name: info_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_master_id_seq', 1, false);


--
-- Name: info_tables; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_tables (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(4000) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.info_tables OWNER TO postgres;

--
-- Name: info_tables_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_tables_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_tables_id_seq OWNER TO postgres;

--
-- Name: info_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_tables_id_seq OWNED BY info_tables.id;


--
-- Name: info_tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_tables_id_seq', 80, true);


--
-- Name: info_tables_import; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_tables_import (
    id integer NOT NULL,
    original_name character varying(50) NOT NULL,
    imported_name character varying(50) NOT NULL,
    convertpk2int boolean DEFAULT false NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    appendnullfields boolean DEFAULT false NOT NULL
);


ALTER TABLE public.info_tables_import OWNER TO postgres;

--
-- Name: info_tables_import_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_tables_import_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_tables_import_id_seq OWNER TO postgres;

--
-- Name: info_tables_import_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_tables_import_id_seq OWNED BY info_tables_import.id;


--
-- Name: info_tables_import_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_tables_import_id_seq', 1, false);


--
-- Name: info_triggers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE info_triggers (
    id integer NOT NULL,
    table_name character varying(50) NOT NULL,
    field_name character varying(50) NOT NULL,
    new boolean DEFAULT true NOT NULL,
    mod boolean DEFAULT true NOT NULL,
    del boolean DEFAULT true NOT NULL
);


ALTER TABLE public.info_triggers OWNER TO postgres;

--
-- Name: info_triggers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE info_triggers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.info_triggers_id_seq OWNER TO postgres;

--
-- Name: info_triggers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE info_triggers_id_seq OWNED BY info_triggers.id;


--
-- Name: info_triggers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('info_triggers_id_seq', 1, false);


--
-- Name: ref_commercial_categories; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_commercial_categories (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_commercial_categories OWNER TO postgres;

--
-- Name: ref_gears; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_gears (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    matchingcodegear character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    geareu character varying(3) DEFAULT 'mis'::character varying NOT NULL,
    gearstd character varying(3) DEFAULT 'mis'::character varying NOT NULL,
    fishingtechniqueeu character varying(3) DEFAULT 'mis'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    gearclass smallint DEFAULT 16 NOT NULL,
    marinefisherysubsector smallint DEFAULT 5 NOT NULL
);


ALTER TABLE public.ref_gears OWNER TO postgres;

--
-- Name: sampled_fishing_operations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_fishing_operations (
    id integer NOT NULL,
    id_fishing_trip integer NOT NULL,
    id_start_dt bigint NOT NULL,
    id_end_dt bigint NOT NULL,
    id_gear integer NOT NULL,
    catch_weight_estimated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_weight_calculated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_catch_weight_units smallint NOT NULL,
    catch_no_boxes_estimated numeric(18,10) NOT NULL,
    catch_no_boxes_calculated numeric(18,10) NOT NULL,
    id_catch_no_boxes_units smallint NOT NULL,
    weight_box numeric(18,10) NOT NULL,
    catch_units_estimated integer DEFAULT 11111 NOT NULL,
    catch_units_calculated integer DEFAULT 11111 NOT NULL,
    id_catch_units_units smallint NOT NULL,
    n_gear_units integer DEFAULT 11111 NOT NULL,
    gear_unit_size numeric(18,10) DEFAULT 0.11111 NOT NULL,
    number_order smallint DEFAULT 11111 NOT NULL,
    id_fishing_zone integer NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    weight_unit numeric(18,10) NOT NULL
);


ALTER TABLE public.sampled_fishing_operations OWNER TO postgres;

--
-- Name: query_trips_for_exaro; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW query_trips_for_exaro AS
    SELECT ref_commercial_categories.name AS com_cat, ref_gears.name AS gear, a.date_local AS start_d, b.date_local AS end_d FROM ((((sampled_fishing_operations JOIN gl_dates a ON ((sampled_fishing_operations.id_start_dt = a.id))) JOIN gl_dates b ON ((sampled_fishing_operations.id_end_dt = b.id))) JOIN ref_commercial_categories ON ((sampled_fishing_operations.id = ref_commercial_categories.id))) JOIN ref_gears ON ((sampled_fishing_operations.id_gear = ref_gears.id)));


ALTER TABLE public.query_trips_for_exaro OWNER TO postgres;

--
-- Name: ref_abstract_landingsite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_abstract_landingsite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_abstract_landingsite_id_seq OWNER TO postgres;

--
-- Name: ref_abstract_landingsite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_abstract_landingsite_id_seq OWNED BY ref_abstract_landingsite.id;


--
-- Name: ref_abstract_landingsite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_abstract_landingsite_id_seq', 1, false);


--
-- Name: ref_authorisation_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_authorisation_types (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_authorisation_types OWNER TO postgres;

--
-- Name: ref_authorisation_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_authorisation_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_authorisation_types_id_seq OWNER TO postgres;

--
-- Name: ref_authorisation_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_authorisation_types_id_seq OWNED BY ref_authorisation_types.id;


--
-- Name: ref_authorisation_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_authorisation_types_id_seq', 1, false);


--
-- Name: ref_changes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_changes (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    input boolean NOT NULL
);


ALTER TABLE public.ref_changes OWNER TO postgres;

--
-- Name: ref_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_changes_id_seq OWNER TO postgres;

--
-- Name: ref_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_changes_id_seq OWNED BY ref_changes.id;


--
-- Name: ref_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_changes_id_seq', 1, false);


--
-- Name: ref_collectors; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_collectors (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    vesselid integer NOT NULL
);


ALTER TABLE public.ref_collectors OWNER TO postgres;

--
-- Name: ref_collectors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_collectors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_collectors_id_seq OWNER TO postgres;

--
-- Name: ref_collectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_collectors_id_seq OWNED BY ref_collectors.id;


--
-- Name: ref_collectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_collectors_id_seq', 1, false);


--
-- Name: ref_commercial_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_commercial_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_commercial_categories_id_seq OWNER TO postgres;

--
-- Name: ref_commercial_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_commercial_categories_id_seq OWNED BY ref_commercial_categories.id;


--
-- Name: ref_commercial_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_commercial_categories_id_seq', 1, false);


--
-- Name: ref_countries; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_countries (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    un character(4) DEFAULT 'miss'::bpchar NOT NULL,
    undp character(3) DEFAULT 'mis'::bpchar NOT NULL,
    iso2 character(2) DEFAULT 'ms'::bpchar NOT NULL,
    iso3 character(3) DEFAULT 'mis'::bpchar NOT NULL,
    gfcm boolean DEFAULT false NOT NULL,
    eu boolean DEFAULT false NOT NULL,
    medfisis boolean DEFAULT false NOT NULL,
    namefrn character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    nameesp character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_countries OWNER TO postgres;

--
-- Name: ref_countries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_countries_id_seq OWNER TO postgres;

--
-- Name: ref_countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_countries_id_seq OWNED BY ref_countries.id;


--
-- Name: ref_countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_countries_id_seq', 1, false);


--
-- Name: ref_datetime_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_datetime_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_datetime_type OWNER TO postgres;

--
-- Name: ref_datetime_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_datetime_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_datetime_type_id_seq OWNER TO postgres;

--
-- Name: ref_datetime_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_datetime_type_id_seq OWNED BY ref_datetime_type.id;


--
-- Name: ref_datetime_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_datetime_type_id_seq', 1, false);


--
-- Name: ref_engine_locations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_engine_locations (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_engine_locations OWNER TO postgres;

--
-- Name: ref_engine_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_engine_locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_engine_locations_id_seq OWNER TO postgres;

--
-- Name: ref_engine_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_engine_locations_id_seq OWNED BY ref_engine_locations.id;


--
-- Name: ref_engine_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_engine_locations_id_seq', 1, false);


--
-- Name: ref_fishing_zones; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_fishing_zones (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    ox numeric(18,10) DEFAULT 0.11111 NOT NULL,
    oy numeric(18,10) DEFAULT 0.11111 NOT NULL,
    dx numeric(18,10) DEFAULT 0.11111 NOT NULL,
    dy numeric(18,10) DEFAULT 0.11111 NOT NULL
);


ALTER TABLE public.ref_fishing_zones OWNER TO postgres;

--
-- Name: COLUMN ref_fishing_zones.ox; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ref_fishing_zones.ox IS 'Longitude (x) on the origin, using WGS84 unprojected coordinates';


--
-- Name: COLUMN ref_fishing_zones.oy; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ref_fishing_zones.oy IS 'Latitude (y) on the origin, using WGS84 unprojected coordinates';


--
-- Name: COLUMN ref_fishing_zones.dx; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ref_fishing_zones.dx IS 'Longitude variation from the origin, using WGS84 unprojected units (deg)';


--
-- Name: COLUMN ref_fishing_zones.dy; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ref_fishing_zones.dy IS 'Latitude variation from the origin, using WGS84 unprojected units (deg)';


--
-- Name: ref_fishing_zones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_fishing_zones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_fishing_zones_id_seq OWNER TO postgres;

--
-- Name: ref_fishing_zones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_fishing_zones_id_seq OWNED BY ref_fishing_zones.id;


--
-- Name: ref_fishing_zones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_fishing_zones_id_seq', 1, false);


--
-- Name: ref_fleet_segmentation; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_fleet_segmentation (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    alphacode character(1) DEFAULT 's'::bpchar NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_fleet_segmentation OWNER TO postgres;

--
-- Name: ref_fleet_segmentation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_fleet_segmentation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_fleet_segmentation_id_seq OWNER TO postgres;

--
-- Name: ref_fleet_segmentation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_fleet_segmentation_id_seq OWNED BY ref_fleet_segmentation.id;


--
-- Name: ref_fleet_segmentation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_fleet_segmentation_id_seq', 1, false);


--
-- Name: ref_frame_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_frame_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_frame_id_seq OWNER TO postgres;

--
-- Name: ref_frame_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_frame_id_seq OWNED BY ref_frame.id;


--
-- Name: ref_frame_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_frame_id_seq', 1, false);


--
-- Name: ref_gear_classes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_gear_classes (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_gear_classes OWNER TO postgres;

--
-- Name: ref_gear_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_gear_classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_gear_classes_id_seq OWNER TO postgres;

--
-- Name: ref_gear_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_gear_classes_id_seq OWNED BY ref_gear_classes.id;


--
-- Name: ref_gear_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_gear_classes_id_seq', 1, false);


--
-- Name: ref_gears_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_gears_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_gears_id_seq OWNER TO postgres;

--
-- Name: ref_gears_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_gears_id_seq OWNED BY ref_gears.id;


--
-- Name: ref_gears_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_gears_id_seq', 1, false);


--
-- Name: ref_group_of_landingsites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_group_of_landingsites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_group_of_landingsites_id_seq OWNER TO postgres;

--
-- Name: ref_group_of_landingsites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_group_of_landingsites_id_seq OWNED BY ref_group_of_landingsites.id;


--
-- Name: ref_group_of_landingsites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_group_of_landingsites_id_seq', 1, false);


--
-- Name: ref_issuing_offices; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_issuing_offices (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_issuing_offices OWNER TO postgres;

--
-- Name: ref_issuing_offices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_issuing_offices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_issuing_offices_id_seq OWNER TO postgres;

--
-- Name: ref_issuing_offices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_issuing_offices_id_seq OWNED BY ref_issuing_offices.id;


--
-- Name: ref_issuing_offices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_issuing_offices_id_seq', 1, false);


--
-- Name: ref_landingsite_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_landingsite_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::bpchar NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_landingsite_type OWNER TO postgres;

--
-- Name: ref_landingsite_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_landingsite_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_landingsite_type_id_seq OWNER TO postgres;

--
-- Name: ref_landingsite_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_landingsite_type_id_seq OWNED BY ref_landingsite_type.id;


--
-- Name: ref_landingsite_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_landingsite_type_id_seq', 1, false);


--
-- Name: ref_levels; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_levels (
    id integer NOT NULL,
    name character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_levels OWNER TO postgres;

--
-- Name: ref_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_levels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_levels_id_seq OWNER TO postgres;

--
-- Name: ref_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_levels_id_seq OWNED BY ref_levels.id;


--
-- Name: ref_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_levels_id_seq', 1, false);


--
-- Name: ref_location; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_location (
    id integer NOT NULL,
    country smallint NOT NULL,
    city_name character varying(50) NOT NULL,
    city_nameeng character varying(50) DEFAULT 'missing'::character varying
);


ALTER TABLE public.ref_location OWNER TO postgres;

--
-- Name: ref_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_location_id_seq OWNER TO postgres;

--
-- Name: ref_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_location_id_seq OWNED BY ref_location.id;


--
-- Name: ref_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_location_id_seq', 1, false);


--
-- Name: ref_logbook_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_logbook_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_logbook_types OWNER TO postgres;

--
-- Name: ref_logbook_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_logbook_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_logbook_types_id_seq OWNER TO postgres;

--
-- Name: ref_logbook_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_logbook_types_id_seq OWNED BY ref_logbook_types.id;


--
-- Name: ref_logbook_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_logbook_types_id_seq', 1, false);


--
-- Name: ref_marine_fishery_subsectors; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_marine_fishery_subsectors (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_marine_fishery_subsectors OWNER TO postgres;

--
-- Name: ref_marine_fishery_subsectors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_marine_fishery_subsectors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_marine_fishery_subsectors_id_seq OWNER TO postgres;

--
-- Name: ref_marine_fishery_subsectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_marine_fishery_subsectors_id_seq OWNED BY ref_marine_fishery_subsectors.id;


--
-- Name: ref_marine_fishery_subsectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_marine_fishery_subsectors_id_seq', 1, false);


--
-- Name: ref_minor_strata_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_minor_strata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_minor_strata_id_seq OWNER TO postgres;

--
-- Name: ref_minor_strata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_minor_strata_id_seq OWNED BY ref_minor_strata.id;


--
-- Name: ref_minor_strata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_minor_strata_id_seq', 1, false);


--
-- Name: ref_months; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_months (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_months OWNER TO postgres;

--
-- Name: ref_months_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_months_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_months_id_seq OWNER TO postgres;

--
-- Name: ref_months_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_months_id_seq OWNED BY ref_months.id;


--
-- Name: ref_months_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_months_id_seq', 1, false);


--
-- Name: ref_no_recording_activities; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_no_recording_activities (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_no_recording_activities OWNER TO postgres;

--
-- Name: ref_no_recording_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_no_recording_activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_no_recording_activities_id_seq OWNER TO postgres;

--
-- Name: ref_no_recording_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_no_recording_activities_id_seq OWNED BY ref_no_recording_activities.id;


--
-- Name: ref_no_recording_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_no_recording_activities_id_seq', 1, false);


--
-- Name: ref_operational_statuses; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_operational_statuses (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_operational_statuses OWNER TO postgres;

--
-- Name: ref_operational_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_operational_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_operational_statuses_id_seq OWNER TO postgres;

--
-- Name: ref_operational_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_operational_statuses_id_seq OWNED BY ref_operational_statuses.id;


--
-- Name: ref_operational_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_operational_statuses_id_seq', 1, false);


--
-- Name: ref_ports; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_ports (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    portcode character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    latitude numeric(18,10) DEFAULT 0.11111 NOT NULL,
    longitude numeric(18,10) DEFAULT 0.11111 NOT NULL,
    geosubarea numeric(18,10) DEFAULT 0.11111 NOT NULL,
    porttype smallint DEFAULT 11111 NOT NULL,
    portcodeeu character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    minorstratum smallint DEFAULT 1111 NOT NULL
);


ALTER TABLE public.ref_ports OWNER TO postgres;

--
-- Name: ref_ports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_ports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_ports_id_seq OWNER TO postgres;

--
-- Name: ref_ports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_ports_id_seq OWNED BY ref_ports.id;


--
-- Name: ref_ports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_ports_id_seq', 1, false);


--
-- Name: ref_sample_origin; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_sample_origin (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    name_eng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_sample_origin OWNER TO postgres;

--
-- Name: ref_sample_origin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_sample_origin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_sample_origin_id_seq OWNER TO postgres;

--
-- Name: ref_sample_origin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_sample_origin_id_seq OWNED BY ref_sample_origin.id;


--
-- Name: ref_sample_origin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_sample_origin_id_seq', 1, false);


--
-- Name: ref_sample_status; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_sample_status (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    name_eng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_sample_status OWNER TO postgres;

--
-- Name: ref_sample_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_sample_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_sample_status_id_seq OWNER TO postgres;

--
-- Name: ref_sample_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_sample_status_id_seq OWNED BY ref_sample_status.id;


--
-- Name: ref_sample_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_sample_status_id_seq', 1, false);


--
-- Name: ref_samplers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_samplers (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.ref_samplers OWNER TO postgres;

--
-- Name: ref_samplers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_samplers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_samplers_id_seq OWNER TO postgres;

--
-- Name: ref_samplers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_samplers_id_seq OWNED BY ref_samplers.id;


--
-- Name: ref_samplers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_samplers_id_seq', 1, false);


--
-- Name: ref_sampling_technique; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_sampling_technique (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    id_strategy smallint NOT NULL,
    sample_size integer NOT NULL,
    population_size integer NOT NULL,
    id_fr_time integer NOT NULL
);


ALTER TABLE public.ref_sampling_technique OWNER TO postgres;

--
-- Name: ref_sampling_technique_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_sampling_technique_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_sampling_technique_id_seq OWNER TO postgres;

--
-- Name: ref_sampling_technique_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_sampling_technique_id_seq OWNED BY ref_sampling_technique.id;


--
-- Name: ref_sampling_technique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_sampling_technique_id_seq', 1, false);


--
-- Name: ref_source; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_source (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_source OWNER TO postgres;

--
-- Name: ref_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_source_id_seq OWNER TO postgres;

--
-- Name: ref_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_source_id_seq OWNED BY ref_source.id;


--
-- Name: ref_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_source_id_seq', 1, false);


--
-- Name: ref_species; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_species (
    id bigint NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    namesci character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    namefrn character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    nameesp character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    isscaap integer DEFAULT 11111 NOT NULL,
    taxocode character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    alphacode character(3) DEFAULT 'mis'::bpchar NOT NULL,
    author character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    family character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    "order" character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_species OWNER TO postgres;

--
-- Name: ref_species_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_species_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_species_id_seq OWNER TO postgres;

--
-- Name: ref_species_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_species_id_seq OWNED BY ref_species.id;


--
-- Name: ref_species_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_species_id_seq', 1, false);


--
-- Name: ref_stocks; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_stocks (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    matchingcode character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    speciescode character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    speciestricode character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    grouptype character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_stocks OWNER TO postgres;

--
-- Name: ref_stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_stocks_id_seq OWNER TO postgres;

--
-- Name: ref_stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_stocks_id_seq OWNED BY ref_stocks.id;


--
-- Name: ref_stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_stocks_id_seq', 1, false);


--
-- Name: ref_strategy; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_strategy (
    id integer NOT NULL,
    name character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_strategy OWNER TO postgres;

--
-- Name: ref_strategy_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_strategy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_strategy_id_seq OWNER TO postgres;

--
-- Name: ref_strategy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_strategy_id_seq OWNED BY ref_strategy.id;


--
-- Name: ref_strategy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_strategy_id_seq', 1, false);


--
-- Name: ref_units; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_units (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ref_units OWNER TO postgres;

--
-- Name: ref_units_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_units_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_units_id_seq OWNER TO postgres;

--
-- Name: ref_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_units_id_seq OWNED BY ref_units.id;


--
-- Name: ref_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_units_id_seq', 1, false);


--
-- Name: ref_vessel_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_vessel_types (
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    stdabbreviation character(2) DEFAULT 'ms'::bpchar NOT NULL,
    vesseltypefffao character varying(50) DEFAULT 'mis'::character varying NOT NULL,
    old_code character varying(50) DEFAULT 'missing'::character varying NOT NULL
);


ALTER TABLE public.ref_vessel_types OWNER TO postgres;

--
-- Name: ref_vessel_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_vessel_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_vessel_types_id_seq OWNER TO postgres;

--
-- Name: ref_vessel_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_vessel_types_id_seq OWNED BY ref_vessel_types.id;


--
-- Name: ref_vessel_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_vessel_types_id_seq', 1, false);


--
-- Name: ref_vessels; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_vessels (
    vesselid integer NOT NULL,
    censusid integer DEFAULT 11111 NOT NULL,
    created timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    uniqueregistrationnumber character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    registrationnumber character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    externalmarking character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    registrationdate timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    name character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    originalname character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    originalregistrationnumber character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    length numeric(18,10) DEFAULT 0.11111 NOT NULL,
    width numeric(18,10) DEFAULT 0.11111 NOT NULL,
    depth numeric(18,10) DEFAULT 0.11111 NOT NULL,
    decked boolean DEFAULT false NOT NULL,
    grt numeric(18,10) DEFAULT 0.11111 NOT NULL,
    gt numeric(18,10) DEFAULT 0.11111 NOT NULL,
    documentid character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    issuedate timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    expirydate timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    fisheryentrydate timestamp without time zone DEFAULT '1753-01-01 00:00:00'::timestamp without time zone NOT NULL,
    fisherydepartmentregistrationnumber character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    licenseindicator boolean DEFAULT false NOT NULL,
    enginepower numeric(18,10) DEFAULT 0.11111 NOT NULL,
    originaldeletiondetails text DEFAULT 'missing'::text NOT NULL,
    old_code integer DEFAULT 11111 NOT NULL,
    operationalstatus smallint NOT NULL,
    vesseltype smallint DEFAULT 15 NOT NULL,
    registrationoffice smallint NOT NULL,
    flag smallint DEFAULT 220 NOT NULL,
    originalflag smallint DEFAULT 221 NOT NULL,
    nonoperationalreason smallint DEFAULT 11 NOT NULL,
    homeport integer DEFAULT 14 NOT NULL,
    fleetsegment smallint DEFAULT 1 NOT NULL,
    authorisationtype smallint DEFAULT 9 NOT NULL,
    issuingoffice smallint DEFAULT 5 NOT NULL,
    enginelocation smallint DEFAULT 3 NOT NULL,
    maingeartype integer NOT NULL,
    maingeartargetgroupofspecies smallint DEFAULT 9 NOT NULL,
    secondarygeartype integer DEFAULT 65 NOT NULL,
    secondarygeartargetgroupofspecies smallint DEFAULT 10 NOT NULL
);


ALTER TABLE public.ref_vessels OWNER TO postgres;

--
-- Name: ref_vessels_vesselid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_vessels_vesselid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ref_vessels_vesselid_seq OWNER TO postgres;

--
-- Name: ref_vessels_vesselid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_vessels_vesselid_seq OWNED BY ref_vessels.vesselid;


--
-- Name: ref_vessels_vesselid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ref_vessels_vesselid_seq', 1, false);


--
-- Name: sampled_catch; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_catch (
    id integer NOT NULL,
    id_fishing_operation integer NOT NULL,
    id_commercial_category smallint NOT NULL,
    catch_weight_estimated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_weight_calculated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_catch_weight_units smallint NOT NULL,
    catch_no_boxes_estimated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_no_boxes_calculated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_catch_no_boxes_units smallint NOT NULL,
    weight_box numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_units_estimated integer DEFAULT 11111 NOT NULL,
    id_catch_units_units smallint NOT NULL,
    sample_units integer DEFAULT 11111 NOT NULL,
    sample_weight numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_sample_units smallint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    catch_units_calculated integer DEFAULT 11111 NOT NULL,
    weight_unit numeric(18,10) NOT NULL
);


ALTER TABLE public.sampled_catch OWNER TO postgres;

--
-- Name: sampled_catch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_catch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_catch_id_seq OWNER TO postgres;

--
-- Name: sampled_catch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_catch_id_seq OWNED BY sampled_catch.id;


--
-- Name: sampled_catch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_catch_id_seq', 1, false);


--
-- Name: sampled_cell; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_cell (
    id integer NOT NULL,
    id_minor_strata integer NOT NULL,
    id_start_dt bigint NOT NULL,
    id_end_dt bigint NOT NULL,
    id_abstract_landingsite integer NOT NULL,
    n_vessels_estimated integer DEFAULT 11111 NOT NULL,
    n_vessels_calculated integer DEFAULT 11111 NOT NULL,
    n_active_vessels_estimated integer DEFAULT 11111 NOT NULL,
    n_active_vessels_calculated integer DEFAULT 11111 NOT NULL,
    n_inactive_vessels_estimated integer DEFAULT 11111 NOT NULL,
    n_inactive_vessels_calculated integer DEFAULT 11111 NOT NULL,
    n_active_vessels_outside_estimated integer NOT NULL,
    n_active_vessels_outside_calculated integer NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.sampled_cell OWNER TO postgres;

--
-- Name: sampled_cell_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_cell_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_cell_id_seq OWNER TO postgres;

--
-- Name: sampled_cell_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_cell_id_seq OWNED BY sampled_cell.id;


--
-- Name: sampled_cell_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_cell_id_seq', 1, false);


--
-- Name: sampled_cell_vessel_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_cell_vessel_types (
    id integer NOT NULL,
    id_cell integer NOT NULL,
    id_vessel_type smallint NOT NULL,
    n_vessels_estimated integer DEFAULT 11111 NOT NULL,
    n_vessels_calculated integer DEFAULT 11111 NOT NULL,
    n_active_vessels_estimated integer DEFAULT 11111 NOT NULL,
    n_active_vessels_calculated integer DEFAULT 11111 NOT NULL,
    n_inactive_vessels_estimated integer DEFAULT 11111 NOT NULL,
    n_inactive_vessels_calculated integer DEFAULT 11111 NOT NULL,
    n_active_vessels_outside_estimated integer NOT NULL,
    n_active_vessels_outside_calculated integer NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.sampled_cell_vessel_types OWNER TO postgres;

--
-- Name: sampled_cell_vessel_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_cell_vessel_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_cell_vessel_types_id_seq OWNER TO postgres;

--
-- Name: sampled_cell_vessel_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_cell_vessel_types_id_seq OWNED BY sampled_cell_vessel_types.id;


--
-- Name: sampled_cell_vessel_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_cell_vessel_types_id_seq', 1, false);


--
-- Name: sampled_cell_vessels; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_cell_vessels (
    id integer NOT NULL,
    id_cell_vessel_types integer NOT NULL,
    n_trips_estimated integer DEFAULT 11111 NOT NULL,
    n_trips_calculated integer DEFAULT 11111 NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.sampled_cell_vessels OWNER TO postgres;

--
-- Name: sampled_cell_vessels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_cell_vessels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_cell_vessels_id_seq OWNER TO postgres;

--
-- Name: sampled_cell_vessels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_cell_vessels_id_seq OWNED BY sampled_cell_vessels.id;


--
-- Name: sampled_cell_vessels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_cell_vessels_id_seq', 1, false);


--
-- Name: sampled_fishing_operations_categories; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_fishing_operations_categories (
    id integer NOT NULL,
    id_fishing_operation integer NOT NULL,
    id_commercial_category smallint NOT NULL
);


ALTER TABLE public.sampled_fishing_operations_categories OWNER TO postgres;

--
-- Name: sampled_fishing_operations_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_fishing_operations_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_fishing_operations_categories_id_seq OWNER TO postgres;

--
-- Name: sampled_fishing_operations_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_fishing_operations_categories_id_seq OWNED BY sampled_fishing_operations_categories.id;


--
-- Name: sampled_fishing_operations_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_fishing_operations_categories_id_seq', 1, false);


--
-- Name: sampled_fishing_operations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_fishing_operations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_fishing_operations_id_seq OWNER TO postgres;

--
-- Name: sampled_fishing_operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_fishing_operations_id_seq OWNED BY sampled_fishing_operations.id;


--
-- Name: sampled_fishing_operations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_fishing_operations_id_seq', 1, false);


--
-- Name: sampled_fishing_trips; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_fishing_trips (
    id integer NOT NULL,
    id_abstract_sampled_vessels integer NOT NULL,
    id_start_dt bigint NOT NULL,
    id_end_dt bigint NOT NULL,
    id_abstract_landing_site integer NOT NULL,
    id_sampler integer NOT NULL,
    prof_fishermen integer DEFAULT 11111 NOT NULL,
    part_time_fishermen integer DEFAULT 11111 NOT NULL,
    n_operations_estimated integer DEFAULT 11111 NOT NULL,
    n_operations_calculated integer DEFAULT 11111 NOT NULL,
    catch_weight_estimated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_weight_calculated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_catch_weight_units smallint NOT NULL,
    catch_no_boxes_estimated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_no_boxes_calculated numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_catch_no_boxes_units smallint NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    weight_box numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    catch_units_estimated integer DEFAULT 44444 NOT NULL,
    weight_unit numeric(18,10) DEFAULT 0.1111100000 NOT NULL,
    id_catch_units_units smallint NOT NULL,
    catch_units_calculated integer DEFAULT 44444 NOT NULL
);


ALTER TABLE public.sampled_fishing_trips OWNER TO postgres;

--
-- Name: sampled_fishing_trips_gears; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_fishing_trips_gears (
    id integer NOT NULL,
    id_fishing_trip integer NOT NULL,
    id_fishing_gear integer NOT NULL
);


ALTER TABLE public.sampled_fishing_trips_gears OWNER TO postgres;

--
-- Name: sampled_fishing_trips_gears_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_fishing_trips_gears_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_fishing_trips_gears_id_seq OWNER TO postgres;

--
-- Name: sampled_fishing_trips_gears_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_fishing_trips_gears_id_seq OWNED BY sampled_fishing_trips_gears.id;


--
-- Name: sampled_fishing_trips_gears_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_fishing_trips_gears_id_seq', 96, true);


--
-- Name: sampled_fishing_trips_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_fishing_trips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_fishing_trips_id_seq OWNER TO postgres;

--
-- Name: sampled_fishing_trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_fishing_trips_id_seq OWNED BY sampled_fishing_trips.id;


--
-- Name: sampled_fishing_trips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_fishing_trips_id_seq', 1, false);


--
-- Name: sampled_fishing_trips_zones; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_fishing_trips_zones (
    id integer NOT NULL,
    id_fishing_trip integer NOT NULL,
    id_fishing_zone integer NOT NULL
);


ALTER TABLE public.sampled_fishing_trips_zones OWNER TO postgres;

--
-- Name: sampled_fishing_trips_zones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_fishing_trips_zones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_fishing_trips_zones_id_seq OWNER TO postgres;

--
-- Name: sampled_fishing_trips_zones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_fishing_trips_zones_id_seq OWNED BY sampled_fishing_trips_zones.id;


--
-- Name: sampled_fishing_trips_zones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_fishing_trips_zones_id_seq', 859, true);


--
-- Name: sampled_levels; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_levels (
    id integer NOT NULL,
    id_level integer NOT NULL,
    sample_size integer NOT NULL,
    population_size integer NOT NULL,
    id_strategy smallint NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    comments text DEFAULT 'missing'::text NOT NULL,
    id_sampling_technique integer NOT NULL
);


ALTER TABLE public.sampled_levels OWNER TO postgres;

--
-- Name: sampled_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_levels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_levels_id_seq OWNER TO postgres;

--
-- Name: sampled_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_levels_id_seq OWNED BY sampled_levels.id;


--
-- Name: sampled_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_levels_id_seq', 1, false);


--
-- Name: sampled_strata_vessels; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sampled_strata_vessels (
    id integer NOT NULL,
    id_minor_strata integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.sampled_strata_vessels OWNER TO postgres;

--
-- Name: sampled_strata_vessels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sampled_strata_vessels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sampled_strata_vessels_id_seq OWNER TO postgres;

--
-- Name: sampled_strata_vessels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sampled_strata_vessels_id_seq OWNED BY sampled_strata_vessels.id;


--
-- Name: sampled_strata_vessels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sampled_strata_vessels_id_seq', 1, false);


--
-- Name: t_distribution; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE t_distribution (
    p numeric(5,3),
    df integer
);


ALTER TABLE public.t_distribution OWNER TO postgres;

--
-- Name: ui_boolean_mapping; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_boolean_mapping (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nameeng character varying(50) DEFAULT 'missing'::character varying NOT NULL,
    val boolean NOT NULL
);


ALTER TABLE public.ui_boolean_mapping OWNER TO postgres;

--
-- Name: ui_boolean_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_boolean_mapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_boolean_mapping_id_seq OWNER TO postgres;

--
-- Name: ui_boolean_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_boolean_mapping_id_seq OWNED BY ui_boolean_mapping.id;


--
-- Name: ui_boolean_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_boolean_mapping_id_seq', 1, false);


--
-- Name: ui_forms; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_forms (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text DEFAULT ' missing'::text NOT NULL,
    comments text DEFAULT ' missing'::text NOT NULL
);


ALTER TABLE public.ui_forms OWNER TO postgres;

--
-- Name: ui_forms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_forms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_forms_id_seq OWNER TO postgres;

--
-- Name: ui_forms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_forms_id_seq OWNED BY ui_forms.id;


--
-- Name: ui_forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_forms_id_seq', 1, false);


--
-- Name: ui_role; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_role (
    id integer NOT NULL,
    name character varying(10) NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    new boolean DEFAULT false NOT NULL,
    view boolean NOT NULL,
    modify boolean DEFAULT false NOT NULL,
    remove boolean NOT NULL,
    report boolean DEFAULT false NOT NULL,
    admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ui_role OWNER TO postgres;

--
-- Name: ui_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_role_id_seq OWNER TO postgres;

--
-- Name: ui_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_role_id_seq OWNED BY ui_role.id;


--
-- Name: ui_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_role_id_seq', 1, false);


--
-- Name: ui_rule_ptrs; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_rule_ptrs (
    id integer NOT NULL,
    field smallint NOT NULL,
    id_rules integer DEFAULT 4444 NOT NULL,
    active smallint DEFAULT 1 NOT NULL,
    form integer DEFAULT 17 NOT NULL,
    mapper integer DEFAULT 44444 NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ui_rule_ptrs OWNER TO postgres;

--
-- Name: ui_rule_ptrs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_rule_ptrs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_rule_ptrs_id_seq OWNER TO postgres;

--
-- Name: ui_rule_ptrs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_rule_ptrs_id_seq OWNED BY ui_rule_ptrs.id;


--
-- Name: ui_rule_ptrs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_rule_ptrs_id_seq', 1, false);


--
-- Name: ui_rule_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_rule_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text
);


ALTER TABLE public.ui_rule_types OWNER TO postgres;

--
-- Name: ui_rule_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_rule_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_rule_types_id_seq OWNER TO postgres;

--
-- Name: ui_rule_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_rule_types_id_seq OWNED BY ui_rule_types.id;


--
-- Name: ui_rule_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_rule_types_id_seq', 1, false);


--
-- Name: ui_rules; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_rules (
    id integer NOT NULL,
    field smallint DEFAULT 4444 NOT NULL,
    type smallint DEFAULT 6 NOT NULL,
    rule text NOT NULL,
    sql_checked numeric(3,0) DEFAULT 0 NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    form integer DEFAULT 17 NOT NULL,
    mapper smallint DEFAULT 4444 NOT NULL
);


ALTER TABLE public.ui_rules OWNER TO postgres;

--
-- Name: COLUMN ui_rules.field; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ui_rules.field IS 'This stores the field index to which the query refers';


--
-- Name: COLUMN ui_rules.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ui_rules.type IS 'This stores the rule type (validation, default, pre-trigger,post-trigger)';


--
-- Name: COLUMN ui_rules.rule; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ui_rules.rule IS 'rule or group of rules, for default, validation and post-trigger';


--
-- Name: COLUMN ui_rules.sql_checked; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN ui_rules.sql_checked IS 'this will be the output of a function that checks the sql syntax';


--
-- Name: ui_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_rules_id_seq OWNER TO postgres;

--
-- Name: ui_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_rules_id_seq OWNED BY ui_rules.id;


--
-- Name: ui_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_rules_id_seq', 1, false);


--
-- Name: ui_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ui_user (
    username character varying(10) NOT NULL,
    password character varying(10) NOT NULL,
    role_id smallint NOT NULL,
    id integer NOT NULL,
    description text DEFAULT 'missing'::text NOT NULL
);


ALTER TABLE public.ui_user OWNER TO postgres;

--
-- Name: ui_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ui_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ui_user_id_seq OWNER TO postgres;

--
-- Name: ui_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ui_user_id_seq OWNED BY ui_user.id;


--
-- Name: ui_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ui_user_id_seq', 1, false);


--
-- Name: view_foreignkeys; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW view_foreignkeys AS
    SELECT fk.table_name AS fk_table, cu.column_name AS fk_column, pk.table_name AS pk_table, pt.column_name AS pk_column, c.constraint_name FROM ((((information_schema.referential_constraints c JOIN information_schema.table_constraints fk ON (((c.constraint_name)::text = (fk.constraint_name)::text))) JOIN information_schema.table_constraints pk ON (((c.unique_constraint_name)::text = (pk.constraint_name)::text))) JOIN information_schema.key_column_usage cu ON (((c.constraint_name)::text = (cu.constraint_name)::text))) JOIN (SELECT i1.table_name, i2.column_name FROM (information_schema.table_constraints i1 JOIN information_schema.key_column_usage i2 ON (((i1.constraint_name)::text = (i2.constraint_name)::text))) WHERE ((i1.constraint_type)::text = 'primary key'::text)) pt ON (((pt.table_name)::text = (pk.table_name)::text)));


ALTER TABLE public.view_foreignkeys OWNER TO postgres;

--
-- Name: viewals; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewals AS
    SELECT ref_landingsite_type.name, ref_abstract_landingsite.name AS expr1 FROM (ref_abstract_landingsite JOIN ref_landingsite_type ON ((ref_abstract_landingsite.id_landingsite_type = ref_landingsite_type.id)));


ALTER TABLE public.viewals OWNER TO postgres;

--
-- Name: viewals4filtercombotrips_logbook; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewals4filtercombotrips_logbook AS
    SELECT ref_abstract_landingsite.name, fr_gls2als.id_gls FROM (((((ref_minor_strata JOIN fr_time ON ((ref_minor_strata.id_frame_time = fr_time.id))) JOIN fr_frame ON ((fr_time.id_frame = fr_frame.id))) JOIN fr_sub_frame ON ((fr_frame.id = fr_sub_frame.id_frame))) JOIN fr_gls2als ON ((fr_sub_frame.id = fr_gls2als.id_sub_frame))) JOIN ref_abstract_landingsite ON ((fr_gls2als.id_abstract_landingsite = ref_abstract_landingsite.id))) WHERE ((ref_minor_strata.id = 27) AND (fr_gls2als.id_gls = (SELECT ref_minor_strata_1.id_gls FROM ref_minor_strata ref_minor_strata_1 WHERE (ref_minor_strata_1.id = 27))));


ALTER TABLE public.viewals4filtercombotrips_logbook OWNER TO postgres;

--
-- Name: viewcatchbygear; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewcatchbygear AS
    SELECT ref_gears.name AS gear, sum(sampled_fishing_operations.catch_weight_estimated) AS catch FROM (sampled_fishing_operations JOIN ref_gears ON ((sampled_fishing_operations.id_gear = ref_gears.id))) GROUP BY sampled_fishing_operations.id_gear, ref_gears.name;


ALTER TABLE public.viewcatchbygear OWNER TO postgres;

--
-- Name: viewcheckoperationcat; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewcheckoperationcat AS
    SELECT sampled_fishing_operations.id, ref_commercial_categories.name FROM ((sampled_fishing_operations JOIN sampled_fishing_operations_categories ON ((sampled_fishing_operations.id = sampled_fishing_operations_categories.id_fishing_operation))) JOIN ref_commercial_categories ON ((sampled_fishing_operations_categories.id_commercial_category = ref_commercial_categories.id))) WHERE (sampled_fishing_operations.id = 10);


ALTER TABLE public.viewcheckoperationcat OWNER TO postgres;

--
-- Name: viewcommercialcategoriesandgears4vessels; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewcommercialcategoriesandgears4vessels AS
    SELECT ref_vessels.name AS expr1, a2.name AS mainspecies, b2.name AS maingear, a1.name AS secspecies, b1.name AS secgear FROM ((((ref_vessels JOIN ref_commercial_categories a1 ON ((ref_vessels.secondarygeartargetgroupofspecies = a1.id))) JOIN ref_commercial_categories a2 ON ((ref_vessels.maingeartargetgroupofspecies = a2.id))) JOIN ref_gears b1 ON ((ref_vessels.secondarygeartype = b1.id))) JOIN ref_gears b2 ON ((ref_vessels.maingeartype = b2.id)));


ALTER TABLE public.viewcommercialcategoriesandgears4vessels OWNER TO postgres;

--
-- Name: viewcopysites; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewcopysites AS
    SELECT fr_frame.name FROM fr_frame WHERE ((NOT ((fr_frame.name)::text IN (SELECT gl_null_replacements.internal_name FROM gl_null_replacements))) AND ((fr_frame.name)::text <> 'outside'::text));


ALTER TABLE public.viewcopysites OWNER TO postgres;

--
-- Name: viewfieldsnonimportedtables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewfieldsnonimportedtables AS
    SELECT info_fields.table_name, info_fields.field_name, info_fields.reviewed_type AS type, info_fields.reviewed_size AS size FROM info_fields WHERE ((info_fields.table_name)::text IN (SELECT info_tables.name FROM info_tables WHERE (NOT ((info_tables.name)::text IN (SELECT info_tables_import.imported_name FROM info_tables_import))))) ORDER BY info_fields.table_name;


ALTER TABLE public.viewfieldsnonimportedtables OWNER TO postgres;

--
-- Name: viewfilter4combotrip; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewfilter4combotrip AS
    SELECT sampled_cell.id_abstract_landingsite FROM sampled_cell WHERE (sampled_cell.id = 1);


ALTER TABLE public.viewfilter4combotrip OWNER TO postgres;

--
-- Name: viewgls4selectedframe; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewgls4selectedframe AS
    SELECT fr_f2gls.id_gls FROM ((fr_sub_frame JOIN fr_f2gls ON ((fr_sub_frame.id = fr_f2gls.id_sub_frame))) JOIN (fr_frame JOIN fr_time ON ((fr_frame.id = fr_time.id_frame))) ON ((fr_sub_frame.id_frame = fr_frame.id))) WHERE ((fr_time.id = 105) AND (fr_sub_frame.type = (SELECT ref_frame.id FROM ref_frame WHERE ((ref_frame.name)::text = 'root'::text))));


ALTER TABLE public.viewgls4selectedframe OWNER TO postgres;

--
-- Name: viewhasrecords; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewhasrecords AS
    SELECT abstract_sampled_vessels.vesselid, sampled_cell_vessel_types.id_cell FROM ((sampled_cell_vessel_types JOIN sampled_cell_vessels ON ((sampled_cell_vessel_types.id = sampled_cell_vessels.id_cell_vessel_types))) JOIN abstract_sampled_vessels ON ((sampled_cell_vessels.id = abstract_sampled_vessels.id_sampled_cell_vessels))) WHERE (sampled_cell_vessel_types.id_cell = 499) ORDER BY abstract_sampled_vessels.vesselid DESC;


ALTER TABLE public.viewhasrecords OWNER TO postgres;

--
-- Name: viewimportedtablechanges; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewimportedtablechanges AS
    SELECT info_fields.table_name AS expr1, info_fields.field_name AS expr2, info_fields.original_type, info_fields.reviewed_type, info_fields.reviewed_size, info_fields.reviewed_size AS expr3, info_fields.change2autoincrement, info_fields.hasdefaultvalue, info_fields.defaultvalue, info_fields.description, info_fields.comments, info_fields.createuniquecstrt FROM (info_fields JOIN info_tables_import ON (((info_fields.table_name)::text = (info_tables_import.imported_name)::text)));


ALTER TABLE public.viewimportedtablechanges OWNER TO postgres;

--
-- Name: viewinfochanges; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewinfochanges AS
    SELECT info_changes."table", info_changes."column" AS field, CASE info_changes."from" WHEN '274b68192b056e268f128ff63bfcd4a4'::text THEN 'nothing'::character varying ELSE info_changes."from" END AS "original value", info_changes."to" AS "new value", gl_dates.date_local AS "timestamp" FROM (info_changes JOIN gl_dates ON ((info_changes.id_datetime = gl_dates.id)));


ALTER TABLE public.viewinfochanges OWNER TO postgres;

--
-- Name: viewinfofields; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewinfofields AS
    SELECT info_fields.id, info_fields.table_name, info_fields.field_name, info_fields.original_type, info_fields.reviewed_type, info_fields.original_size, info_fields.reviewed_size, info_fields.change2autoincrement, info_fields.hasdefaultvalue, info_fields.defaultvalue, info_fields.description, info_fields.comments, info_fields.createuniquecstrt FROM info_fields ORDER BY info_fields.table_name;


ALTER TABLE public.viewinfofields OWNER TO postgres;

--
-- Name: viewinvesselsreasons; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewinvesselsreasons AS
    SELECT ref_changes.id, ref_changes.description, ref_changes.name, ref_changes.input FROM ref_changes WHERE (ref_changes.input = true);


ALTER TABLE public.viewinvesselsreasons OWNER TO postgres;

--
-- Name: viewlastinsertedlocation; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewlastinsertedlocation AS
    SELECT gl_session.id_location FROM gl_session ORDER BY gl_session.id DESC LIMIT 1;


ALTER TABLE public.viewlastinsertedlocation OWNER TO postgres;

--
-- Name: viewls4gls; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewls4gls AS
    SELECT fr_gls2als.id_abstract_landingsite AS ls, ref_minor_strata.id_gls, fr_gls2als.id_gls AS expr1 FROM ((((ref_minor_strata JOIN fr_time ON ((ref_minor_strata.id_frame_time = fr_time.id))) JOIN fr_frame ON ((fr_time.id_frame = fr_frame.id))) JOIN fr_sub_frame ON ((fr_frame.id = fr_sub_frame.id_frame))) JOIN fr_gls2als ON (((fr_sub_frame.id = fr_gls2als.id_sub_frame) AND (ref_minor_strata.id_gls = fr_gls2als.id_gls)))) WHERE (ref_minor_strata.id = 20);


ALTER TABLE public.viewls4gls OWNER TO postgres;

--
-- Name: viewmaingear; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewmaingear AS
    SELECT ref_gears.id, ref_gears.name FROM ref_gears WHERE ((ref_gears.name)::text <> 'n/a'::text);


ALTER TABLE public.viewmaingear OWNER TO postgres;

--
-- Name: viewmsdates; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewmsdates AS
    SELECT ref_minor_strata.name, f1.date_local AS start_date, f2.date_local AS end_date, ref_minor_strata.isclosed FROM ((ref_minor_strata JOIN gl_dates f1 ON ((ref_minor_strata.id_start_dt = f1.id))) JOIN gl_dates f2 ON ((ref_minor_strata.id_end_dt = f2.id))) WHERE (ref_minor_strata.id_frame_time = 136);


ALTER TABLE public.viewmsdates OWNER TO postgres;

--
-- Name: viewnonimportedtables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewnonimportedtables AS
    SELECT info_fields.table_name, info_fields.field_name, info_fields.reviewed_type AS type, info_fields.reviewed_size AS size FROM info_fields WHERE ((info_fields.table_name)::text IN (SELECT info_tables.name FROM info_tables WHERE (NOT ((info_tables.name)::text IN (SELECT info_tables_import.imported_name FROM info_tables_import))))) ORDER BY info_fields.table_name;


ALTER TABLE public.viewnonimportedtables OWNER TO postgres;

--
-- Name: viewnotin; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewnotin AS
    SELECT abstract_changes_temp_vessel.vesselid FROM abstract_changes_temp_vessel WHERE ((abstract_changes_temp_vessel.id_cell = 27) AND (abstract_changes_temp_vessel.to_ls = (SELECT ref_abstract_landingsite.id FROM ref_abstract_landingsite WHERE ((ref_abstract_landingsite.name)::text = 'outside'::text))));


ALTER TABLE public.viewnotin OWNER TO postgres;

--
-- Name: viewoutvesselsreasons; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewoutvesselsreasons AS
    SELECT ref_changes.id, ref_changes.description, ref_changes.name FROM ref_changes;


ALTER TABLE public.viewoutvesselsreasons OWNER TO postgres;

--
-- Name: viewports; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewports AS
    SELECT ref_ports.id, ref_ports.name, ref_ports.portcode, ref_ports.geosubarea, ref_ports.latitude, ref_ports.longitude FROM ref_ports WHERE (NOT ((ref_ports.name)::text IN (SELECT gl_null_replacements.internal_name FROM gl_null_replacements)));


ALTER TABLE public.viewports OWNER TO postgres;

--
-- Name: viewpreviewcatch; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewpreviewcatch AS
    SELECT sampled_catch.id, ref_commercial_categories.name AS "Commercial Category", sampled_catch.catch_weight_estimated AS "Total Catch", ref_units.name AS units FROM ((sampled_catch JOIN ref_commercial_categories ON ((sampled_catch.id_commercial_category = ref_commercial_categories.id))) JOIN ref_units ON (((((sampled_catch.id_catch_no_boxes_units = ref_units.id) AND (sampled_catch.id_catch_units_units = ref_units.id)) AND (sampled_catch.id_catch_weight_units = ref_units.id)) AND (sampled_catch.id_sample_units = ref_units.id)))) WHERE (sampled_catch.id_fishing_operation = 42);


ALTER TABLE public.viewpreviewcatch OWNER TO postgres;

--
-- Name: viewreasons2permchangels; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewreasons2permchangels AS
    SELECT changes_perm_vessel.vesselid, ref_changes.name FROM (changes_perm_vessel JOIN ref_changes ON ((changes_perm_vessel.id_ref_changes = ref_changes.id)));


ALTER TABLE public.viewreasons2permchangels OWNER TO postgres;

--
-- Name: viewsampvesseltypes; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewsampvesseltypes AS
    SELECT sampled_cell_vessel_types.id, ref_vessel_types.name FROM (sampled_cell_vessel_types JOIN ref_vessel_types ON ((sampled_cell_vessel_types.id_vessel_type = ref_vessel_types.id))) WHERE (sampled_cell_vessel_types.id_cell = 1);


ALTER TABLE public.viewsampvesseltypes OWNER TO postgres;

--
-- Name: viewselectlogbooksampling; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewselectlogbooksampling AS
    SELECT fr_als2vessel.vesselid FROM ((((ref_group_of_landingsites JOIN ref_minor_strata ON ((ref_group_of_landingsites.id = ref_minor_strata.id_gls))) JOIN fr_gls2als ON ((ref_group_of_landingsites.id = fr_gls2als.id_gls))) JOIN ref_abstract_landingsite ON ((fr_gls2als.id_abstract_landingsite = ref_abstract_landingsite.id))) JOIN fr_als2vessel ON ((ref_abstract_landingsite.id = fr_als2vessel.id_abstract_landingsite))) WHERE (ref_minor_strata.id = 1);


ALTER TABLE public.viewselectlogbooksampling OWNER TO postgres;

--
-- Name: viewstartenddatefrtime; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewstartenddatefrtime AS
    SELECT dt1.date_local AS start_dt, dt2.date_local AS end_dt FROM ((fr_time JOIN gl_dates dt1 ON ((fr_time.id_start_dt = dt1.id))) JOIN gl_dates dt2 ON ((fr_time.id_end_dt = dt2.id))) WHERE (fr_time.id = 293);


ALTER TABLE public.viewstartenddatefrtime OWNER TO postgres;

--
-- Name: viewtablesimport; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewtablesimport AS
    SELECT info_tables_import.original_name, info_tables_import.imported_name, info_tables_import.convertpk2int, info_tables_import.comments, info_tables.description FROM (info_tables_import JOIN info_tables ON (((info_tables_import.imported_name)::text = (info_tables.name)::text)));


ALTER TABLE public.viewtablesimport OWNER TO postgres;

--
-- Name: viewunionaddedvessels; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewunionaddedvessels AS
    SELECT DISTINCT ref_vessel_types.name FROM (ref_vessels JOIN ref_vessel_types ON ((ref_vessels.vesseltype = ref_vessel_types.id))) WHERE (ref_vessels.vesselid IN (SELECT ref_vessels.vesselid FROM abstract_changes_temp_vessel WHERE ((abstract_changes_temp_vessel.id_cell = 35) AND (abstract_changes_temp_vessel.to_ls = 38))));


ALTER TABLE public.viewunionaddedvessels OWNER TO postgres;

--
-- Name: viewvessels4cell; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewvessels4cell AS
    SELECT ref_vessels.vesselid, ref_vessels.name, ref_vessels.vesseltype FROM (fr_als2vessel JOIN ref_vessels ON ((fr_als2vessel.vesselid = ref_vessels.vesselid))) WHERE (((fr_als2vessel.id_sub_frame = (SELECT fr_sub_frame.id FROM fr_sub_frame WHERE ((fr_sub_frame.type = (SELECT ref_frame.id FROM ref_frame WHERE ((ref_frame.name)::text = 'root'::text))) AND (fr_sub_frame.id_frame = 3)))) AND (fr_als2vessel.id_abstract_landingsite = (SELECT sampled_cell.id_abstract_landingsite FROM sampled_cell WHERE (sampled_cell.id = 3)))) AND (NOT (fr_als2vessel.vesselid IN (SELECT abstract_changes_temp_vessel.vesselid FROM abstract_changes_temp_vessel WHERE ((abstract_changes_temp_vessel.id_cell = 3) AND (abstract_changes_temp_vessel.to_ls = (SELECT ref_abstract_landingsite.id FROM ref_abstract_landingsite WHERE ((ref_abstract_landingsite.name)::text = 'outside'::text)))))))) UNION SELECT ref_vessels_1.vesselid, ref_vessels_1.name, ref_vessels_1.vesseltype FROM (fr_als2vessel fr_als2vessel_1 JOIN ref_vessels ref_vessels_1 ON ((fr_als2vessel_1.vesselid = ref_vessels_1.vesselid))) WHERE (ref_vessels_1.vesselid IN (SELECT changes_temp_vessel_1.vesselid FROM abstract_changes_temp_vessel changes_temp_vessel_1 WHERE ((changes_temp_vessel_1.id_cell = 3) AND (changes_temp_vessel_1.to_ls = (SELECT sampled_cell_1.id_abstract_landingsite FROM sampled_cell sampled_cell_1 WHERE (sampled_cell_1.id = 3))))));


ALTER TABLE public.viewvessels4cell OWNER TO postgres;

--
-- Name: viewvessels4ms; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewvessels4ms AS
    SELECT fr_als2vessel_1.vesselid, fr_gls2als.id_gls FROM (((fr_als2vessel JOIN fr_gls2als ON ((fr_als2vessel.id = fr_gls2als.id))) JOIN fr_als2vessel fr_als2vessel_1 ON ((fr_als2vessel.id = fr_als2vessel_1.id))) JOIN ref_vessels ON (((fr_als2vessel.vesselid = ref_vessels.vesselid) AND (fr_als2vessel_1.vesselid = ref_vessels.vesselid)))) WHERE ((fr_als2vessel.id_sub_frame = (SELECT fr_sub_frame.id FROM fr_sub_frame WHERE ((fr_sub_frame.type = (SELECT ref_frame.id FROM ref_frame WHERE ((ref_frame.name)::text = 'root'::text))) AND (fr_sub_frame.id_frame = 5)))) AND (fr_gls2als.id_gls = (SELECT ref_minor_strata.id_gls FROM ref_minor_strata WHERE (ref_minor_strata.id = 223))));


ALTER TABLE public.viewvessels4ms OWNER TO postgres;

--
-- Name: viewvesselslogbook; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewvesselslogbook AS
    SELECT abstract_sampled_vessels.vesselid, ref_vessels.name, ref_sample_status.name AS expr1 FROM (((abstract_sampled_vessels JOIN ref_vessels ON ((abstract_sampled_vessels.vesselid = ref_vessels.vesselid))) JOIN sampled_strata_vessels ON ((abstract_sampled_vessels.id_sampled_strata_vessels = sampled_strata_vessels.id))) JOIN ref_sample_status ON ((abstract_sampled_vessels.id_sample_status = ref_sample_status.id))) WHERE (sampled_strata_vessels.id_minor_strata = 270);


ALTER TABLE public.viewvesselslogbook OWNER TO postgres;

--
-- Name: viewvesselssampling; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewvesselssampling AS
    SELECT abstract_sampled_vessels.vesselid, ref_vessels.name, ref_sample_status.name AS status FROM (((abstract_sampled_vessels JOIN sampled_cell_vessels ON ((abstract_sampled_vessels.id_sampled_cell_vessels = sampled_cell_vessels.id))) JOIN ref_vessels ON ((abstract_sampled_vessels.vesselid = ref_vessels.vesselid))) JOIN ref_sample_status ON ((abstract_sampled_vessels.id_sample_status = ref_sample_status.id))) WHERE (sampled_cell_vessels.id_cell_vessel_types = 50);


ALTER TABLE public.viewvesselssampling OWNER TO postgres;

--
-- Name: viewvesseltypes4cell; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewvesseltypes4cell AS
    SELECT ref_vessel_types.name FROM ((fr_als2vessel JOIN ref_vessels ON ((fr_als2vessel.vesselid = ref_vessels.vesselid))) JOIN ref_vessel_types ON ((ref_vessels.vesseltype = ref_vessel_types.id))) WHERE (((fr_als2vessel.id_sub_frame = (SELECT fr_sub_frame.id FROM fr_sub_frame WHERE ((fr_sub_frame.type = (SELECT ref_frame.id FROM ref_frame WHERE ((ref_frame.name)::text = 'root'::text))) AND (fr_sub_frame.id_frame = 3)))) AND (fr_als2vessel.id_abstract_landingsite = (SELECT sampled_cell.id_abstract_landingsite FROM sampled_cell WHERE (sampled_cell.id = 2)))) AND (NOT (fr_als2vessel.vesselid IN (SELECT abstract_changes_temp_vessel.vesselid FROM abstract_changes_temp_vessel WHERE ((abstract_changes_temp_vessel.id_cell = 2) AND (abstract_changes_temp_vessel.to_ls = (SELECT ref_abstract_landingsite.id FROM ref_abstract_landingsite WHERE ((ref_abstract_landingsite.name)::text = 'outside'::text)))))))) UNION SELECT ref_vessel_types_1.name FROM ((fr_als2vessel fr_als2vessel_1 JOIN ref_vessels ref_vessels_1 ON ((fr_als2vessel_1.vesselid = ref_vessels_1.vesselid))) JOIN ref_vessel_types ref_vessel_types_1 ON ((ref_vessels_1.vesseltype = ref_vessel_types_1.id))) WHERE (ref_vessels_1.vesselid IN (SELECT changes_temp_vessel_1.vesselid FROM abstract_changes_temp_vessel changes_temp_vessel_1 WHERE ((changes_temp_vessel_1.id_cell = 53) AND (changes_temp_vessel_1.to_ls = (SELECT sampled_cell_1.id_abstract_landingsite FROM sampled_cell sampled_cell_1 WHERE (sampled_cell_1.id = 2))))));


ALTER TABLE public.viewvesseltypes4cell OWNER TO postgres;

--
-- Name: viewvesseltypesgears; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW viewvesseltypesgears AS
    SELECT ref_vessels.name, ref_vessel_types.name AS expr1, ref_gears.name AS expr2 FROM ((ref_vessels JOIN ref_vessel_types ON ((ref_vessels.vesseltype = ref_vessel_types.id))) JOIN ref_gears ON (((ref_vessels.secondarygeartype = ref_gears.id) AND (ref_vessels.maingeartype = ref_gears.id))));


ALTER TABLE public.viewvesseltypesgears OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel ALTER COLUMN id SET DEFAULT nextval('abstract_changes_temp_vessel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_sampled_vessels ALTER COLUMN id SET DEFAULT nextval('abstract_sampled_vessels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_gls ALTER COLUMN id SET DEFAULT nextval('changes_perm_gls_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_ls ALTER COLUMN id SET DEFAULT nextval('changes_perm_ls_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_vessel ALTER COLUMN id SET DEFAULT nextval('changes_perm_vessel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_als2vessel ALTER COLUMN id SET DEFAULT nextval('fr_als2vessel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_f2gls ALTER COLUMN id SET DEFAULT nextval('fr_f2gls_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_frame ALTER COLUMN id SET DEFAULT nextval('fr_frame_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_gls2als ALTER COLUMN id SET DEFAULT nextval('fr_gls2als_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_node_description ALTER COLUMN id SET DEFAULT nextval('fr_node_description_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_sub_frame ALTER COLUMN id SET DEFAULT nextval('fr_sub_frame_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_time ALTER COLUMN id SET DEFAULT nextval('fr_time_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_tree ALTER COLUMN id SET DEFAULT nextval('fr_tree_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_dates ALTER COLUMN id SET DEFAULT nextval('gl_dates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_null_replacements ALTER COLUMN id SET DEFAULT nextval('gl_null_replacements_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_session ALTER COLUMN id SET DEFAULT nextval('gl_session_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_changes ALTER COLUMN id SET DEFAULT nextval('info_changes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_client ALTER COLUMN id SET DEFAULT nextval('info_client_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_fields ALTER COLUMN id SET DEFAULT nextval('info_fields_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_fk ALTER COLUMN id SET DEFAULT nextval('info_fk_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_master ALTER COLUMN id SET DEFAULT nextval('info_master_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_tables ALTER COLUMN id SET DEFAULT nextval('info_tables_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_tables_import ALTER COLUMN id SET DEFAULT nextval('info_tables_import_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_triggers ALTER COLUMN id SET DEFAULT nextval('info_triggers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_abstract_landingsite ALTER COLUMN id SET DEFAULT nextval('ref_abstract_landingsite_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_authorisation_types ALTER COLUMN id SET DEFAULT nextval('ref_authorisation_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_changes ALTER COLUMN id SET DEFAULT nextval('ref_changes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_collectors ALTER COLUMN id SET DEFAULT nextval('ref_collectors_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_commercial_categories ALTER COLUMN id SET DEFAULT nextval('ref_commercial_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_countries ALTER COLUMN id SET DEFAULT nextval('ref_countries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_datetime_type ALTER COLUMN id SET DEFAULT nextval('ref_datetime_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_engine_locations ALTER COLUMN id SET DEFAULT nextval('ref_engine_locations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_fishing_zones ALTER COLUMN id SET DEFAULT nextval('ref_fishing_zones_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_fleet_segmentation ALTER COLUMN id SET DEFAULT nextval('ref_fleet_segmentation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_frame ALTER COLUMN id SET DEFAULT nextval('ref_frame_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_gear_classes ALTER COLUMN id SET DEFAULT nextval('ref_gear_classes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_gears ALTER COLUMN id SET DEFAULT nextval('ref_gears_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_group_of_landingsites ALTER COLUMN id SET DEFAULT nextval('ref_group_of_landingsites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_issuing_offices ALTER COLUMN id SET DEFAULT nextval('ref_issuing_offices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_landingsite_type ALTER COLUMN id SET DEFAULT nextval('ref_landingsite_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_levels ALTER COLUMN id SET DEFAULT nextval('ref_levels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_location ALTER COLUMN id SET DEFAULT nextval('ref_location_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_logbook_types ALTER COLUMN id SET DEFAULT nextval('ref_logbook_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_marine_fishery_subsectors ALTER COLUMN id SET DEFAULT nextval('ref_marine_fishery_subsectors_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_minor_strata ALTER COLUMN id SET DEFAULT nextval('ref_minor_strata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_months ALTER COLUMN id SET DEFAULT nextval('ref_months_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_no_recording_activities ALTER COLUMN id SET DEFAULT nextval('ref_no_recording_activities_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_operational_statuses ALTER COLUMN id SET DEFAULT nextval('ref_operational_statuses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_ports ALTER COLUMN id SET DEFAULT nextval('ref_ports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_sample_origin ALTER COLUMN id SET DEFAULT nextval('ref_sample_origin_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_sample_status ALTER COLUMN id SET DEFAULT nextval('ref_sample_status_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_samplers ALTER COLUMN id SET DEFAULT nextval('ref_samplers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_sampling_technique ALTER COLUMN id SET DEFAULT nextval('ref_sampling_technique_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_source ALTER COLUMN id SET DEFAULT nextval('ref_source_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_species ALTER COLUMN id SET DEFAULT nextval('ref_species_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_stocks ALTER COLUMN id SET DEFAULT nextval('ref_stocks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_strategy ALTER COLUMN id SET DEFAULT nextval('ref_strategy_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_units ALTER COLUMN id SET DEFAULT nextval('ref_units_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessel_types ALTER COLUMN id SET DEFAULT nextval('ref_vessel_types_id_seq'::regclass);


--
-- Name: vesselid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels ALTER COLUMN vesselid SET DEFAULT nextval('ref_vessels_vesselid_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch ALTER COLUMN id SET DEFAULT nextval('sampled_catch_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell ALTER COLUMN id SET DEFAULT nextval('sampled_cell_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell_vessel_types ALTER COLUMN id SET DEFAULT nextval('sampled_cell_vessel_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell_vessels ALTER COLUMN id SET DEFAULT nextval('sampled_cell_vessels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations ALTER COLUMN id SET DEFAULT nextval('sampled_fishing_operations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations_categories ALTER COLUMN id SET DEFAULT nextval('sampled_fishing_operations_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips ALTER COLUMN id SET DEFAULT nextval('sampled_fishing_trips_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips_gears ALTER COLUMN id SET DEFAULT nextval('sampled_fishing_trips_gears_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips_zones ALTER COLUMN id SET DEFAULT nextval('sampled_fishing_trips_zones_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_levels ALTER COLUMN id SET DEFAULT nextval('sampled_levels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_strata_vessels ALTER COLUMN id SET DEFAULT nextval('sampled_strata_vessels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_boolean_mapping ALTER COLUMN id SET DEFAULT nextval('ui_boolean_mapping_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_forms ALTER COLUMN id SET DEFAULT nextval('ui_forms_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_role ALTER COLUMN id SET DEFAULT nextval('ui_role_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rule_ptrs ALTER COLUMN id SET DEFAULT nextval('ui_rule_ptrs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rule_types ALTER COLUMN id SET DEFAULT nextval('ui_rule_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rules ALTER COLUMN id SET DEFAULT nextval('ui_rules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_user ALTER COLUMN id SET DEFAULT nextval('ui_user_id_seq'::regclass);


--
-- Data for Name: abstract_changes_temp_vessel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY abstract_changes_temp_vessel (id, id_cell, vesselid, from_ls, to_ls, id_ref_changes, id_source, id_minor_strata) FROM stdin;
\.
copy abstract_changes_temp_vessel (id, id_cell, vesselid, from_ls, to_ls, id_ref_changes, id_source, id_minor_strata)  from '$$PATH$$/3289.dat' ;
--
-- Data for Name: abstract_sampled_vessels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY abstract_sampled_vessels (id, id_source, vesselid, id_sample_origin, id_sample_status, id_sampled_cell_vessels, id_sampled_strata_vessels, comments) FROM stdin;
\.
copy abstract_sampled_vessels (id, id_source, vesselid, id_sample_origin, id_sample_status, id_sampled_cell_vessels, id_sampled_strata_vessels, comments)  from '$$PATH$$/3290.dat' ;
--
-- Data for Name: changes_perm_gls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY changes_perm_gls (id, id_sub_frame, id_gls, reason) FROM stdin;
\.
copy changes_perm_gls (id, id_sub_frame, id_gls, reason)  from '$$PATH$$/3291.dat' ;
--
-- Data for Name: changes_perm_ls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY changes_perm_ls (id, id_sub_frame, id_abstract_landingsite, reason) FROM stdin;
\.
copy changes_perm_ls (id, id_sub_frame, id_abstract_landingsite, reason)  from '$$PATH$$/3292.dat' ;
--
-- Data for Name: changes_perm_vessel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY changes_perm_vessel (id, id_sub_frame, vesselid, id_ref_changes) FROM stdin;
\.
copy changes_perm_vessel (id, id_sub_frame, vesselid, id_ref_changes)  from '$$PATH$$/3293.dat' ;
--
-- Data for Name: fr_als2vessel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_als2vessel (id, id_sub_frame, id_abstract_landingsite, vesselid) FROM stdin;
\.
copy fr_als2vessel (id, id_sub_frame, id_abstract_landingsite, vesselid)  from '$$PATH$$/3284.dat' ;
--
-- Data for Name: fr_f2gls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_f2gls (id, id_sub_frame, id_gls) FROM stdin;
\.
copy fr_f2gls (id, id_sub_frame, id_gls)  from '$$PATH$$/3294.dat' ;
--
-- Data for Name: fr_frame; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_frame (id, name, nameeng, description, id_cloned_previous_frame, id_source, comments) FROM stdin;
\.
copy fr_frame (id, name, nameeng, description, id_cloned_previous_frame, id_source, comments)  from '$$PATH$$/3295.dat' ;
--
-- Data for Name: fr_gls2als; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_gls2als (id, id_sub_frame, id_gls, id_abstract_landingsite) FROM stdin;
\.
copy fr_gls2als (id, id_sub_frame, id_gls, id_abstract_landingsite)  from '$$PATH$$/3285.dat' ;
--
-- Data for Name: fr_node_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_node_description (id, name, name_eng, description, old_code) FROM stdin;
\.
copy fr_node_description (id, name, name_eng, description, old_code)  from '$$PATH$$/3298.dat' ;
--
-- Data for Name: fr_sub_frame; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_sub_frame (id, type, description, comments, id_frame) FROM stdin;
\.
copy fr_sub_frame (id, type, description, comments, id_frame)  from '$$PATH$$/3296.dat' ;
--
-- Data for Name: fr_time; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_time (id, id_frame, id_start_dt, id_end_dt, comments, description) FROM stdin;
\.
copy fr_time (id, id_frame, id_start_dt, id_end_dt, comments, description)  from '$$PATH$$/3299.dat' ;
--
-- Data for Name: fr_tree; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY fr_tree (id, lft, rgt, parent, depth) FROM stdin;
\.
copy fr_tree (id, lft, rgt, parent, depth)  from '$$PATH$$/3300.dat' ;
--
-- Data for Name: gl_dates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY gl_dates (id, date_utc, date_local, date_type, comments) FROM stdin;
\.
copy gl_dates (id, date_utc, date_local, date_type, comments)  from '$$PATH$$/3301.dat' ;
--
-- Data for Name: gl_null_replacements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY gl_null_replacements (id, internal_name, name_eng, description, "varchar", "int", char3, char2, datetime, "bit", char4, char1, "smallint", "decimal") FROM stdin;
\.
copy gl_null_replacements (id, internal_name, name_eng, description, "varchar", "int", char3, char2, datetime, "bit", char4, char1, "smallint", "decimal")  from '$$PATH$$/3302.dat' ;
--
-- Data for Name: gl_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY gl_session (id, id_user, mac_address, id_base_date, id_location, id_start_dt, id_end_dt, comments) FROM stdin;
\.
copy gl_session (id, id_user, mac_address, id_base_date, id_location, id_start_dt, id_end_dt, comments)  from '$$PATH$$/3303.dat' ;
--
-- Data for Name: info_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_changes (id, "table", "column", "from", "to", id_session, id_datetime) FROM stdin;
\.
copy info_changes (id, "table", "column", "from", "to", id_session, id_datetime)  from '$$PATH$$/3304.dat' ;
--
-- Data for Name: info_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_client (id, client_id) FROM stdin;
\.
copy info_client (id, client_id)  from '$$PATH$$/3305.dat' ;
--
-- Data for Name: info_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_fields (id, table_name, field_name, original_type, reviewed_type, original_size, reviewed_size, change2autoincrement, hasdefaultvalue, defaultvalue, description, comments, createuniquecstrt, replacenulls, nullvalue) FROM stdin;
\.
copy info_fields (id, table_name, field_name, original_type, reviewed_type, original_size, reviewed_size, change2autoincrement, hasdefaultvalue, defaultvalue, description, comments, createuniquecstrt, replacenulls, nullvalue)  from '$$PATH$$/3306.dat' ;
--
-- Data for Name: info_fk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_fk (id, fk_table, fk_field, pk_table, pk_field) FROM stdin;
\.
copy info_fk (id, fk_table, fk_field, pk_table, pk_field)  from '$$PATH$$/3307.dat' ;
--
-- Data for Name: info_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_master (id, master_id) FROM stdin;
\.
copy info_master (id, master_id)  from '$$PATH$$/3308.dat' ;
--
-- Data for Name: info_tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_tables (id, name, description) FROM stdin;
\.
copy info_tables (id, name, description)  from '$$PATH$$/3309.dat' ;
--
-- Data for Name: info_tables_import; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_tables_import (id, original_name, imported_name, convertpk2int, comments, appendnullfields) FROM stdin;
\.
copy info_tables_import (id, original_name, imported_name, convertpk2int, comments, appendnullfields)  from '$$PATH$$/3310.dat' ;
--
-- Data for Name: info_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY info_triggers (id, table_name, field_name, new, mod, del) FROM stdin;
\.
copy info_triggers (id, table_name, field_name, new, mod, del)  from '$$PATH$$/3311.dat' ;
--
-- Data for Name: ref_abstract_landingsite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_abstract_landingsite (id, id_landingsite_type, id_port, id_collector, name, nameeng, description, comments) FROM stdin;
\.
copy ref_abstract_landingsite (id, id_landingsite_type, id_port, id_collector, name, nameeng, description, comments)  from '$$PATH$$/3286.dat' ;
--
-- Data for Name: ref_authorisation_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_authorisation_types (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_authorisation_types (id, description, name, nameeng, old_code)  from '$$PATH$$/3315.dat' ;
--
-- Data for Name: ref_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_changes (id, description, name, nameeng, old_code, input) FROM stdin;
\.
copy ref_changes (id, description, name, nameeng, old_code, input)  from '$$PATH$$/3316.dat' ;
--
-- Data for Name: ref_collectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_collectors (id, name, vesselid) FROM stdin;
\.
copy ref_collectors (id, name, vesselid)  from '$$PATH$$/3317.dat' ;
--
-- Data for Name: ref_commercial_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_commercial_categories (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_commercial_categories (id, description, name, nameeng, old_code)  from '$$PATH$$/3312.dat' ;
--
-- Data for Name: ref_countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_countries (id, description, name, nameeng, un, undp, iso2, iso3, gfcm, eu, medfisis, namefrn, nameesp, old_code) FROM stdin;
\.
copy ref_countries (id, description, name, nameeng, un, undp, iso2, iso3, gfcm, eu, medfisis, namefrn, nameesp, old_code)  from '$$PATH$$/3318.dat' ;
--
-- Data for Name: ref_datetime_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_datetime_type (id, name, nameeng, description) FROM stdin;
\.
copy ref_datetime_type (id, name, nameeng, description)  from '$$PATH$$/3319.dat' ;
--
-- Data for Name: ref_engine_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_engine_locations (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_engine_locations (id, description, name, nameeng, old_code)  from '$$PATH$$/3320.dat' ;
--
-- Data for Name: ref_fishing_zones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_fishing_zones (id, description, name, nameeng, old_code, ox, oy, dx, dy) FROM stdin;
\.
copy ref_fishing_zones (id, description, name, nameeng, old_code, ox, oy, dx, dy)  from '$$PATH$$/3321.dat' ;
--
-- Data for Name: ref_fleet_segmentation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_fleet_segmentation (id, description, name, nameeng, alphacode, old_code) FROM stdin;
\.
copy ref_fleet_segmentation (id, description, name, nameeng, alphacode, old_code)  from '$$PATH$$/3322.dat' ;
--
-- Data for Name: ref_frame; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_frame (id, name, nameeng, description, comments) FROM stdin;
\.
copy ref_frame (id, name, nameeng, description, comments)  from '$$PATH$$/3297.dat' ;
--
-- Data for Name: ref_gear_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_gear_classes (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_gear_classes (id, description, name, nameeng, old_code)  from '$$PATH$$/3323.dat' ;
--
-- Data for Name: ref_gears; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_gears (id, description, name, nameeng, matchingcodegear, geareu, gearstd, fishingtechniqueeu, old_code, gearclass, marinefisherysubsector) FROM stdin;
\.
copy ref_gears (id, description, name, nameeng, matchingcodegear, geareu, gearstd, fishingtechniqueeu, old_code, gearclass, marinefisherysubsector)  from '$$PATH$$/3313.dat' ;
--
-- Data for Name: ref_group_of_landingsites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_group_of_landingsites (id, name, nameeng, description, comments) FROM stdin;
\.
copy ref_group_of_landingsites (id, name, nameeng, description, comments)  from '$$PATH$$/3287.dat' ;
--
-- Data for Name: ref_issuing_offices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_issuing_offices (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_issuing_offices (id, description, name, nameeng, old_code)  from '$$PATH$$/3324.dat' ;
--
-- Data for Name: ref_landingsite_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_landingsite_type (id, name, nameeng, description) FROM stdin;
\.
copy ref_landingsite_type (id, name, nameeng, description)  from '$$PATH$$/3325.dat' ;
--
-- Data for Name: ref_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_levels (id, name, description, comments) FROM stdin;
\.
copy ref_levels (id, name, description, comments)  from '$$PATH$$/3326.dat' ;
--
-- Data for Name: ref_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_location (id, country, city_name, city_nameeng) FROM stdin;
\.
copy ref_location (id, country, city_name, city_nameeng)  from '$$PATH$$/3327.dat' ;
--
-- Data for Name: ref_logbook_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_logbook_types (id, name, description) FROM stdin;
\.
copy ref_logbook_types (id, name, description)  from '$$PATH$$/3328.dat' ;
--
-- Data for Name: ref_marine_fishery_subsectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_marine_fishery_subsectors (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_marine_fishery_subsectors (id, description, name, nameeng, old_code)  from '$$PATH$$/3329.dat' ;
--
-- Data for Name: ref_minor_strata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_minor_strata (id, id_start_dt, id_end_dt, id_frame_time, id_gls, isclosed, id_no_recording_activity, comments, name) FROM stdin;
\.
copy ref_minor_strata (id, id_start_dt, id_end_dt, id_frame_time, id_gls, isclosed, id_no_recording_activity, comments, name)  from '$$PATH$$/3288.dat' ;
--
-- Data for Name: ref_months; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_months (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_months (id, description, name, nameeng, old_code)  from '$$PATH$$/3330.dat' ;
--
-- Data for Name: ref_no_recording_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_no_recording_activities (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_no_recording_activities (id, description, name, nameeng, old_code)  from '$$PATH$$/3331.dat' ;
--
-- Data for Name: ref_operational_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_operational_statuses (id, description, name, nameeng, old_code) FROM stdin;
\.
copy ref_operational_statuses (id, description, name, nameeng, old_code)  from '$$PATH$$/3332.dat' ;
--
-- Data for Name: ref_ports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_ports (id, description, name, nameeng, portcode, latitude, longitude, geosubarea, porttype, portcodeeu, old_code, minorstratum) FROM stdin;
\.
copy ref_ports (id, description, name, nameeng, portcode, latitude, longitude, geosubarea, porttype, portcodeeu, old_code, minorstratum)  from '$$PATH$$/3333.dat' ;
--
-- Data for Name: ref_sample_origin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_sample_origin (id, name, name_eng, description) FROM stdin;
\.
copy ref_sample_origin (id, name, name_eng, description)  from '$$PATH$$/3334.dat' ;
--
-- Data for Name: ref_sample_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_sample_status (id, name, name_eng, description) FROM stdin;
\.
copy ref_sample_status (id, name, name_eng, description)  from '$$PATH$$/3335.dat' ;
--
-- Data for Name: ref_samplers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_samplers (id, name) FROM stdin;
\.
copy ref_samplers (id, name)  from '$$PATH$$/3336.dat' ;
--
-- Data for Name: ref_sampling_technique; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_sampling_technique (id, name, nameeng, description, comments, id_strategy, sample_size, population_size, id_fr_time) FROM stdin;
\.
copy ref_sampling_technique (id, name, nameeng, description, comments, id_strategy, sample_size, population_size, id_fr_time)  from '$$PATH$$/3337.dat' ;
--
-- Data for Name: ref_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_source (id, name, nameeng, description) FROM stdin;
\.
copy ref_source (id, name, nameeng, description)  from '$$PATH$$/3338.dat' ;
--
-- Data for Name: ref_species; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_species (id, description, name, nameeng, namesci, namefrn, nameesp, isscaap, taxocode, alphacode, author, family, "order", old_code) FROM stdin;
\.
copy ref_species (id, description, name, nameeng, namesci, namefrn, nameesp, isscaap, taxocode, alphacode, author, family, "order", old_code)  from '$$PATH$$/3339.dat' ;
--
-- Data for Name: ref_stocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_stocks (id, description, name, nameeng, matchingcode, speciescode, speciestricode, grouptype, old_code) FROM stdin;
\.
copy ref_stocks (id, description, name, nameeng, matchingcode, speciescode, speciestricode, grouptype, old_code)  from '$$PATH$$/3340.dat' ;
--
-- Data for Name: ref_strategy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_strategy (id, name, description, comments) FROM stdin;
\.
copy ref_strategy (id, name, description, comments)  from '$$PATH$$/3341.dat' ;
--
-- Data for Name: ref_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_units (id, name, nameeng, description) FROM stdin;
\.
copy ref_units (id, name, nameeng, description)  from '$$PATH$$/3342.dat' ;
--
-- Data for Name: ref_vessel_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_vessel_types (id, description, name, nameeng, stdabbreviation, vesseltypefffao, old_code) FROM stdin;
\.
copy ref_vessel_types (id, description, name, nameeng, stdabbreviation, vesseltypefffao, old_code)  from '$$PATH$$/3343.dat' ;
--
-- Data for Name: ref_vessels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ref_vessels (vesselid, censusid, created, uniqueregistrationnumber, registrationnumber, externalmarking, registrationdate, name, originalname, originalregistrationnumber, length, width, depth, decked, grt, gt, documentid, issuedate, expirydate, fisheryentrydate, fisherydepartmentregistrationnumber, licenseindicator, enginepower, originaldeletiondetails, old_code, operationalstatus, vesseltype, registrationoffice, flag, originalflag, nonoperationalreason, homeport, fleetsegment, authorisationtype, issuingoffice, enginelocation, maingeartype, maingeartargetgroupofspecies, secondarygeartype, secondarygeartargetgroupofspecies) FROM stdin;
\.
copy ref_vessels (vesselid, censusid, created, uniqueregistrationnumber, registrationnumber, externalmarking, registrationdate, name, originalname, originalregistrationnumber, length, width, depth, decked, grt, gt, documentid, issuedate, expirydate, fisheryentrydate, fisherydepartmentregistrationnumber, licenseindicator, enginepower, originaldeletiondetails, old_code, operationalstatus, vesseltype, registrationoffice, flag, originalflag, nonoperationalreason, homeport, fleetsegment, authorisationtype, issuingoffice, enginelocation, maingeartype, maingeartargetgroupofspecies, secondarygeartype, secondarygeartargetgroupofspecies)  from '$$PATH$$/3344.dat' ;
--
-- Data for Name: sampled_catch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_catch (id, id_fishing_operation, id_commercial_category, catch_weight_estimated, catch_weight_calculated, id_catch_weight_units, catch_no_boxes_estimated, catch_no_boxes_calculated, id_catch_no_boxes_units, weight_box, catch_units_estimated, id_catch_units_units, sample_units, sample_weight, id_sample_units, comments, catch_units_calculated, weight_unit) FROM stdin;
\.
copy sampled_catch (id, id_fishing_operation, id_commercial_category, catch_weight_estimated, catch_weight_calculated, id_catch_weight_units, catch_no_boxes_estimated, catch_no_boxes_calculated, id_catch_no_boxes_units, weight_box, catch_units_estimated, id_catch_units_units, sample_units, sample_weight, id_sample_units, comments, catch_units_calculated, weight_unit)  from '$$PATH$$/3345.dat' ;
--
-- Data for Name: sampled_cell; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_cell (id, id_minor_strata, id_start_dt, id_end_dt, id_abstract_landingsite, n_vessels_estimated, n_vessels_calculated, n_active_vessels_estimated, n_active_vessels_calculated, n_inactive_vessels_estimated, n_inactive_vessels_calculated, n_active_vessels_outside_estimated, n_active_vessels_outside_calculated, comments, description) FROM stdin;
\.
copy sampled_cell (id, id_minor_strata, id_start_dt, id_end_dt, id_abstract_landingsite, n_vessels_estimated, n_vessels_calculated, n_active_vessels_estimated, n_active_vessels_calculated, n_inactive_vessels_estimated, n_inactive_vessels_calculated, n_active_vessels_outside_estimated, n_active_vessels_outside_calculated, comments, description)  from '$$PATH$$/3346.dat' ;
--
-- Data for Name: sampled_cell_vessel_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_cell_vessel_types (id, id_cell, id_vessel_type, n_vessels_estimated, n_vessels_calculated, n_active_vessels_estimated, n_active_vessels_calculated, n_inactive_vessels_estimated, n_inactive_vessels_calculated, n_active_vessels_outside_estimated, n_active_vessels_outside_calculated, comments) FROM stdin;
\.
copy sampled_cell_vessel_types (id, id_cell, id_vessel_type, n_vessels_estimated, n_vessels_calculated, n_active_vessels_estimated, n_active_vessels_calculated, n_inactive_vessels_estimated, n_inactive_vessels_calculated, n_active_vessels_outside_estimated, n_active_vessels_outside_calculated, comments)  from '$$PATH$$/3347.dat' ;
--
-- Data for Name: sampled_cell_vessels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_cell_vessels (id, id_cell_vessel_types, n_trips_estimated, n_trips_calculated, description) FROM stdin;
\.
copy sampled_cell_vessels (id, id_cell_vessel_types, n_trips_estimated, n_trips_calculated, description)  from '$$PATH$$/3348.dat' ;
--
-- Data for Name: sampled_fishing_operations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_fishing_operations (id, id_fishing_trip, id_start_dt, id_end_dt, id_gear, catch_weight_estimated, catch_weight_calculated, id_catch_weight_units, catch_no_boxes_estimated, catch_no_boxes_calculated, id_catch_no_boxes_units, weight_box, catch_units_estimated, catch_units_calculated, id_catch_units_units, n_gear_units, gear_unit_size, number_order, id_fishing_zone, comments, weight_unit) FROM stdin;
\.
copy sampled_fishing_operations (id, id_fishing_trip, id_start_dt, id_end_dt, id_gear, catch_weight_estimated, catch_weight_calculated, id_catch_weight_units, catch_no_boxes_estimated, catch_no_boxes_calculated, id_catch_no_boxes_units, weight_box, catch_units_estimated, catch_units_calculated, id_catch_units_units, n_gear_units, gear_unit_size, number_order, id_fishing_zone, comments, weight_unit)  from '$$PATH$$/3314.dat' ;
--
-- Data for Name: sampled_fishing_operations_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_fishing_operations_categories (id, id_fishing_operation, id_commercial_category) FROM stdin;
\.
copy sampled_fishing_operations_categories (id, id_fishing_operation, id_commercial_category)  from '$$PATH$$/3349.dat' ;
--
-- Data for Name: sampled_fishing_trips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_fishing_trips (id, id_abstract_sampled_vessels, id_start_dt, id_end_dt, id_abstract_landing_site, id_sampler, prof_fishermen, part_time_fishermen, n_operations_estimated, n_operations_calculated, catch_weight_estimated, catch_weight_calculated, id_catch_weight_units, catch_no_boxes_estimated, catch_no_boxes_calculated, id_catch_no_boxes_units, comments, weight_box, catch_units_estimated, weight_unit, id_catch_units_units, catch_units_calculated) FROM stdin;
\.
copy sampled_fishing_trips (id, id_abstract_sampled_vessels, id_start_dt, id_end_dt, id_abstract_landing_site, id_sampler, prof_fishermen, part_time_fishermen, n_operations_estimated, n_operations_calculated, catch_weight_estimated, catch_weight_calculated, id_catch_weight_units, catch_no_boxes_estimated, catch_no_boxes_calculated, id_catch_no_boxes_units, comments, weight_box, catch_units_estimated, weight_unit, id_catch_units_units, catch_units_calculated)  from '$$PATH$$/3350.dat' ;
--
-- Data for Name: sampled_fishing_trips_gears; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_fishing_trips_gears (id, id_fishing_trip, id_fishing_gear) FROM stdin;
\.
copy sampled_fishing_trips_gears (id, id_fishing_trip, id_fishing_gear)  from '$$PATH$$/3351.dat' ;
--
-- Data for Name: sampled_fishing_trips_zones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_fishing_trips_zones (id, id_fishing_trip, id_fishing_zone) FROM stdin;
\.
copy sampled_fishing_trips_zones (id, id_fishing_trip, id_fishing_zone)  from '$$PATH$$/3352.dat' ;
--
-- Data for Name: sampled_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_levels (id, id_level, sample_size, population_size, id_strategy, description, comments, id_sampling_technique) FROM stdin;
\.
copy sampled_levels (id, id_level, sample_size, population_size, id_strategy, description, comments, id_sampling_technique)  from '$$PATH$$/3353.dat' ;
--
-- Data for Name: sampled_strata_vessels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sampled_strata_vessels (id, id_minor_strata, description) FROM stdin;
\.
copy sampled_strata_vessels (id, id_minor_strata, description)  from '$$PATH$$/3354.dat' ;
--
-- Data for Name: t_distribution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY t_distribution (p, df) FROM stdin;
\.
copy t_distribution (p, df)  from '$$PATH$$/3355.dat' ;
--
-- Data for Name: ui_boolean_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_boolean_mapping (id, name, nameeng, val) FROM stdin;
\.
copy ui_boolean_mapping (id, name, nameeng, val)  from '$$PATH$$/3356.dat' ;
--
-- Data for Name: ui_forms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_forms (id, name, description, comments) FROM stdin;
\.
copy ui_forms (id, name, description, comments)  from '$$PATH$$/3357.dat' ;
--
-- Data for Name: ui_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_role (id, name, description, new, view, modify, remove, report, admin) FROM stdin;
\.
copy ui_role (id, name, description, new, view, modify, remove, report, admin)  from '$$PATH$$/3358.dat' ;
--
-- Data for Name: ui_rule_ptrs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_rule_ptrs (id, field, id_rules, active, form, mapper, description) FROM stdin;
\.
copy ui_rule_ptrs (id, field, id_rules, active, form, mapper, description)  from '$$PATH$$/3359.dat' ;
--
-- Data for Name: ui_rule_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_rule_types (id, name, description) FROM stdin;
\.
copy ui_rule_types (id, name, description)  from '$$PATH$$/3360.dat' ;
--
-- Data for Name: ui_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_rules (id, field, type, rule, sql_checked, description, active, form, mapper) FROM stdin;
\.
copy ui_rules (id, field, type, rule, sql_checked, description, active, form, mapper)  from '$$PATH$$/3361.dat' ;
--
-- Data for Name: ui_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ui_user (username, password, role_id, id, description) FROM stdin;
\.
copy ui_user (username, password, role_id, id, description)  from '$$PATH$$/3362.dat' ;
--
-- Name: aaaaaref_logbook_types_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_logbook_types
    ADD CONSTRAINT aaaaaref_logbook_types_pk PRIMARY KEY (id);


--
-- Name: abstract_changes_temp_vessel_pk_temp_changes; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT abstract_changes_temp_vessel_pk_temp_changes PRIMARY KEY (id);


--
-- Name: changes_perm_gls_pk_gls_perm_changes; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY changes_perm_gls
    ADD CONSTRAINT changes_perm_gls_pk_gls_perm_changes PRIMARY KEY (id);


--
-- Name: changes_perm_ls_pk_ls_perm_changes; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY changes_perm_ls
    ADD CONSTRAINT changes_perm_ls_pk_ls_perm_changes PRIMARY KEY (id);


--
-- Name: changes_perm_vessel_pk_perm_changes; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY changes_perm_vessel
    ADD CONSTRAINT changes_perm_vessel_pk_perm_changes PRIMARY KEY (id);


--
-- Name: fr_node_description_pk_ref_levels; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_node_description
    ADD CONSTRAINT fr_node_description_pk_ref_levels PRIMARY KEY (id);


--
-- Name: fr_time_pk_fr_frame_time; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_time
    ADD CONSTRAINT fr_time_pk_fr_frame_time PRIMARY KEY (id);


--
-- Name: fr_tree_pk_tree; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_tree
    ADD CONSTRAINT fr_tree_pk_tree PRIMARY KEY (id);


--
-- Name: gl_dates_pk_cas_dates; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY gl_dates
    ADD CONSTRAINT gl_dates_pk_cas_dates PRIMARY KEY (id);


--
-- Name: gl_null_replacements_pk_null_replacements; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY gl_null_replacements
    ADD CONSTRAINT gl_null_replacements_pk_null_replacements PRIMARY KEY (id);


--
-- Name: info_fields_pk_cas_fields; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY info_fields
    ADD CONSTRAINT info_fields_pk_cas_fields PRIMARY KEY (id);


--
-- Name: info_tables_import_pk_cas_tables_import_1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY info_tables_import
    ADD CONSTRAINT info_tables_import_pk_cas_tables_import_1 PRIMARY KEY (id);


--
-- Name: info_tables_pk_cas_tables; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY info_tables
    ADD CONSTRAINT info_tables_pk_cas_tables PRIMARY KEY (id);


--
-- Name: pk_abstract_sampled_vessels; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY abstract_sampled_vessels
    ADD CONSTRAINT pk_abstract_sampled_vessels PRIMARY KEY (id);


--
-- Name: pk_fr_als2vessel; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_als2vessel
    ADD CONSTRAINT pk_fr_als2vessel PRIMARY KEY (id);


--
-- Name: pk_fr_f2gls; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_f2gls
    ADD CONSTRAINT pk_fr_f2gls PRIMARY KEY (id);


--
-- Name: pk_fr_frame; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_frame
    ADD CONSTRAINT pk_fr_frame PRIMARY KEY (id);


--
-- Name: pk_fr_gls2als; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_gls2als
    ADD CONSTRAINT pk_fr_gls2als PRIMARY KEY (id);


--
-- Name: pk_fr_sub_frame; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fr_sub_frame
    ADD CONSTRAINT pk_fr_sub_frame PRIMARY KEY (id);


--
-- Name: pk_gl_session; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY gl_session
    ADD CONSTRAINT pk_gl_session PRIMARY KEY (id);


--
-- Name: pk_info_changes; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY info_changes
    ADD CONSTRAINT pk_info_changes PRIMARY KEY (id);


--
-- Name: pk_info_fk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY info_fk
    ADD CONSTRAINT pk_info_fk PRIMARY KEY (id);


--
-- Name: pk_info_triggers; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY info_triggers
    ADD CONSTRAINT pk_info_triggers PRIMARY KEY (id);


--
-- Name: pk_ref_collectors; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_collectors
    ADD CONSTRAINT pk_ref_collectors PRIMARY KEY (id);


--
-- Name: pk_ref_datetime_type; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_datetime_type
    ADD CONSTRAINT pk_ref_datetime_type PRIMARY KEY (id);


--
-- Name: pk_ref_frame; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_frame
    ADD CONSTRAINT pk_ref_frame PRIMARY KEY (id);


--
-- Name: pk_ref_samplers; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_samplers
    ADD CONSTRAINT pk_ref_samplers PRIMARY KEY (id);


--
-- Name: pk_ref_source; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_source
    ADD CONSTRAINT pk_ref_source PRIMARY KEY (id);


--
-- Name: pk_ref_units; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_units
    ADD CONSTRAINT pk_ref_units PRIMARY KEY (id);


--
-- Name: pk_sampled_catch; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT pk_sampled_catch PRIMARY KEY (id);


--
-- Name: pk_sampled_fishing_operations_categories; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_fishing_operations_categories
    ADD CONSTRAINT pk_sampled_fishing_operations_categories PRIMARY KEY (id);


--
-- Name: pk_sampled_fishing_trips_gears; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_fishing_trips_gears
    ADD CONSTRAINT pk_sampled_fishing_trips_gears PRIMARY KEY (id);


--
-- Name: pk_sampled_levels_1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_levels
    ADD CONSTRAINT pk_sampled_levels_1 PRIMARY KEY (id);


--
-- Name: pk_sampled_strata_vessels; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_strata_vessels
    ADD CONSTRAINT pk_sampled_strata_vessels PRIMARY KEY (id);


--
-- Name: pk_ui_boolean_mapping; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_boolean_mapping
    ADD CONSTRAINT pk_ui_boolean_mapping PRIMARY KEY (id);


--
-- Name: pk_ui_forms; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_forms
    ADD CONSTRAINT pk_ui_forms PRIMARY KEY (id);


--
-- Name: pk_ui_rule_types; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_rule_types
    ADD CONSTRAINT pk_ui_rule_types PRIMARY KEY (id);


--
-- Name: pk_ui_rules; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_rules
    ADD CONSTRAINT pk_ui_rules PRIMARY KEY (id);


--
-- Name: ref_abstract_landingsite_pk_ref_psu_detail; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_abstract_landingsite
    ADD CONSTRAINT ref_abstract_landingsite_pk_ref_psu_detail PRIMARY KEY (id);


--
-- Name: ref_authorisation_types_refauthorisationtypes_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_authorisation_types
    ADD CONSTRAINT ref_authorisation_types_refauthorisationtypes_constraint1 PRIMARY KEY (id);


--
-- Name: ref_changes_refinactivityreasons_constraint1_; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_changes
    ADD CONSTRAINT ref_changes_refinactivityreasons_constraint1_ PRIMARY KEY (id);


--
-- Name: ref_commercial_categories_refgroupofspecies_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_commercial_categories
    ADD CONSTRAINT ref_commercial_categories_refgroupofspecies_constraint1 PRIMARY KEY (id);


--
-- Name: ref_countries_refcountries_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_countries
    ADD CONSTRAINT ref_countries_refcountries_constraint1 PRIMARY KEY (id);


--
-- Name: ref_engine_locations_refenginelocations_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_engine_locations
    ADD CONSTRAINT ref_engine_locations_refenginelocations_constraint1 PRIMARY KEY (id);


--
-- Name: ref_fishing_zones_reffishingzones_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_fishing_zones
    ADD CONSTRAINT ref_fishing_zones_reffishingzones_constraint1 PRIMARY KEY (id);


--
-- Name: ref_fleet_segmentation_reffleetsegmentation_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_fleet_segmentation
    ADD CONSTRAINT ref_fleet_segmentation_reffleetsegmentation_constraint1 PRIMARY KEY (id);


--
-- Name: ref_gear_classes_refgearclasses_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_gear_classes
    ADD CONSTRAINT ref_gear_classes_refgearclasses_constraint1 PRIMARY KEY (id);


--
-- Name: ref_gears_refgears_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_gears
    ADD CONSTRAINT ref_gears_refgears_constraint1 PRIMARY KEY (id);


--
-- Name: ref_group_of_landingsites_pk_group_of_landingsites; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_group_of_landingsites
    ADD CONSTRAINT ref_group_of_landingsites_pk_group_of_landingsites PRIMARY KEY (id);


--
-- Name: ref_issuing_offices_refissuingoffices_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_issuing_offices
    ADD CONSTRAINT ref_issuing_offices_refissuingoffices_constraint1 PRIMARY KEY (id);


--
-- Name: ref_landingsite_type_pk_ref_psu_detail_type; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_landingsite_type
    ADD CONSTRAINT ref_landingsite_type_pk_ref_psu_detail_type PRIMARY KEY (id);


--
-- Name: ref_levels_pk_sampled_levels; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_levels
    ADD CONSTRAINT ref_levels_pk_sampled_levels PRIMARY KEY (id);


--
-- Name: ref_location_pk_location; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_location
    ADD CONSTRAINT ref_location_pk_location PRIMARY KEY (id);


--
-- Name: ref_marine_fishery_subsectors_refmarinefisherysubsectors_constr; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_marine_fishery_subsectors
    ADD CONSTRAINT ref_marine_fishery_subsectors_refmarinefisherysubsectors_constr PRIMARY KEY (id);


--
-- Name: ref_minor_strata_pk_minor_strata; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_minor_strata
    ADD CONSTRAINT ref_minor_strata_pk_minor_strata PRIMARY KEY (id);


--
-- Name: ref_months_refmonths_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_months
    ADD CONSTRAINT ref_months_refmonths_constraint1 PRIMARY KEY (id);


--
-- Name: ref_no_recording_activities_reflogbooknareasons_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_no_recording_activities
    ADD CONSTRAINT ref_no_recording_activities_reflogbooknareasons_constraint1 PRIMARY KEY (id);


--
-- Name: ref_operational_statuses_refoperationalstatuses_constraint1_; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_operational_statuses
    ADD CONSTRAINT ref_operational_statuses_refoperationalstatuses_constraint1_ PRIMARY KEY (id);


--
-- Name: ref_ports_refports_constraint1_; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_ports
    ADD CONSTRAINT ref_ports_refports_constraint1_ PRIMARY KEY (id);


--
-- Name: ref_sample_origin_aaaaaref_logbooks_origin_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_sample_origin
    ADD CONSTRAINT ref_sample_origin_aaaaaref_logbooks_origin_pk PRIMARY KEY (id);


--
-- Name: ref_sample_status_aaaaaref_logbook_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_sample_status
    ADD CONSTRAINT ref_sample_status_aaaaaref_logbook_status_pk PRIMARY KEY (id);


--
-- Name: ref_sampling_technique_pk_ref_schema; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_sampling_technique
    ADD CONSTRAINT ref_sampling_technique_pk_ref_schema PRIMARY KEY (id);


--
-- Name: ref_species_refspecies_constraint1______; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_species
    ADD CONSTRAINT ref_species_refspecies_constraint1______ PRIMARY KEY (id);


--
-- Name: ref_stocks_refstocks_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_stocks
    ADD CONSTRAINT ref_stocks_refstocks_constraint1 PRIMARY KEY (id);


--
-- Name: ref_strategy_pk_ref_criteria; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_strategy
    ADD CONSTRAINT ref_strategy_pk_ref_criteria PRIMARY KEY (id);


--
-- Name: ref_vessel_types_refvesseltypes_constraint1_; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_vessel_types
    ADD CONSTRAINT ref_vessel_types_refvesseltypes_constraint1_ PRIMARY KEY (id);


--
-- Name: ref_vessels_constraint1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT ref_vessels_constraint1 PRIMARY KEY (vesselid);


--
-- Name: sampled_cell_pk_cell; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_cell
    ADD CONSTRAINT sampled_cell_pk_cell PRIMARY KEY (id);


--
-- Name: sampled_cell_vessel_types_pk_cell_vessel_types; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_cell_vessel_types
    ADD CONSTRAINT sampled_cell_vessel_types_pk_cell_vessel_types PRIMARY KEY (id);


--
-- Name: sampled_cell_vessels_pk_cell_vessels; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_cell_vessels
    ADD CONSTRAINT sampled_cell_vessels_pk_cell_vessels PRIMARY KEY (id);


--
-- Name: sampled_fishing_operations_pk_fishing_operation; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT sampled_fishing_operations_pk_fishing_operation PRIMARY KEY (id);


--
-- Name: sampled_fishing_trips_pk_fishing_trips; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT sampled_fishing_trips_pk_fishing_trips PRIMARY KEY (id);


--
-- Name: sampled_fishing_trips_zones_pk_sampled_fishing_trip_zones; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sampled_fishing_trips_zones
    ADD CONSTRAINT sampled_fishing_trips_zones_pk_sampled_fishing_trip_zones PRIMARY KEY (id);


--
-- Name: ui_role_pk_role; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_role
    ADD CONSTRAINT ui_role_pk_role PRIMARY KEY (id);


--
-- Name: ui_rule_ptrs_pk_ui_pre_triggers_ptrs_1; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_rule_ptrs
    ADD CONSTRAINT ui_rule_ptrs_pk_ui_pre_triggers_ptrs_1 PRIMARY KEY (id);


--
-- Name: ui_user_pk_user; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ui_user
    ADD CONSTRAINT ui_user_pk_user PRIMARY KEY (id);


--
-- Name: gl_null_replacements_unique_code_cstrt; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX gl_null_replacements_unique_code_cstrt ON gl_null_replacements USING btree ("int");


--
-- Name: gl_null_replacements_unique_display_name_cstrt; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX gl_null_replacements_unique_display_name_cstrt ON gl_null_replacements USING btree (internal_name);


--
-- Name: info_fields_uniquetablefieldcstrt; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX info_fields_uniquetablefieldcstrt ON info_fields USING btree (table_name, field_name);


--
-- Name: info_tables_uniquenamecstrnt; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX info_tables_uniquenamecstrnt ON info_tables USING btree (name);


--
-- Name: ref_authorisation_types_uq____ref_authorisat__39883157; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_authorisation_types_uq____ref_authorisat__39883157 ON ref_authorisation_types USING btree (name);


--
-- Name: ref_changes_uq____ref_inactivity__49be9920; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_changes_uq____ref_inactivity__49be9920 ON ref_changes USING btree (name);


--
-- Name: ref_commercial_categories_uq___ref_group_of_sp__1c4cd42b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_commercial_categories_uq___ref_group_of_sp__1c4cd42b ON ref_commercial_categories USING btree (name);


--
-- Name: ref_engine_locations_uq___ref_engine_loca__5dc591cd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_engine_locations_uq___ref_engine_loca__5dc591cd ON ref_engine_locations USING btree (name);


--
-- Name: ref_fishing_zones_uq___ref_fishing_zon__0d0a909b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_fishing_zones_uq___ref_fishing_zon__0d0a909b ON ref_fishing_zones USING btree (name);


--
-- Name: ref_fleet_segmentation_uq___ref_fleet_segme__11cf45b8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_fleet_segmentation_uq___ref_fleet_segme__11cf45b8 ON ref_fleet_segmentation USING btree (name);


--
-- Name: ref_gear_classes_uq___ref_gear_classe__17881f0e; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_gear_classes_uq___ref_gear_classe__17881f0e ON ref_gear_classes USING btree (name);


--
-- Name: ref_issuing_offices_uq____ref_issuing_of__3e4ce674; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_issuing_offices_uq____ref_issuing_of__3e4ce674 ON ref_issuing_offices USING btree (name);


--
-- Name: ref_marine_fishery_subsectors_uq___ref_marine_fish__25d63e65; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_marine_fishery_subsectors_uq___ref_marine_fish__25d63e65 ON ref_marine_fishery_subsectors USING btree (name);


--
-- Name: ref_no_recording_activities_uq___ref_no_recordin__21118948; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_no_recording_activities_uq___ref_no_recordin__21118948 ON ref_no_recording_activities USING btree (name);


--
-- Name: ref_operational_statuses_uq___ref_operational__4366a14c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_operational_statuses_uq___ref_operational__4366a14c ON ref_operational_statuses USING btree (name);


--
-- Name: ref_vessel_types_uq___ref_vessel_type__2442fbae; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ref_vessel_types_uq___ref_vessel_type__2442fbae ON ref_vessel_types USING btree (name);


--
-- Name: uq___ref_countries__0d5f9656; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX uq___ref_countries__0d5f9656 ON ref_countries USING btree (name);


--
-- Name: uq___ref_months__3dadc7f6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX uq___ref_months__3dadc7f6 ON ref_months USING btree (name);


--
-- Name: fk_abstract_changes_temp_vessel_ref_minor_strata; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_abstract_changes_temp_vessel_ref_minor_strata FOREIGN KEY (id_minor_strata) REFERENCES ref_minor_strata(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_abstract_changes_temp_vessel_ref_source; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_abstract_changes_temp_vessel_ref_source FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;


--
-- Name: fk_abstract_sampled_vessels_ref_sample_origin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_sampled_vessels
    ADD CONSTRAINT fk_abstract_sampled_vessels_ref_sample_origin FOREIGN KEY (id_sample_origin) REFERENCES ref_sample_origin(id) DEFERRABLE;


--
-- Name: fk_abstract_sampled_vessels_ref_sample_status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_sampled_vessels
    ADD CONSTRAINT fk_abstract_sampled_vessels_ref_sample_status FOREIGN KEY (id_sample_status) REFERENCES ref_sample_status(id) DEFERRABLE;


--
-- Name: fk_abstract_sampled_vessels_ref_source; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_sampled_vessels
    ADD CONSTRAINT fk_abstract_sampled_vessels_ref_source FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;


--
-- Name: fk_abstract_sampled_vessels_ref_vessels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_sampled_vessels
    ADD CONSTRAINT fk_abstract_sampled_vessels_ref_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;


--
-- Name: fk_cas_dates_ref_datetime_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_dates
    ADD CONSTRAINT fk_cas_dates_ref_datetime_type FOREIGN KEY (date_type) REFERENCES ref_datetime_type(id) DEFERRABLE;


--
-- Name: fk_cas_landingsite2psu_cas_landingsite_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_abstract_landingsite
    ADD CONSTRAINT fk_cas_landingsite2psu_cas_landingsite_type FOREIGN KEY (id_landingsite_type) REFERENCES ref_landingsite_type(id) DEFERRABLE;


--
-- Name: fk_cas_landingsite2psu_ref_collectors; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_abstract_landingsite
    ADD CONSTRAINT fk_cas_landingsite2psu_ref_collectors FOREIGN KEY (id_collector) REFERENCES ref_collectors(id) DEFERRABLE;


--
-- Name: fk_cas_landingsite2psu_ref_ports; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_abstract_landingsite
    ADD CONSTRAINT fk_cas_landingsite2psu_ref_ports FOREIGN KEY (id_port) REFERENCES ref_ports(id) DEFERRABLE;


--
-- Name: fk_cell_minor_strata; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell
    ADD CONSTRAINT fk_cell_minor_strata FOREIGN KEY (id_minor_strata) REFERENCES ref_minor_strata(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_cell_vessel_types_cell; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell_vessel_types
    ADD CONSTRAINT fk_cell_vessel_types_cell FOREIGN KEY (id_cell) REFERENCES sampled_cell(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_cell_vessel_types_ref_vessel_types; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell_vessel_types
    ADD CONSTRAINT fk_cell_vessel_types_ref_vessel_types FOREIGN KEY (id_vessel_type) REFERENCES ref_vessel_types(id) DEFERRABLE;


--
-- Name: fk_cell_vessels_cell_vessel_types; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell_vessels
    ADD CONSTRAINT fk_cell_vessels_cell_vessel_types FOREIGN KEY (id_cell_vessel_types) REFERENCES sampled_cell_vessel_types(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fishing_operation_fishing_trips; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_fishing_operation_fishing_trips FOREIGN KEY (id_fishing_trip) REFERENCES sampled_fishing_trips(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fishing_trips_cell_vessels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_fishing_trips_cell_vessels FOREIGN KEY (id_abstract_sampled_vessels) REFERENCES abstract_sampled_vessels(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fishing_trips_ref_units; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_fishing_trips_ref_units FOREIGN KEY (id_catch_weight_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_fr_als2vessel_abstract_landingsite; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_als2vessel
    ADD CONSTRAINT fk_fr_als2vessel_abstract_landingsite FOREIGN KEY (id_abstract_landingsite) REFERENCES ref_abstract_landingsite(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fr_als2vessel_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_als2vessel
    ADD CONSTRAINT fk_fr_als2vessel_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fr_als2vessel_reg_vessels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_als2vessel
    ADD CONSTRAINT fk_fr_als2vessel_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fr_f2gls_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_f2gls
    ADD CONSTRAINT fk_fr_f2gls_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fr_f2gls_group_of_landingsites; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_f2gls
    ADD CONSTRAINT fk_fr_f2gls_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fr_frame_ref_source; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_frame
    ADD CONSTRAINT fk_fr_frame_ref_source FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;


--
-- Name: fk_fr_frame_ref_source_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_frame
    ADD CONSTRAINT fk_fr_frame_ref_source_ FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;


--
-- Name: fk_fr_frame_ref_source__; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_frame
    ADD CONSTRAINT fk_fr_frame_ref_source__ FOREIGN KEY (id_source) REFERENCES ref_source(id) DEFERRABLE;


--
-- Name: fk_fr_gls2als_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_gls2als
    ADD CONSTRAINT fk_fr_gls2als_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_fr_sub_frame_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_sub_frame
    ADD CONSTRAINT fk_fr_sub_frame_fr_frame FOREIGN KEY (id_frame) REFERENCES fr_frame(id) DEFERRABLE;


--
-- Name: fk_fr_sub_frame_ref_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_sub_frame
    ADD CONSTRAINT fk_fr_sub_frame_ref_frame FOREIGN KEY (type) REFERENCES ref_frame(id) DEFERRABLE;


--
-- Name: fk_fr_time_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_time
    ADD CONSTRAINT fk_fr_time_fr_frame FOREIGN KEY (id_frame) REFERENCES fr_frame(id) DEFERRABLE;


--
-- Name: fk_frame_time_cas_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_time
    ADD CONSTRAINT fk_frame_time_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_frame_time_cas_dates1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_time
    ADD CONSTRAINT fk_frame_time_cas_dates1 FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_gl_session_gl_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_session
    ADD CONSTRAINT fk_gl_session_gl_dates FOREIGN KEY (id_base_date) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_gl_session_gl_dates1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_session
    ADD CONSTRAINT fk_gl_session_gl_dates1 FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_gl_session_ref_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_session
    ADD CONSTRAINT fk_gl_session_ref_local FOREIGN KEY (id_location) REFERENCES ref_location(id) DEFERRABLE;


--
-- Name: fk_gl_session_ui_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY gl_session
    ADD CONSTRAINT fk_gl_session_ui_user FOREIGN KEY (id_user) REFERENCES ui_user(id) DEFERRABLE;


--
-- Name: fk_gls2als_abstract_landingsite; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_gls2als
    ADD CONSTRAINT fk_gls2als_abstract_landingsite FOREIGN KEY (id_abstract_landingsite) REFERENCES ref_abstract_landingsite(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_gls2als_group_of_landingsites; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_gls2als
    ADD CONSTRAINT fk_gls2als_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_gls_perm_changes_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_gls
    ADD CONSTRAINT fk_gls_perm_changes_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_gls_perm_changes_group_of_landingsites; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_gls
    ADD CONSTRAINT fk_gls_perm_changes_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_info_changes_gl_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_changes
    ADD CONSTRAINT fk_info_changes_gl_dates FOREIGN KEY (id_datetime) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_info_changes_gl_session; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_changes
    ADD CONSTRAINT fk_info_changes_gl_session FOREIGN KEY (id_session) REFERENCES gl_session(id) DEFERRABLE;


--
-- Name: fk_info_client_info_changes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_client
    ADD CONSTRAINT fk_info_client_info_changes FOREIGN KEY (client_id) REFERENCES info_changes(id) DEFERRABLE;


--
-- Name: fk_info_fields_info_tables1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_fields
    ADD CONSTRAINT fk_info_fields_info_tables1 FOREIGN KEY (table_name) REFERENCES info_tables(name) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_info_tables_import_info_tables; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY info_tables_import
    ADD CONSTRAINT fk_info_tables_import_info_tables FOREIGN KEY (imported_name) REFERENCES info_tables(name) DEFERRABLE;


--
-- Name: fk_location_ref_countries; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_location
    ADD CONSTRAINT fk_location_ref_countries FOREIGN KEY (country) REFERENCES ref_countries(id) DEFERRABLE;


--
-- Name: fk_ls_perm_changes_abstract_landingsite; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_ls
    ADD CONSTRAINT fk_ls_perm_changes_abstract_landingsite FOREIGN KEY (id_abstract_landingsite) REFERENCES ref_abstract_landingsite(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_ls_perm_changes_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_ls
    ADD CONSTRAINT fk_ls_perm_changes_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_minor_strata_cas_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_minor_strata
    ADD CONSTRAINT fk_minor_strata_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_minor_strata_cas_dates1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_minor_strata
    ADD CONSTRAINT fk_minor_strata_cas_dates1 FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_minor_strata_frame_time; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_minor_strata
    ADD CONSTRAINT fk_minor_strata_frame_time FOREIGN KEY (id_frame_time) REFERENCES fr_time(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_minor_strata_group_of_landingsites; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_minor_strata
    ADD CONSTRAINT fk_minor_strata_group_of_landingsites FOREIGN KEY (id_gls) REFERENCES ref_group_of_landingsites(id) DEFERRABLE;


--
-- Name: fk_minor_strata_ref_no_recording_activities; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_minor_strata
    ADD CONSTRAINT fk_minor_strata_ref_no_recording_activities FOREIGN KEY (id_no_recording_activity) REFERENCES ref_no_recording_activities(id) DEFERRABLE;


--
-- Name: fk_ref_collectors_reg_vessels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_collectors
    ADD CONSTRAINT fk_ref_collectors_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;


--
-- Name: fk_ref_sampling_technique_fr_time; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_sampling_technique
    ADD CONSTRAINT fk_ref_sampling_technique_fr_time FOREIGN KEY (id_fr_time) REFERENCES fr_time(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_ref_sampling_technique_ref_strategy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_sampling_technique
    ADD CONSTRAINT fk_ref_sampling_technique_ref_strategy FOREIGN KEY (id_strategy) REFERENCES ref_strategy(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_authorisation_types; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_authorisation_types FOREIGN KEY (authorisationtype) REFERENCES ref_authorisation_types(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_changes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_changes FOREIGN KEY (nonoperationalreason) REFERENCES ref_changes(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_commercial_categories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_commercial_categories FOREIGN KEY (secondarygeartargetgroupofspecies) REFERENCES ref_commercial_categories(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_commercial_categories1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_commercial_categories1 FOREIGN KEY (maingeartargetgroupofspecies) REFERENCES ref_commercial_categories(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_countries; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_countries FOREIGN KEY (originalflag) REFERENCES ref_countries(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_countries1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_countries1 FOREIGN KEY (flag) REFERENCES ref_countries(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_engine_locations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_engine_locations FOREIGN KEY (enginelocation) REFERENCES ref_engine_locations(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_fleet_segmentation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_fleet_segmentation FOREIGN KEY (fleetsegment) REFERENCES ref_fleet_segmentation(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_gears; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_gears FOREIGN KEY (secondarygeartype) REFERENCES ref_gears(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_gears1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_gears1 FOREIGN KEY (maingeartype) REFERENCES ref_gears(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_issuing_offices; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_issuing_offices FOREIGN KEY (issuingoffice) REFERENCES ref_issuing_offices(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_operational_statuses; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_operational_statuses FOREIGN KEY (operationalstatus) REFERENCES ref_operational_statuses(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_ports; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_ports FOREIGN KEY (homeport) REFERENCES ref_ports(id) DEFERRABLE;


--
-- Name: fk_ref_vessels_ref_vessel_types; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_vessels
    ADD CONSTRAINT fk_ref_vessels_ref_vessel_types FOREIGN KEY (vesseltype) REFERENCES ref_vessel_types(id) DEFERRABLE;


--
-- Name: fk_refgears_refgearclasses; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_gears
    ADD CONSTRAINT fk_refgears_refgearclasses FOREIGN KEY (gearclass) REFERENCES ref_gear_classes(id) DEFERRABLE;


--
-- Name: fk_refgears_refmarinefisherysubsectors; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ref_gears
    ADD CONSTRAINT fk_refgears_refmarinefisherysubsectors FOREIGN KEY (marinefisherysubsector) REFERENCES ref_marine_fishery_subsectors(id) DEFERRABLE;


--
-- Name: fk_sampled_catch_ref_commercial_categories; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT fk_sampled_catch_ref_commercial_categories FOREIGN KEY (id_commercial_category) REFERENCES ref_commercial_categories(id) DEFERRABLE;


--
-- Name: fk_sampled_catch_ref_units; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT fk_sampled_catch_ref_units FOREIGN KEY (id_catch_no_boxes_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_catch_ref_units1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT fk_sampled_catch_ref_units1 FOREIGN KEY (id_catch_units_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_catch_ref_units2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT fk_sampled_catch_ref_units2 FOREIGN KEY (id_catch_weight_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_catch_ref_units3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT fk_sampled_catch_ref_units3 FOREIGN KEY (id_sample_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_catch_sampled_fishing_operations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_catch
    ADD CONSTRAINT fk_sampled_catch_sampled_fishing_operations FOREIGN KEY (id_fishing_operation) REFERENCES sampled_fishing_operations(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_sampled_cell_cas_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell
    ADD CONSTRAINT fk_sampled_cell_cas_dates FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_sampled_cell_gl_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_cell
    ADD CONSTRAINT fk_sampled_cell_gl_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_cas_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_cas_dates1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_cas_dates1 FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_categories_ref_commercial_categor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations_categories
    ADD CONSTRAINT fk_sampled_fishing_operations_categories_ref_commercial_categor FOREIGN KEY (id_commercial_category) REFERENCES ref_commercial_categories(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_categories_sampled_fishing_operat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations_categories
    ADD CONSTRAINT fk_sampled_fishing_operations_categories_sampled_fishing_operat FOREIGN KEY (id_fishing_operation) REFERENCES sampled_fishing_operations(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_ref_fishing_zones; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_ref_fishing_zones FOREIGN KEY (id_fishing_zone) REFERENCES ref_fishing_zones(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_ref_gears; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_ref_gears FOREIGN KEY (id_gear) REFERENCES ref_gears(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_ref_units; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_ref_units FOREIGN KEY (id_catch_weight_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_ref_units1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_ref_units1 FOREIGN KEY (id_catch_no_boxes_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_operations_ref_units2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_operations
    ADD CONSTRAINT fk_sampled_fishing_operations_ref_units2 FOREIGN KEY (id_catch_units_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trip_zones_ref_fishing_zones; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips_zones
    ADD CONSTRAINT fk_sampled_fishing_trip_zones_ref_fishing_zones FOREIGN KEY (id_fishing_zone) REFERENCES ref_fishing_zones(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trip_zones_sampled_fishing_trips; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips_zones
    ADD CONSTRAINT fk_sampled_fishing_trip_zones_sampled_fishing_trips FOREIGN KEY (id_fishing_trip) REFERENCES sampled_fishing_trips(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_cas_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_sampled_fishing_trips_cas_dates FOREIGN KEY (id_start_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_gears_ref_gears; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips_gears
    ADD CONSTRAINT fk_sampled_fishing_trips_gears_ref_gears FOREIGN KEY (id_fishing_gear) REFERENCES ref_gears(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_gears_sampled_fishing_trips; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips_gears
    ADD CONSTRAINT fk_sampled_fishing_trips_gears_sampled_fishing_trips FOREIGN KEY (id_fishing_trip) REFERENCES sampled_fishing_trips(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_gl_dates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_sampled_fishing_trips_gl_dates FOREIGN KEY (id_end_dt) REFERENCES gl_dates(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_ref_abstract_landingsite; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_sampled_fishing_trips_ref_abstract_landingsite FOREIGN KEY (id_abstract_landing_site) REFERENCES ref_abstract_landingsite(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_ref_samplers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_sampled_fishing_trips_ref_samplers FOREIGN KEY (id_sampler) REFERENCES ref_samplers(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_ref_units; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_sampled_fishing_trips_ref_units FOREIGN KEY (id_catch_units_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_fishing_trips_ref_units1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_fishing_trips
    ADD CONSTRAINT fk_sampled_fishing_trips_ref_units1 FOREIGN KEY (id_catch_no_boxes_units) REFERENCES ref_units(id) DEFERRABLE;


--
-- Name: fk_sampled_levels_ref_criteria; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_levels
    ADD CONSTRAINT fk_sampled_levels_ref_criteria FOREIGN KEY (id_strategy) REFERENCES ref_strategy(id) DEFERRABLE;


--
-- Name: fk_sampled_levels_ref_levels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_levels
    ADD CONSTRAINT fk_sampled_levels_ref_levels FOREIGN KEY (id_level) REFERENCES ref_levels(id) DEFERRABLE;


--
-- Name: fk_sampled_levels_ref_sampling_technique; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_levels
    ADD CONSTRAINT fk_sampled_levels_ref_sampling_technique FOREIGN KEY (id_sampling_technique) REFERENCES ref_sampling_technique(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_sampled_strata_vessels_ref_minor_strata; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sampled_strata_vessels
    ADD CONSTRAINT fk_sampled_strata_vessels_ref_minor_strata FOREIGN KEY (id_minor_strata) REFERENCES ref_minor_strata(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_tree_node_description; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY fr_tree
    ADD CONSTRAINT fk_tree_node_description FOREIGN KEY (id) REFERENCES fr_node_description(id) DEFERRABLE;


--
-- Name: fk_ui_rule_ptrs_ui_forms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rule_ptrs
    ADD CONSTRAINT fk_ui_rule_ptrs_ui_forms FOREIGN KEY (form) REFERENCES ui_forms(id) DEFERRABLE;


--
-- Name: fk_ui_rule_ptrs_ui_rules; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rule_ptrs
    ADD CONSTRAINT fk_ui_rule_ptrs_ui_rules FOREIGN KEY (id_rules) REFERENCES ui_rules(id) DEFERRABLE;


--
-- Name: fk_ui_rules_ui_forms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rules
    ADD CONSTRAINT fk_ui_rules_ui_forms FOREIGN KEY (form) REFERENCES ui_forms(id) DEFERRABLE;


--
-- Name: fk_ui_rules_ui_rule_types; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_rules
    ADD CONSTRAINT fk_ui_rules_ui_rule_types FOREIGN KEY (type) REFERENCES ui_rule_types(id) DEFERRABLE;


--
-- Name: fk_user_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ui_user
    ADD CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES ui_role(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_vessel_perm_changes_fr_frame; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_vessel
    ADD CONSTRAINT fk_vessel_perm_changes_fr_frame FOREIGN KEY (id_sub_frame) REFERENCES fr_sub_frame(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: fk_vessel_perm_changes_ref_changes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_vessel
    ADD CONSTRAINT fk_vessel_perm_changes_ref_changes FOREIGN KEY (id_ref_changes) REFERENCES ref_changes(id) DEFERRABLE;


--
-- Name: fk_vessel_perm_changes_reg_vessels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY changes_perm_vessel
    ADD CONSTRAINT fk_vessel_perm_changes_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;


--
-- Name: fk_vessel_temp_changes_abstract_landingsite; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_vessel_temp_changes_abstract_landingsite FOREIGN KEY (from_ls) REFERENCES ref_abstract_landingsite(id) DEFERRABLE;


--
-- Name: fk_vessel_temp_changes_abstract_landingsite1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_vessel_temp_changes_abstract_landingsite1 FOREIGN KEY (to_ls) REFERENCES ref_abstract_landingsite(id) DEFERRABLE;


--
-- Name: fk_vessel_temp_changes_ref_changes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_vessel_temp_changes_ref_changes FOREIGN KEY (id_ref_changes) REFERENCES ref_changes(id) DEFERRABLE;


--
-- Name: fk_vessel_temp_changes_reg_vessels; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_vessel_temp_changes_reg_vessels FOREIGN KEY (vesselid) REFERENCES ref_vessels(vesselid) DEFERRABLE;


--
-- Name: fk_vessel_temp_changes_sampled_cell; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY abstract_changes_temp_vessel
    ADD CONSTRAINT fk_vessel_temp_changes_sampled_cell FOREIGN KEY (id_cell) REFERENCES sampled_cell(id) DEFERRABLE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

